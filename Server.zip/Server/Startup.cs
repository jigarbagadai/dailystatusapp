﻿using System;
using System.Collections.Generic;
using Server.Data.DataModel;
using System.IO;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Server.Authorization;
using Microsoft.Extensions.Configuration;
using Hangfire;
using Hangfire.SqlServer;
using Microsoft.AspNetCore.Mvc.Authorization;
using Server.Infrastructure;
using Server.Infrastructure.Emailing;
using Server.Infrastructure.FilesHandling;
using Server.Infrastructure.Utility;
using Swashbuckle.Swagger.Model;
using Swashbuckle.SwaggerGen.Generator;
using System.Linq;
using NLog;
using NLog.Extensions.Logging;
using NLog.Web;
using Server.Filters;

namespace Server
{
    public class Startup
    {
        private readonly ApplicationSettings _applicationSettings = new ApplicationSettings();

        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json")
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", true);

            builder.AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; set; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit http://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            Configuration.GetSection("Application").Bind(_applicationSettings);
            services.Configure<ApplicationSettings>(settings => Configuration.GetSection("Application").Bind(settings));
            services.Configure<EmailingSettings>(settings => Configuration.GetSection("Emailing").Bind(settings));
            services.Configure<StorageSettings>(settings => Configuration.GetSection("Storage").Bind(settings));

            services.AddTransient<EncryptionHelper>();
            services.AddTransient<EmailGenerator>();

            services.AddTransient<MeanderEntities>(sp => new MeanderEntities(Configuration["Data:ConnectionString"]));

            services.AddMvc(options =>
            {
                options.Filters.Add(new ExceptionHandleAtttribute());
            });

            services.AddOpenIddict<MdrApplicationStore, MdrAuthorizationStore, MdrScopeStore, MdrTokenStore>()
                .AddApplicationStore<MdrApplicationStore>()
                .AddAuthorizationStore<MdrAuthorizationStore>()
                .AddScopeStore<MdrScopeStore>()
                .AddTokenStore<MdrTokenStore>()
                .EnableTokenEndpoint("/api/connect/token")
                .AllowPasswordFlow()
                .UseJsonWebTokens()
                .AddEphemeralSigningKey()
                .AddMvcBinders()
                .DisableHttpsRequirement() // todo: remove in prod
                ;

            services.AddHangfire(configuration =>
            {
                JobStorage.Current = new SqlServerStorage(Configuration.GetSection("Hangfire:ConnectionString").Value);
            });

            services.AddSwaggerGen();
            services.ConfigureSwaggerGen(options => options.OperationFilter<SwaggerOpFilter>());
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            app.UseHangfireDashboard("/hangfire", new DashboardOptions
            {
                Authorization = new[]
                {
                    new HangfireDashboardAuthorizationFilter()
                }
            });

            loggerFactory.AddConsole();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();

                app.UseSwagger();
                app.UseSwaggerUi();
            }

            // todo: restrict later
            app.UseCors(builder =>
            {
                builder.AllowAnyHeader();
                builder.AllowAnyMethod();
                builder.AllowAnyOrigin();
            });

            app.UseJwtBearerAuthentication(new JwtBearerOptions
            {
                AutomaticAuthenticate = true,
                AutomaticChallenge = true,
                Audience = _applicationSettings.AuthenticationAudience,
                Authority = _applicationSettings.ServerHostName,
                RequireHttpsMetadata = false,
                TokenValidationParameters =
                {
                    ClockSkew = TimeSpan.Zero
                }
            });

            app.UseOpenIddict();

            app.Use(async (context, next) =>
            {
                await next();

                if (context.Response.StatusCode == 404 &&
                    !Path.HasExtension(context.Request.Path.Value) &&
                    !context.Request.Path.Value.StartsWith("/api/"))
                {
                    context.Request.Path = "/index.html";
                    await next();
                }
            });

            app.UseMvc();

            app.UseStaticFiles();

            loggerFactory.AddNLog();
            env.ConfigureNLog("nlog.config");

        }
    }

    public class SwaggerOpFilter : IOperationFilter
    {
        public void Apply(Operation operation, OperationFilterContext context)
        {
            var filterPipeline = context.ApiDescription.ActionDescriptor.FilterDescriptors;
            var isAuthorized = filterPipeline.Select(filterInfo => filterInfo.Filter).Any(filter => filter is AuthorizeFilter);
            var allowAnonymous = filterPipeline.Select(filterInfo => filterInfo.Filter).Any(filter => filter is IAllowAnonymousFilter);
            if (isAuthorized && !allowAnonymous)
            {
                if (operation.Parameters == null)
                    operation.Parameters = new List<IParameter>();
                operation.Parameters.Add(new NonBodyParameter
                {
                    Name = "Authorization",
                    In = "header",
                    Description = "access token",
                    Required = true,
                    Type = "string"
                });
            }
        }
    }

}
