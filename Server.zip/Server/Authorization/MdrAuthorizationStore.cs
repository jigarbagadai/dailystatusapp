﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using OpenIddict.Core;

namespace Server.Authorization
{
    public class MdrAuthorizationStore : IOpenIddictAuthorizationStore<MdrAuthorizationStore>
    {
        public Task<MdrAuthorizationStore> CreateAsync(MdrAuthorizationStore authorization, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<MdrAuthorizationStore> FindByIdAsync(string identifier, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<MdrAuthorizationStore> FindAsync(string subject, string client, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetIdAsync(MdrAuthorizationStore authorization, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetSubjectAsync(MdrAuthorizationStore authorization, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
