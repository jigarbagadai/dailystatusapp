﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using OpenIddict.Core;

namespace Server.Authorization
{
    public class MdrTokenStore : IOpenIddictTokenStore<MdrTokenStore>
    {
        public Task<MdrTokenStore> CreateAsync(MdrTokenStore token, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<MdrTokenStore> CreateAsync(string type, string subject, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<MdrTokenStore> FindByIdAsync(string identifier, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<MdrTokenStore[]> FindBySubjectAsync(string subject, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetIdAsync(MdrTokenStore token, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetTokenTypeAsync(MdrTokenStore token, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetSubjectAsync(MdrTokenStore token, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task RevokeAsync(MdrTokenStore token, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task SetAuthorizationAsync(MdrTokenStore token, string identifier, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task SetClientAsync(MdrTokenStore token, string identifier, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task UpdateAsync(MdrTokenStore token, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
