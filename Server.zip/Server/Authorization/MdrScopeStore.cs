﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OpenIddict.Core;

namespace Server.Authorization
{
    public class MdrScopeStore : IOpenIddictScopeStore<MdrScopeStore>
    {
    }
}
