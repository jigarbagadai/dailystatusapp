﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using OpenIddict.Core;

namespace Server.Authorization
{
    public class MdrApplicationStore : IOpenIddictApplicationStore<MdrApplicationStore>
    {
        public Task<MdrApplicationStore> CreateAsync(MdrApplicationStore application, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task DeleteAsync(MdrApplicationStore application, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<MdrApplicationStore> FindByIdAsync(string identifier, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<MdrApplicationStore> FindByClientIdAsync(string identifier, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<MdrApplicationStore> FindByLogoutRedirectUri(string url, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetClientIdAsync(MdrApplicationStore application, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetClientTypeAsync(MdrApplicationStore application, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetDisplayNameAsync(MdrApplicationStore application, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetHashedSecretAsync(MdrApplicationStore application, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetIdAsync(MdrApplicationStore application, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetLogoutRedirectUriAsync(MdrApplicationStore application, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetRedirectUriAsync(MdrApplicationStore application, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<string>> GetTokensAsync(MdrApplicationStore application, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task SetClientTypeAsync(MdrApplicationStore application, string type, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task SetHashedSecretAsync(MdrApplicationStore application, string hash, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task UpdateAsync(MdrApplicationStore application, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
