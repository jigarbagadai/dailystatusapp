﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Server.Models;
using Server.Infrastructure.FilesHandling;
using Microsoft.Extensions.Options;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.Linq;

namespace Server.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class FileController : Controller
    {
        protected readonly StorageSettings StorageSettings;
        private string fileIdentifier;

        public FileController(IOptions<StorageSettings> storageSettings)
        {
            this.StorageSettings = storageSettings.Value;
        }

        [HttpPost]
        public async Task<IList<FileModel>> Post()
        {
            List<FileModel> files = new List<FileModel>();

            if (Request.Form.Files == null || Request.Form.Files.Count == 0)
                return files;

            var storageAccount = CloudStorageAccount.Parse(this.StorageSettings.AzureStorageConnectionString);
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference($"user{User.Claims.SingleOrDefault(c => c.Type == "name").Value}");
            await container.CreateIfNotExistsAsync();
            await container.SetPermissionsAsync(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob  });

            foreach (var formFile in Request.Form.Files)
            {
                var fileExt = formFile.FileName.Split('.').Last();
                fileIdentifier = $"{Guid.NewGuid().ToString("N")}.{fileExt}";

                using (var memoryStream = new MemoryStream())
                {
                    formFile.CopyTo(memoryStream);
                    memoryStream.Position = 0;

                    CloudBlockBlob blobref = container.GetBlockBlobReference(fileIdentifier);
                    await blobref.UploadFromStreamAsync(memoryStream);
                    blobref.Properties.ContentType = formFile.ContentType;
                    blobref.Properties.ContentDisposition = "inline; filename=" + formFile.FileName;
                    blobref.SetProperties();

                    files.Add(new FileModel
                    {
                        Id = fileIdentifier,
                        Name = formFile.FileName,
                        ContentType = formFile.ContentType,
                        Url = blobref.StorageUri.PrimaryUri.AbsoluteUri
                    });

                }
            }

            return files;
        }

        [HttpDelete("{fileidentifier}")]
        public async Task<bool> Delete(string fileidentifier)
        {
            bool result = false;
            string[] fileids = fileidentifier.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string fileid in fileids)
            {
                var storageAccount = CloudStorageAccount.Parse(this.StorageSettings.AzureStorageConnectionString);
                CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
                CloudBlobContainer container = blobClient.GetContainerReference($"user{User.Claims.SingleOrDefault(c => c.Type == "name").Value}");
                //string azureFileUrl = string.Format("{0}/{1}", container.Uri.ToString(), fileidentifier);
                CloudBlockBlob blobref = container.GetBlockBlobReference(fileidentifier);
                result = await blobref.DeleteIfExistsAsync();
            }

            return result;
        }
    }
}
