﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Server.Models;
using Server.Data;
using Server.Data.BAL;
using System;
using Server.Data.DataModel;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Server.Data.Dtos;
using Server.Infrastructure.Emailing;
using Server.Infrastructure.Emailing.EmailProperties;
using Server.Infrastructure.Utility;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Server.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class MemoryController : Controller
    {

        protected readonly MeanderEntities _meanderEntities;
        protected readonly EncryptionHelper objEncryptionHelper;
        protected readonly EmailGenerator objEmailGenerator;

        MemoryBL _objMemoryBL;
        public MemoryController(
            MeanderEntities meanderEntities,
            EncryptionHelper encryptionHelper,
            EmailGenerator emailGenerator)
        {
            _meanderEntities = meanderEntities;
            _objMemoryBL = new MemoryBL(_meanderEntities);
            objEncryptionHelper = encryptionHelper;
            objEmailGenerator = emailGenerator;
        }

        [HttpGet("{memoryId}")]
        public async Task<JsonResult> Get(int memoryId)
        {
            Response response = new Response();
            try
            {
                int userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);

                var memoryResult = await _objMemoryBL.GetMemory(memoryId, userId);
            
                response.Object = memoryResult;
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }

        [HttpPost]
        public async Task<JsonResult> Post([FromBody] MemoryViewModel model)
        {
            Response response = new Response();
            try
            {
                int userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);

                if (ModelState.IsValid)
                {
                    Memory obj = new Data.DataModel.Memory();
                    obj.MemoryId = model.MemoryId ?? 0;
                    obj.OwnerId = userId;
                    obj.CategoryId = model.CategoryId;
                    obj.Date = model.Date;
                    obj.Location = model.Location;
                    obj.latitude = model.LocationModel.Latitude;
                    obj.longitude = model.LocationModel.Longitude;
                    obj.Title = model.Title;
                    obj.Description = model.Description;
                    obj.DateText = model.DateText;

                    List<MemoryAttachment> lstattach = new List<MemoryAttachment>();
                    if (model.lstMemoryAttachment != null)
                    {
                        foreach (MemoryAttachmentViewModel item in model.lstMemoryAttachment)
                        {
                            lstattach.Add(new MemoryAttachment()
                            {
                                FileName = item.FileName,
                                FileIdentifier = item.FileIdentifier,
                                AttachmentUrl = item.AttachmentUrl
                            });
                        }
                    }

                    int memoryId = await _objMemoryBL.MemoryAdd(obj, lstattach, model.lstPeople);

                    var memoryResult = await _objMemoryBL.GetMemory(memoryId, userId);
                    await SendMemoryNotificationEmail(memoryResult.lstPeople);

                    var memoryInvitees = await _objMemoryBL.GetMemoryInvitees(memoryId);

                    await SendMemoryInvitations(memoryInvitees, memoryId, memoryResult);

                    response.Success = true;
                    response.Object = memoryResult;
                }
                else
                {
                    response.Success = false;
                    response.ResponseString = "Invalid model";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }

        [HttpPut]
        public async Task<JsonResult> Put([FromBody] MemoryViewModel model)
        {
            Response response = new Response();
            try
            {
                if (ModelState.IsValid)
                {
                    if (!model.MemoryId.HasValue)
                    {
                        throw new InvalidOperationException("Memory Id cannot be null");
                    }

                    var userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);

                    Memory obj = new Data.DataModel.Memory();
                    obj.MemoryId = model.MemoryId.Value;
                    obj.OwnerId = userId;
                    obj.CategoryId = model.CategoryId;
                    obj.Date = model.Date;
                    obj.Location = model.Location;
                    obj.latitude = model.LocationModel.Latitude;
                    obj.longitude = model.LocationModel.Longitude;
                    obj.Title = model.Title;
                    obj.Description = model.Description;
                    obj.DateText = model.DateText;

                    List<MemoryAttachment> lstattach = new List<MemoryAttachment>();
                    if (model.lstMemoryAttachment != null)
                    {
                        foreach (MemoryAttachmentViewModel item in model.lstMemoryAttachment)
                        {
                            lstattach.Add(new MemoryAttachment()
                            {
                                MemoryAttachmentId = item.MemoryAttachmentId ?? 0,
                                MemoryId = item.MemoryId ?? 0,
                                FileName = item.FileName,
                                FileIdentifier = item.FileIdentifier,
                                AttachmentUrl = item.AttachmentUrl
                            });
                        }
                    }

                    var existingMemoryUsers = await _objMemoryBL.GetMemoryPeople(model.MemoryId.Value);

                    response = await _objMemoryBL.MemoryUpdate(obj, lstattach, model.lstPeople);

                    if (response.Success)
                    {
                        var memoryResult = await _objMemoryBL.GetMemory(model.MemoryId.Value, userId);
                        await SendMemoryNotificationEmail(memoryResult.lstPeople);

                        var alreadySentIds = existingMemoryUsers.Where(mu => mu.UserRelationId.HasValue).Select(mu => (int)mu.UserRelationId);
                        var memoryInvitees = await _objMemoryBL.GetMemoryInvitees(model.MemoryId.Value);

                        // filter out any user relation who has already been sent an invite to the Memory
                        var filteredInvitees = memoryInvitees.Where(mi => !alreadySentIds.Contains(mi.UserRelationId));

                        await SendMemoryInvitations(filteredInvitees, model.MemoryId.Value, memoryResult);
                    }
                    
                }
                else
                {
                    response.Success = false;
                    response.ResponseString = "Invalid model";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }

        [HttpPut("[action]/{memoryId}")]
        public async Task<JsonResult> UserMemoryUpdate(int memoryId, [FromBody]MemoryUserViewModel model)
        {
            int userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);
            return Json(await _objMemoryBL.UpdateMemoryBubbleUser(memoryId, userId, model.IsSavedToTimeline, model.IsBookmarked));
        }

        [HttpGet("[action]/{searchText}")]
        public JsonResult SearchMemory(string searchText)
        {
            Response response = new Data.Response();
            try
            {
                response.Object = _objMemoryBL.SearchMemory(searchText, Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value));
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }
        
        [HttpPost("[action]")]
        public JsonResult FilterMemory(FilterMemoryModel model)
        {
            Response response = new Data.Response();
            try
            {
                response.Object = _objMemoryBL.FilterMemory(model.CategoryId,model.DateTIme,model.Location,model.UserRelationId, Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value));
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }

        [HttpGet]
        public JsonResult GetUserMemoryByUserId()
        {
            Response response = new Data.Response();
            try
            {
                int userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);

                response.Object = _objMemoryBL.GetUserMemoryByUserId(userId);
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }

        private async Task SendMemoryNotificationEmail(IEnumerable<MemoryPersonDto> memoryPersons)
        {
            memoryPersons = memoryPersons.Where(m => m.UserRelationId.HasValue && (!m.IsEmailSent.HasValue || (m.IsEmailSent.HasValue && !m.IsEmailSent.Value)));
            foreach (var item in memoryPersons)
            {
               bool result =  await objEmailGenerator.SendMemoryNotificationEmail(
                    item.UserEmailAddress, 
                    item.ScreenName);

                if(result)
                {
                    await _objMemoryBL.UpdateEmailStatus(item.MemoryUserId);
                }
            }
        }
        private async Task SendMemoryInvitations(IEnumerable<MemoryInviteeDto> memoryInvitees, int memoryId, MemoryDto memory)
        {
            foreach (var invitee in memoryInvitees)
            {
                var inviteeToken = $"{invitee.UserRelationId}|{memoryId}|{invitee.EmailAddress}";
                var inviteeTokenEncrypted = objEncryptionHelper.Encrypt(inviteeToken);

                var people = string.Join(", ", memory.lstPeople.Select(p => !string.IsNullOrEmpty(p.ScreenName) ? p.ScreenName : p.FirstName)).TrimEnd(' ').TrimEnd(',');

                await objEmailGenerator.SendMemoryInvitationEmail(
                    invitee.EmailAddress,
                    invitee.FirstName,
                    new MemoryInvitation
                    {
                        MemoryId = memoryId,
                        RecipientName = invitee.ScreenName,
                        Title = memory.Title,
                        Location = memory.Location,
                        Date = memory.DateText,
                        People = people,
                        Details = memory.Description,
                        InviteeToken = inviteeTokenEncrypted,
                        OwnerName = memory.OwnerName,
                    });
            }
        }


    }

}
