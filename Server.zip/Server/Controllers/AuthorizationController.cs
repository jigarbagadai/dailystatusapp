﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using AspNet.Security.OpenIdConnect.Primitives;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using AspNet.Security.OpenIdConnect.Extensions;
using AspNet.Security.OpenIdConnect.Server;
using Microsoft.AspNetCore.Http.Authentication;
using Microsoft.Extensions.Options;
using OpenIddict.Core;
using Server.Data.BAL;
using Server.Data;
using Server.Data.DataModel;
using Server.Infrastructure;
using Server.Infrastructure.Utility;

namespace Server.Controllers
{
    // source: https://github.com/openiddict/openiddict-samples/blob/master/samples/PasswordFlow/AuthorizationServer/Controllers/AuthorizationController.cs
    public class AuthorizationController : Controller
    {
        protected readonly MeanderEntities _meanderEntities;

        private readonly UserBL objUserBL;
        EncryptionHelper objEncryptionHelper;
        private readonly ApplicationSettings _applicationSettings;

        public AuthorizationController(
            MeanderEntities meanderEntities,
            EncryptionHelper encryptionHelper,
            IOptions<ApplicationSettings> applicationSettings)
        {
            _meanderEntities = meanderEntities;
            objUserBL = new UserBL(_meanderEntities);
            objEncryptionHelper = encryptionHelper;
            _applicationSettings = applicationSettings.Value;
        }

        [HttpPost("~/api/connect/token"), Produces("application/json")]
        public async Task<IActionResult> Exchange(OpenIdConnectRequest request)
        {
            if (!request.IsPasswordGrantType())
            {
                return Unauthorized();
            }

            // check for a verifyEmail token and if present extract the userId from that
            Response res = null;
            if (!string.IsNullOrEmpty(request.Token))
            {
                var emailVerifyToken = objEncryptionHelper.Decrypt(request.Token);
                var tokenParts = emailVerifyToken.Split('|');
                int userId;

                if (tokenParts.Length == 2 && int.TryParse(tokenParts[0], out userId) && !string.IsNullOrEmpty(tokenParts[1]))
                {
                    res = await objUserBL.GetUserByUserId(userId);
                }
            }
            else
            {
                // otherwise login using credentials
                res = objUserBL.Login(request.Username, request.Password);
            }

            if (res == null || !res.Success)
            {
                return Unauthorized();
            }


            User oUser = (User)res.Object;
            
            var identity = new ClaimsIdentity(
                OpenIdConnectServerDefaults.AuthenticationScheme,
                OpenIdConnectConstants.Claims.Name,
                OpenIdConnectConstants.Claims.Role);
            identity.AddClaim(OpenIdConnectConstants.Claims.Subject, oUser.EmailAddress);
            identity.AddClaim(OpenIdConnectConstants.Claims.Name, oUser.UserId.ToString(),
                OpenIdConnectConstants.Destinations.AccessToken,
                OpenIdConnectConstants.Destinations.IdentityToken);

            var principal = new ClaimsPrincipal(identity);

            var tokenExpiry = TimeSpan.FromMinutes(_applicationSettings.AuthenticationTimeoutMinutes);

            var ticket = new AuthenticationTicket(
                principal,
                new AuthenticationProperties
                {
                    ExpiresUtc = DateTime.Now.Add(tokenExpiry)
                },
                OpenIdConnectServerDefaults.AuthenticationScheme);

            ticket.SetResources(_applicationSettings.AuthenticationAudience);
            ticket.SetAccessTokenLifetime(TimeSpan.FromMinutes(_applicationSettings.AuthenticationTimeoutMinutes));

            ticket.SetScopes(new[]
            {
                OpenIdConnectConstants.Scopes.OpenId,
                OpenIdConnectConstants.Scopes.Email,
                OpenIdConnectConstants.Scopes.Profile,
                OpenIdConnectConstants.Scopes.OfflineAccess,
                OpenIddictConstants.Scopes.Roles
            }.Intersect(request.GetScopes()));

            return SignIn(ticket.Principal, ticket.Properties, ticket.AuthenticationScheme);
             
        }

    }
}
