﻿using System;
using Microsoft.AspNetCore.Mvc;
using Server.Data.DataModel;
using Server.Data.BAL.MemoryBubble;
using Server.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using System.Linq;
using Server.Data.Dtos;
using Server.Infrastructure.Emailing;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Server.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class MemoryBubbleController : Controller
    {
        protected readonly MeanderEntities _meanderEntities;
        protected readonly EmailGenerator objEmailGenerator;
        MemoryBubbleBL _objMemoryBubbleBL;
        public MemoryBubbleController(MeanderEntities meanderEntities,
            EmailGenerator emailGenerator)
        {
            _meanderEntities = meanderEntities;
            _objMemoryBubbleBL = new MemoryBubbleBL(_meanderEntities);
            objEmailGenerator = emailGenerator;
        }
        
        [HttpPost]
        public async Task<JsonResult> Post([FromBody]MemoryBubbleViewModel model)
        {
            var userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);

            List<MemoryBubbleAttachment> lstattach = new List<MemoryBubbleAttachment>();
            if (model.lstBubbleAttachments != null)
            {
                foreach (BubbleAttachmentViewModel item in model.lstBubbleAttachments)
                {
                    lstattach.Add(new MemoryBubbleAttachment()
                    {
                        BubbleAttachmentId = item.BubbleAttachmentId ?? 0,
                        BubbleId = item.MemoryBubbleId ?? 0,
                        Name = item.FileName,
                        FileIdentifier = item.FileIdentifier,
                        AttachmentUrl = item.AttachmentUrl
                    });
                }
            }

            var memoryBubbleResult = await _objMemoryBubbleBL.MemoryBubbleAdd(model.MemoryId, userId, model.Description, lstattach, model.lstBubblePeople);
            MemoryBubbleDto result = memoryBubbleResult.Object.Object as MemoryBubbleDto;
            if(result!=null)
            {
                await SendBubbleNotificationEmail(result.lstBubblePeople);
            }

            return Json(memoryBubbleResult);
        }
        
        [HttpPut("{memoryBubbleId}")]
        public async Task<JsonResult> Put(int memoryBubbleId, [FromBody]MemoryBubbleViewModel model)
        {
            var userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);
            model.MemoryBubbleId = memoryBubbleId;

            List<MemoryBubbleAttachment> lstattach = new List<MemoryBubbleAttachment>();
            if (model.lstBubbleAttachments != null)
            {
                foreach (BubbleAttachmentViewModel item in model.lstBubbleAttachments)
                {
                    lstattach.Add(new MemoryBubbleAttachment()
                    {
                        Name = item.FileName,
                        FileIdentifier = item.FileIdentifier,
                        AttachmentUrl = item.AttachmentUrl
                    });
                }
            }

            var memoryBubbleResult = await _objMemoryBubbleBL.MemoryBubbleUpdate(memoryBubbleId, userId, model.Description, lstattach);
            MemoryBubbleDto result = memoryBubbleResult.Object.Object as MemoryBubbleDto;
            if (result != null)
            {
                await SendBubbleNotificationEmail(result.lstBubblePeople);
            }

            return Json(memoryBubbleResult);
        }

        [HttpPut("UpdateMemoryBubbleUser/{memoryBubbleId}")]
        public async Task<JsonResult> UpdateMemoryBubbleUser(int memoryBubbleId, [FromBody]MemoryBubbleUserViewModel model)
        {
            var userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);
            model.MemoryBubbleId = memoryBubbleId;
            return Json(await _objMemoryBubbleBL.UpdateMemoryBubbleUser(model.MemoryBubbleId, userId, model.IsBookmarked, model.IsSavedToTimeline));
        }

        [HttpGet("{memoryBubbleId}")]
        public async Task<JsonResult> Get(int memoryBubbleId)
        {
            var userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);
            var result = await _objMemoryBubbleBL.GetUserMemoryBubble(userId, memoryBubbleId);
            return Json(result);
        }

        [HttpGet("[action]/{memoryId}")]
        public async Task<JsonResult> MemoryBubbleSummaries(int memoryId)
        {
            var userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);
            var result = await _objMemoryBubbleBL.GetBubbleSummariesByMemoryId(userId, memoryId);
            return Json(result);
        }

        private async Task SendBubbleNotificationEmail(IEnumerable<MemoryBubblePersonDto> memoryBubblePersons)
        {
            memoryBubblePersons = memoryBubblePersons.Where(m=>!m.IsEmailSent.HasValue || (m.IsEmailSent.HasValue && !m.IsEmailSent.Value));
            foreach (var item in memoryBubblePersons)
            {
                bool result = await objEmailGenerator.SendBubbleNotificationEmail(
                     item.UserEmailAddress,
                     string.Format("{0} {1}", item.FirstName,item.LastName));

                if (result)
                {
                    await _objMemoryBubbleBL.UpdateEmailStatus(item.MemoryBubbleUserId);
                }
            }
        }
    }
}
