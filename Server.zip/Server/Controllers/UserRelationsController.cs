﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Server.Data.DataModel;
using Server.Data.BAL.UserRelations;
using Server.Models;
using Server.Data;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Server.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class UserRelationsController : Controller
    {
        MeanderEntities objEntites;
        UserRelationsBL objUserRelationsBL;
        public UserRelationsController(MeanderEntities _meanderEntities)
        {
            objEntites = _meanderEntities;
            objUserRelationsBL = new UserRelationsBL(_meanderEntities);
        }

        [HttpGet]
        public async Task<JsonResult> Get()
        {
            var userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);
            var relations = await objUserRelationsBL.GetAllUserRelation(userId);
            return Json(relations);
        }

        [HttpPost]
        public async Task<JsonResult> Post([FromBody]UserRelationViewModel model)
        {
            Response response = new Data.Response();
            try
            {
                UserRelation obj = new UserRelation();
                obj.UserRelationId = 0;
                obj.UserId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);
                obj.RelationUserId = model.RelationUserId;
                obj.RelationshipType = model.RelationshipType;
                obj.FirstName = model.FirstName;
                obj.LastName = model.LastName;
                obj.EmailAddress = model.EmailAddress;
                obj.ScreenName = model.ScreenName;
                obj.TimelineShared = model.TimelineShared;
                response = await objUserRelationsBL.UserRelationAddUpdate(obj);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }

        [HttpPut("{userRelationId}")]
        public async Task<JsonResult> Put(int userRelationId, [FromBody]UserRelationViewModel model)
        {
            Response response = new Data.Response();
            try
            {
                var relation = await objUserRelationsBL.GetUserRelation(userRelationId);
                if (relation == null)
                    throw new InvalidOperationException("User relation does not exist");

                UserRelation obj = new UserRelation();
                obj.UserRelationId = relation.UserRelationId;
                obj.UserId = relation.UserId;
                obj.RelationUserId = relation.RelationUserId;
                obj.RelationshipType = model.RelationshipType;
                obj.FirstName = model.FirstName;
                obj.LastName = model.LastName;
                obj.EmailAddress = model.EmailAddress;
                obj.ScreenName = model.ScreenName;
                obj.TimelineShared = model.TimelineShared;
                response = await objUserRelationsBL.UserRelationAddUpdate(obj);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }

        [HttpDelete("{userRelationId}")]
        public async Task<JsonResult> Delete(int userRelationId)
        {
            Response response = new Data.Response();
            try
            {
                response = await objUserRelationsBL.DeleteUserRelation(userRelationId);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }
      
    }
}
