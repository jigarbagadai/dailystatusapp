﻿using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Server.Models;
using Server.Data.DataModel;
using Server.Data.BAL.Category;
using System;
using Server.Data;

namespace Server.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class CategoriesController : Controller
    {
        MeanderEntities objEntites;
        CategoryBL objCategoryBL;
        public CategoriesController(MeanderEntities _meanderEntities)
        {
            objEntites = _meanderEntities;
            objCategoryBL = new CategoryBL(_meanderEntities);
        }

        [HttpGet]
        public async Task<JsonResult> Get()
        {
            var results = await objCategoryBL.GetUserAndSystemCategories(Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value));
            return Json(results);
        }

        [HttpGet("getown")]
        public async Task<JsonResult> GetOwn()
        {
            var results = await objCategoryBL.GetUserCategories(Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value));
            return Json(results);
        }

        [HttpPost]
        public async Task<JsonResult> Post([FromBody]CategoryViewModel model)
        {
            Category obj = new Category();
            obj.CategoryId = model.CategoryId;
            obj.OwnerId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);
            obj.Name = model.Name;
            obj.IconUrl = model.IconUrl;
            return Json(await objCategoryBL.CategoryAddUpdate(obj));
        }

        [HttpPut("{categoryId}")]
        public async Task<JsonResult> Put(int categoryId, [FromBody]CategoryViewModel model)
        {
            Category obj = new Category();
            obj.CategoryId = model.CategoryId;
            obj.OwnerId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);
            obj.Name = model.Name;
            obj.IconUrl = model.IconUrl;
            return Json(await objCategoryBL.CategoryAddUpdate(obj));
        }

        [HttpDelete("{categoryId}")]
        public async Task<JsonResult> Delete(int categoryId)
        {
            Response response = new Data.Response();
            try
            {
                response = await objCategoryBL.DeleteCategory(categoryId);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }

    }
}
