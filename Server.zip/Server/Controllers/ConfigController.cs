﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Server.Models;
using Microsoft.Extensions.Options;
using Server.Infrastructure;

namespace Server.Controllers
{
    [Route("api/[controller]")]
    public class ConfigController : Controller
    {
        protected readonly ApplicationSettings ApplicationSettings;

        public ConfigController(IOptions<ApplicationSettings> applicationSettings)
        {
            this.ApplicationSettings = applicationSettings.Value;
        }

        [HttpGet]
        public async Task<ConfigModel> Get()
        {
            return new ConfigModel
            {
                GoogleAnalyticsTrackingId = ApplicationSettings.GoogleAnalyticsTrackingId
            };
        }
        
    }
}
