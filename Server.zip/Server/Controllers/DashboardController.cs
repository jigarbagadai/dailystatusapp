﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Server.Data.BAL.DashBoard;
using Server.Data;
using Server.Data.DataModel;
using System.Linq;
using Server.Data.Dtos;
using Server.Infrastructure.Search;
using Server.Models;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Server.Controllers
{
    [Authorize]
    [Route("api/[controller]/[action]")]
    public class DashboardController : Controller
    {
        protected readonly MeanderEntities _meanderEntities;
        DashBoardBL _objDashBoardBL;

        private class TimelineFilterTypes
        {
            public static string Category = "category";
            public static string Location = "location";
            public static string Date = "date";
            public static string Person = "person";
            public static string Owner = "owner";
        }

        public DashboardController(MeanderEntities meanderEntities)
        {
            _meanderEntities = meanderEntities;
            _objDashBoardBL = new DashBoardBL(_meanderEntities);
        }

        [HttpGet]
        public async Task<JsonResult> Bookmarks()
        {
            Response response = new Response();
            try
            {
                response.Object = await _objDashBoardBL.Bookmarks(Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value));
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }

            return Json(response);
        }

        [HttpGet]
        public async Task<JsonResult> Notifications()
        {
            Response response = new Response();
            try
            {
                response.Object = await _objDashBoardBL.Notifications(Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value));
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }

            return Json(response);
        }

        [HttpGet("{timelineUserId}")]
        public async Task<JsonResult> TimelineUser(int timelineUserId)
        {
            Response response = new Response();
            try
            {
                var userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);

                response.Object = await _objDashBoardBL.TryViewTimelineUser(userId, timelineUserId);
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }

            return Json(response);
        }

        [HttpPost]
        public async Task<JsonResult> Timeline([FromBody] TimelineQueryDto query)
        {
            Response response = new Response();
            try
            {
                var userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);

                // get the timelineUserId, either the loggedIn user or try get their relations timelineUserId (if visible)
                int timelineUserId;
                if (userId == query.TimelineUserId)
                {
                    timelineUserId = userId;
                }
                else
                {
                    var timelineUser = await _objDashBoardBL.TryViewTimelineUser(userId, query.TimelineUserId);

                    timelineUserId = timelineUser?.UserId ?? userId;
                }

                var includeHidden = !string.IsNullOrWhiteSpace(query.SearchTerm);

                var memories = (await _objDashBoardBL.Memories(timelineUserId, includeHidden)).AsQueryable();

                var memoriesQueried = FilterMemories(memories, query.SearchTerm, query.Filters);

                var filtered = memoriesQueried.Select(tm => new TimelineMemoryModel
                {
                    MemoryId = tm.MemoryId,
                    CategoryIconUrl = tm.CategoryIconUrl,
                    Timestamp = tm.Date,
                    BubbleCount = tm.MemoryBubbles?.Count() ?? 0
                }).ToArray();

                response.Object = filtered;
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }

            return Json(response);
        }

        [HttpPost]
        public async Task<JsonResult> OpenNotification([FromBody] NotificationDto notification)
        {
            var userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);

            return Json(await _objDashBoardBL.OpenNotification(userId, notification));
        }


        private IList<TimelineMemoryDto> FilterMemories(
            IQueryable<TimelineMemoryDto> memories, 
            string searchTerm, 
            TimelineFilterDto[] filters)
        {
            // check if no search/filters provided
            if (string.IsNullOrWhiteSpace(searchTerm) && filters.Length == 0)
                return memories.ToList();

            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                // query by filters

                var predicate = PredicateBuilder.True<TimelineMemoryDto>();

                foreach (var filter in filters)
                {
                    if (filter.Type == TimelineFilterTypes.Category)
                    {
                        predicate = predicate.And(m => m.CategoryId == int.Parse(filter.Value));
                    }
                    else if (filter.Type == TimelineFilterTypes.Location)
                    {
                        predicate = predicate.And(m => m.Location.IgnoreCaseContains(filter.Value));
                    }
                    else if (filter.Type == TimelineFilterTypes.Date)
                    {
                        predicate = predicate.And(m => m.DateText.IgnoreCaseContains(filter.Value));
                        // need check on Date ?
                    }
                    else if (filter.Type == TimelineFilterTypes.Person)
                    {
                        predicate = predicate.And(m => m.UserRelationIds.Any(urId => urId == int.Parse(filter.Value)));
                    }
                    else if (filter.Type == TimelineFilterTypes.Owner)
                    {
                        predicate = predicate.And(m => m.OwnerId == int.Parse(filter.Value));
                    }
                    else
                    {
                        throw new InvalidOperationException("Unknown timeline filter type");
                    }
                }

                return memories.Where(predicate).ToList();
            }
            else
            {
                // query by search

                // include if memory title/description or any of the memories bubbles contains the searchTerm
                Func<TimelineMemoryDto, bool> query = m =>
                    m.Title.IgnoreCaseContains(searchTerm) 
                    || m.Description.IgnoreCaseContains(searchTerm) 
                    || m.MemoryBubbles.Any(mb => mb.Description.IgnoreCaseContains(searchTerm));

                return memories.Where(query).ToList();
            }
        }

    }
}
