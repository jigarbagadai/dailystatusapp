﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Server.Models;
using Server.Data;
using Server.Data.BAL;
using System;
using Server.Data.DataModel;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Server.Data.Dtos;
using Server.Infrastructure.Utility;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Server.Controllers
{
    [Route("api/[controller]")]
    public class AccessUnauthMemoryController : Controller
    {

        protected readonly MeanderEntities _meanderEntities;
        protected readonly EncryptionHelper objEncryptionHelper;
        MemoryBL _objMemoryBL;

        public AccessUnauthMemoryController(
            MeanderEntities meanderEntities,
            EncryptionHelper encryptionHelper)
        {
            _meanderEntities = meanderEntities;
            _objMemoryBL = new MemoryBL(_meanderEntities);
            objEncryptionHelper = encryptionHelper;
        }
        
        [HttpPost]
        public async Task<JsonResult> Post([FromBody] AccessUnauthMemoryViewModel model)
        {
            Response response = new Response();
            try
            {
                var memoryIniteToken = objEncryptionHelper.Decrypt(model.AccessToken);
                var tokenParts = memoryIniteToken.Split('|');
                int userRelationId, memoryId;

                if (tokenParts.Length == 3
                    && int.TryParse(tokenParts[0], out userRelationId)
                    && int.TryParse(tokenParts[1], out memoryId)
                    && !string.IsNullOrEmpty(tokenParts[2]))
                {
                    var emailAddress = tokenParts[2];

                    var memoryResult = await _objMemoryBL.GetMemory(memoryId);

                    response.Object = memoryResult;
                    response.Success = true;
                }
                else
                {
                    response.Success = false;
                    response.ResponseString = "Unable to validate memory invitation token";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }

    }

}
