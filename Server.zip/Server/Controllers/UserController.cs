﻿using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Server.Data.BAL;
using Server.Models;
using Server.Data;
using System;
using System.Collections.Generic;
using System.Reflection;
using Server.Data.DataModel;
using Server.Infrastructure.Emailing;
using Server.Infrastructure.Utility;

namespace Server.Controllers
{
    [Route("api/[controller]")]
    public class UserController : Controller
    {
        UserBL objUserBL;
        MeanderEntities objEntites;
        EncryptionHelper objEncryptionHelper;
        EmailGenerator objEmailGenerator;

        public UserController(
            MeanderEntities _meanderEntities,
            EncryptionHelper _encryptionHelper,
            EmailGenerator _emailGenerator)
        {
            objEntites = _meanderEntities;
            objUserBL = new UserBL(_meanderEntities);
            objEncryptionHelper = _encryptionHelper;
            objEmailGenerator = _emailGenerator;
        }

        [Authorize]
        [HttpGet]
        public async Task<JsonResult> Get()
        {
            var email = User.Claims.SingleOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;
            return Json(await objUserBL.GetUserByEmail(email));
        }

        [Authorize]
        [HttpPut]
        public async Task<JsonResult> Put([FromBody] UserViewModel model)
        {
            Response response = new Data.Response();
            try
            {
                if (ModelState.IsValid)
                {
                    Data.DataModel.User obj = new Data.DataModel.User();
                    obj.UserId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);
                    obj.EmailAddress = model.EmailAddress;
                    obj.FirstName = model.FirstName;
                    obj.LastName = model.LastName;
                    obj.DateOfBirth = model.DateOfBirth;
                    obj.PlaceOfBirth = model.PlaceOfBirth;
                    obj.Mobile = model.Mobile;
                    obj.DateFormat = model.DateFormat;
                    obj.ProfilePhotoUrl = model.ProfilePhotoUrl;
                    response = await objUserBL.UserUpdate(obj);
                }
                else
                {
                    response.Success = false;
                    response.ResponseString = "Invalid Model";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }

        [HttpPost]
        public async Task<JsonResult> Post([FromBody] UserViewModel model)
        {
            Response response = new Data.Response();
            try
            {
                if (ModelState.IsValid)
                {
                    Data.DataModel.User obj = new Data.DataModel.User();
                    obj.UserId = 0;
                    obj.EmailAddress = model.EmailAddress;
                    obj.PasswordHash = model.PasswordHash;
                    obj.FirstName = model.FirstName;
                    obj.LastName = model.LastName;
                    obj.DateOfBirth = model.DateOfBirth;
                    obj.PlaceOfBirth = model.PlaceOfBirth;
                    obj.Mobile = model.Mobile;
                    obj.DateFormat = model.DateFormat;
                    obj.ProfilePhotoUrl = model.ProfilePhotoUrl;

                    var newUser = objUserBL.UserAdd(obj);

                    if (!newUser.Success)
                        return Json(newUser);

                    var emailVerifyToken = $"{obj.UserId}|{obj.EmailAddress}";
                    var emailVerifyTokenEncrypted = objEncryptionHelper.Encrypt(emailVerifyToken);
                    
                    await objEmailGenerator.SendEmailVerificationEmail(
                        obj.EmailAddress,
                        obj.FirstName,
                        emailVerifyTokenEncrypted,
                        model.InviteToken);

                    return Json(newUser);
                }
                else
                {
                    response.Success = false;
                    response.ResponseString = "Invalid Model";
                }

            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }

        [HttpPost("verify")]
        public async Task<JsonResult> Verify([FromBody] string token)
        {

            Response response = new Data.Response();
            try
            {
                var emailVerifyToken = objEncryptionHelper.Decrypt(token);
                var tokenParts = emailVerifyToken.Split('|');
                int userId;

                if (tokenParts.Length == 2 && int.TryParse(tokenParts[0], out userId) && !string.IsNullOrEmpty(tokenParts[1]))
                {
                    var emailAddress = tokenParts[1];

                    response = await objUserBL.SetEmailAddressVerified(userId);
                }
                else
                {
                    response.Success = false;
                    response.ResponseString = "Unable to validate email verification token";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString= ex.Message;
            }
            return Json(response);
        }

        [HttpPost("resetpassword")]
        public async Task<JsonResult> ResetPassword([FromBody] string email)
        {
            Response response = new Data.Response();
            try
            {
                if (string.IsNullOrEmpty(email))
                    throw new InvalidOperationException("Email address is required");

                var userResult = await objUserBL.GetUserByEmail(email);

                if (!userResult.Success)
                    return Json(userResult);

                var passwordResetToken = $"{userResult.Object.UserId}|{userResult.Object.EmailAddress}";
                var passwordResetTokenEncrypted = objEncryptionHelper.Encrypt(passwordResetToken);

                var result = await objEmailGenerator.SendPasswordResetEmail(
                    userResult.Object.EmailAddress,
                    userResult.Object.FirstName,
                    passwordResetTokenEncrypted);

                if (result == true)
                {
                    response.Success = true;
                }
                else
                {
                    response.Success = false;
                    response.ResponseString = "A has occured while attempting to send an email.";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }

            return Json(response);
        }

        [HttpPost("updatepassword")]
        public async Task<JsonResult> UpdatePassword([FromBody] PasswordUpdateModel model)
        {
            Response response = new Data.Response();
            try
            {
                var passwordUpdateToken = objEncryptionHelper.Decrypt(model.Token);
                var tokenParts = passwordUpdateToken.Split('|');
                int userId;

                if (tokenParts.Length == 2 && int.TryParse(tokenParts[0], out userId) && !string.IsNullOrEmpty(tokenParts[1]))
                {
                    var result = await objUserBL.UserPasswordUpdate(userId, model.Password);
                    return Json(result);
                }

                response.Success = false;
                response.ResponseString = "Unable to validate password update token";
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }

            return Json(response);
        }

        [Authorize]
        [HttpPost("redeeminvitation")]
        public async Task<JsonResult> RedeemInvitation([FromBody] string token)
        {
            Response response = new Data.Response();
            try
            {
                int userId = Convert.ToInt32(User.Claims.SingleOrDefault(c => c.Type == "name").Value);

                var memoryIniteToken = objEncryptionHelper.Decrypt(token);
                var tokenParts = memoryIniteToken.Split('|');
                int userRelationId, memoryId;

                if (tokenParts.Length == 3
                    && int.TryParse(tokenParts[0], out userRelationId)
                    && int.TryParse(tokenParts[1], out memoryId)
                    && !string.IsNullOrEmpty(tokenParts[2]))
                {
                    var emailAddress = tokenParts[2];

                    await objUserBL.AssociateUserRelations(userRelationId, userId);

                    response.Success = true;
                    response.Object = new
                    {
                        MemoryId = memoryId
                    };
                }
                else
                {
                    response.Success = false;
                    response.ResponseString = "Unable to redeem memory invitation token";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return Json(response);
        }
    }
}
