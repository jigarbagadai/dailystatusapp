﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Server.Infrastructure.Utility
{
    public class EncryptionHelper
    {

        private const string EncryptionKey = "Idv418Kw";

        private byte[] _key = { };
        private readonly byte[] _iv = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef };

        public string Decrypt(string stringToDecrypt)
        {
            try
            {
                _key = Encoding.UTF8.GetBytes(EncryptionKey);
                var inputByteArray = UrlDecode(stringToDecrypt);
                using (var des = new DESCryptoServiceProvider())
                using (var ms = new MemoryStream())
                using (var cs = new CryptoStream(ms, des.CreateDecryptor(_key, _iv), CryptoStreamMode.Write))
                {
                    cs.Write(inputByteArray, 0, inputByteArray.Length);
                    cs.FlushFinalBlock();
                    var encoding = Encoding.UTF8;
                    return encoding.GetString(ms.ToArray());
                }
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string Encrypt(string stringToEncrypt)
        {
            try
            {
                _key = Encoding.UTF8.GetBytes(EncryptionKey);
                var inputByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
                using (var des = new DESCryptoServiceProvider())
                using (var ms = new MemoryStream())
                using (var cs = new CryptoStream(ms, des.CreateEncryptor(_key, _iv), CryptoStreamMode.Write))
                {
                    cs.Write(inputByteArray, 0, inputByteArray.Length);
                    cs.FlushFinalBlock();
                    return UrlEncode(ms.ToArray());
                }
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }


        public string UrlEncode(byte[] bytes)
        {
            var returnVal = Convert.ToBase64String(bytes);
            return returnVal.TrimEnd('=').Replace('+', '-').Replace('/', '_');
        }

        public byte[] UrlDecode(string str)
        {
            if (string.IsNullOrEmpty(str))
                return null;

            var decoded = str.Replace('-', '+').Replace('_', '/');

            int paddings = decoded.Length % 4;
            if (paddings > 0)
                decoded += new string('=', 4 - paddings);

            return Convert.FromBase64String(decoded);
        }
    }
}
