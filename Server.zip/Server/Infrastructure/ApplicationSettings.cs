﻿namespace Server.Infrastructure
{
    public class ApplicationSettings
    {
        public string AuthenticationAudience { get; set; }
        public int AuthenticationTimeoutMinutes { get; set; }
        public string ClientHostName { get; set; }
        public string ServerHostName { get; set; }
        public string EmailVerificationPath { get; set; }
        public string PasswordUpdatePath { get; set; }
        public string MemoryInvitationPath { get; set; }
        public string GoogleAnalyticsTrackingId { get; set; }
    }
}
