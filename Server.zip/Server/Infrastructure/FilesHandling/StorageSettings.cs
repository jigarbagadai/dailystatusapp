﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Server.Infrastructure.FilesHandling
{
    public class StorageSettings
    {
        public string AzureStorageKey { get; set; }
        public string AzureStorageConnectionString { get; set; }
    }
}
