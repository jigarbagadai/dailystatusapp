﻿using System.Net;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using SendGrid;
using SendGrid.Helpers.Mail;
using Server.Infrastructure.Emailing.EmailProperties;

namespace Server.Infrastructure.Emailing
{
    public class EmailGenerator
    {

        protected readonly EmailingSettings EmailingSettings;
        protected readonly ApplicationSettings ApplicationSettings;


        public EmailGenerator(
            IOptions<ApplicationSettings> applicationSettings,
            IOptions<EmailingSettings> emailingSettings)
        {
            EmailingSettings = emailingSettings.Value;
            ApplicationSettings = applicationSettings.Value;
        }

        public async Task<bool> SendMemoryNotificationEmail(
            string toEmailAddress,
            string toName
            )
        {
            var client = new SendGridClient(EmailingSettings.SendGridApiKey);
            var fromAddress = new EmailAddress(EmailingSettings.SystemFromEmailAddress, EmailingSettings.SystemFromName);
            var toAddress = new EmailAddress(toEmailAddress, toName);

            var message = new SendGridMessage();
            message.SetFrom(fromAddress);
            message.AddTo(toAddress);
            message.SetTemplateId(EmailingSettings.SendGridMemoryNotificationTemplate);
            message.AddSubstitution("-recipientname-", toName);

            var response = await client.SendEmailAsync(message);
            return response.StatusCode == HttpStatusCode.Accepted;

        }

        public async Task<bool> SendBubbleNotificationEmail(
            string toEmailAddress,
            string toName
            )
        {
            var client = new SendGridClient(EmailingSettings.SendGridApiKey);
            var fromAddress = new EmailAddress(EmailingSettings.SystemFromEmailAddress, EmailingSettings.SystemFromName);
            var toAddress = new EmailAddress(toEmailAddress, toName);

            var message = new SendGridMessage();
            message.SetFrom(fromAddress);
            message.AddTo(toAddress);
            message.SetTemplateId(EmailingSettings.SendGridBubbleNotificationTemplate);
            message.AddSubstitution("-recipientname-", toName);

            var response = await client.SendEmailAsync(message);
            return response.StatusCode == HttpStatusCode.Accepted;

        }

        public async Task<bool> SendEmailVerificationEmail(
            string toEmailAddress,
            string toName,
            string verificationToken,
            string inviteeToken = null)
        {
            var verificationUrl = $"{ApplicationSettings.ClientHostName}" +
                                  $"{ApplicationSettings.EmailVerificationPath}" +
                                  $"/{verificationToken}";

            if (!string.IsNullOrEmpty(inviteeToken))
            {
                verificationUrl += "/" + inviteeToken;
            }

            var client = new SendGridClient(EmailingSettings.SendGridApiKey);
            var fromAddress = new EmailAddress(EmailingSettings.SystemFromEmailAddress, EmailingSettings.SystemFromName);
            var toAddress = new EmailAddress(toEmailAddress, toName);

            var message = new SendGridMessage();
            message.SetFrom(fromAddress);
            message.AddTo(toAddress);
            message.SetTemplateId(EmailingSettings.SendGridEmailVerificationTemplate);
            message.AddSubstitution("-recipientname-", toName);
            message.AddSubstitution("-verificationlink-", verificationUrl);

            var response = await client.SendEmailAsync(message);

            return response.StatusCode == HttpStatusCode.Accepted;
        }

        public async Task<bool> SendPasswordResetEmail(
            string toEmailAddress,
            string toName,
            string resetToken)
        {
            var verificationUrl = $"{ApplicationSettings.ClientHostName}" +
                                  $"{ApplicationSettings.PasswordUpdatePath}" +
                                  $"/{resetToken}";

            var client = new SendGridClient(EmailingSettings.SendGridApiKey);
            var fromAddress = new EmailAddress(EmailingSettings.SystemFromEmailAddress, EmailingSettings.SystemFromName);
            var toAddress = new EmailAddress(toEmailAddress, toName);

            var message = new SendGridMessage();
            message.SetFrom(fromAddress);
            message.AddTo(toAddress);
            message.SetTemplateId(EmailingSettings.SendGridPasswordResetTemplate);
            message.AddSubstitution("-recipientname-", toName);
            message.AddSubstitution("-resetlink-", verificationUrl);

            var response = await client.SendEmailAsync(message);

            return response.StatusCode == HttpStatusCode.Accepted;
        }

        public async Task<bool> SendMemoryInvitationEmail(
            string toEmailAddress,
            string toName,
            MemoryInvitation emailProperties)
        {
            var inviteeUrl = $"{ApplicationSettings.ClientHostName}" +
                             $"{ApplicationSettings.MemoryInvitationPath}" +
                             $"/{emailProperties.InviteeToken}";

            var client = new SendGridClient(EmailingSettings.SendGridApiKey);
            var fromAddress = new EmailAddress(EmailingSettings.SystemFromEmailAddress, emailProperties.OwnerName);
            var toAddress = new EmailAddress(toEmailAddress, toName);

            var message = new SendGridMessage();
            message.SetFrom(fromAddress);
            message.AddTo(toAddress);
            message.SetTemplateId(EmailingSettings.SendGridMemoryInvitationTemplate);
            message.AddSubstitution("-recipientname-", emailProperties.RecipientName);
            message.AddSubstitution("-title-", emailProperties.Title);
            message.AddSubstitution("-location-", emailProperties.Location);
            message.AddSubstitution("-date-", emailProperties.Date);
            message.AddSubstitution("-people-", emailProperties.People);
            message.AddSubstitution("-details-", emailProperties.Details);
            message.AddSubstitution("-inviteelink-", inviteeUrl);
            message.AddSubstitution("-ownername-", emailProperties.OwnerName);

            var response = await client.SendEmailAsync(message);

            return response.StatusCode == HttpStatusCode.Accepted;
        }

    }
}
