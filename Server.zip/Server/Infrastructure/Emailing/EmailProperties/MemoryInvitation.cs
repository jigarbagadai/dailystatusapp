﻿namespace Server.Infrastructure.Emailing.EmailProperties
{
    public class MemoryInvitation
    {
        public int MemoryId { get; set; }
        public string RecipientName { get; set; }
        public string Title { get; set; }
        public string Location { get; set; }
        public string Date { get; set; }
        public string People { get; set; }
        public string Details { get; set; }
        public string InviteeToken { get; set; }
        public string OwnerName { get; set; }
    }
}
