﻿namespace Server.Infrastructure.Emailing
{
    public class EmailingSettings
    {
        public string SystemFromEmailAddress { get; set; }
        public string SystemFromName { get; set; }
        public string SendGridApiKey { get; set; }
        public string SendGridEmailVerificationTemplate { get; set; }
        public string SendGridPasswordResetTemplate { get; set; }
        public string SendGridMemoryInvitationTemplate { get; set; }
        public string SendGridMemoryNotificationTemplate { get; set; }
        public string SendGridBubbleNotificationTemplate { get; set; }
    }
}
