﻿using System;

namespace Server.Infrastructure.Search
{
    public static class StringExtensions
    {
        public static bool IgnoreCaseContains(this string source, string toCheck)
        {
            return source != null && toCheck != null && source.IndexOf(toCheck, StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }
}
