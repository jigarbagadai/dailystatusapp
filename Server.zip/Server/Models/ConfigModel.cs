﻿namespace Server.Models
{
    public class ConfigModel
    {
        public string GoogleAnalyticsTrackingId { get; set; }
    }
}
