﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Server.Models
{
    public class MemoryBubbleUserViewModel
    {
        public int MemoryBubbleId { get; set; }
        public bool IsSavedToTimeline { get; set; }
        public bool IsBookmarked { get; set; }
    }
}
