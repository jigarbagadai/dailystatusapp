﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Server.Models
{
    public class UserRelationViewModel
    {
        public int? UserRelationId { get; set; }
        public int? UserId { get; set; }
        public int? RelationUserId { get; set; }
        public string RelationshipType { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string ScreenName { get; set; }
        public bool TimelineShared { get; set; }
    }
}
