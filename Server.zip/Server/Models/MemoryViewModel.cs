﻿using System.Collections.Generic;
namespace Server.Models
{
    public class MemoryViewModel
    {
        public int? MemoryId { get; set; }
        public int CategoryId { get; set; }
        public System.DateTime Date { get; set; }
        public string DateText { get; set; }
        public string Location { get; set; }
        public LocationModel LocationModel { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public List<MemoryAttachmentViewModel> lstMemoryAttachment { get; set; }
        public List<int> lstPeople { get; set; }
    }
    public class LocationModel
    {
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }
    public class MemoryAttachmentViewModel {
        public int? MemoryAttachmentId { get; set; }
        public int? MemoryId { get; set; }
        public string FileName { get; set; }
        public string FileIdentifier { get; set; }
        public string AttachmentUrl { get; set; }
    }
}
