﻿namespace Server.Models
{
    public class AccessUnauthMemoryViewModel
    {
        public string AccessToken { get; set; }
    }
}
