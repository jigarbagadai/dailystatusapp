﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Server.Models
{
    public class FilterMemoryModel
    {
        public int CategoryId { get; set; }
        public DateTime? DateTIme { get; set; }
        public string Location { get; set; }
        public int? UserRelationId { get; set; }
    }
}
