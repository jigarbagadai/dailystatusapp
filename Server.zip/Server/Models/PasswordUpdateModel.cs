﻿namespace Server.Models
{
    public class PasswordUpdateModel
    {
        public string Password { get; set; }
        public string Token { get; set; }
    }
}
