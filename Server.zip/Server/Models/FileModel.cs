﻿using Newtonsoft.Json;

namespace Server.Models
{
    public class FileModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
        public string ContentType { get; set; }
    }
}
