﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Server.Models
{
    public class MemoryBubbleViewModel
    {
        public int MemoryBubbleId { get; set; }
        public int MemoryId { get; set; }
        public string Description { get; set; }
        public List<BubbleAttachmentViewModel> lstBubbleAttachments { get; set; }
        public List<int> lstBubblePeople { get; set; }
    }
    public class BubbleAttachmentViewModel
    {
        public int? BubbleAttachmentId { get; set; }
        public int? MemoryBubbleId { get; set; }
        public string FileName { get; set; }
        public string FileIdentifier { get; set; }
        public string AttachmentUrl { get; set; }
    }
}
