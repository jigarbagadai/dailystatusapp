﻿using System;

namespace Server.Models
{
    public class TimelineMemoryModel
    {
        public int MemoryId { get; set; }
        public string CategoryIconUrl { get; set; }
        public DateTime Timestamp { get; set; }
        public int BubbleCount { get; set; }
    }
}
