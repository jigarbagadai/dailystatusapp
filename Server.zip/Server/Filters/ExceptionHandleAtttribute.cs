﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using NLog;
using Server.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Server.Filters
{
    public class ExceptionHandleAtttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            LogManager.GetCurrentClassLogger().Error(context.Exception, context.Exception.Message);

            Response response = new Data.Response();
            response.Success = false;
            response.ResponseString = context.Exception.Message;
            context.Result = new JsonResult(response);
            base.OnException(context);
        }
    }
}
