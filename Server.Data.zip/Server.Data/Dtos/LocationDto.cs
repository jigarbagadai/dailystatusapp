﻿
namespace Server.Data.Dtos
{
    public class LocationDto
    {
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }
}
