﻿using System;

namespace Server.Data.Dtos
{
    public class TimelineUserDto
    {
        public int UserId { get; set; }
        public string EmailAddress { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string PlaceOfBirth { get; set; }
        public string Mobile { get; set; }
        public string DateFormat { get; set; }
        public string ProfilePhotoUrl { get; set; }
    }
}
