﻿using System.Collections.Generic;

namespace Server.Data.Dtos
{
    public class TimelineMemoryDto
    {
        public int MemoryId { get; set; }
        public int OwnerId { get; set; }
        public int CategoryId { get; set; }
        public string CategoryIconUrl { get; set; }
        public System.DateTime Date { get; set; }
        public string DateText { get; set; }
        public string Location { get; set; }
        public int[] UserRelationIds { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public IEnumerable<TimelineMemoryBubbleDto> MemoryBubbles { get; set; }
    }
}
