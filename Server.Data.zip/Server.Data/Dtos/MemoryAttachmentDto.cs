﻿
namespace Server.Data.Dtos
{
    public class MemoryAttachmentDto
    {
        public int MemoryAttachmentId { get; set; }
        public int MemoryId { get; set; }
        public string FileName { get; set; }
        public string FileIdentifier { get; set; }
        public string AttachmentUrl { get; set; }
    }
}
