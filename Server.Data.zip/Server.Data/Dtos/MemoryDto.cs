﻿
using System.Collections.Generic;

namespace Server.Data.Dtos
{
    public class MemoryDto
    {
        public int MemoryId { get; set; }
        public int OwnerId { get; set; }
        public string OwnerName { get; set; }
        public string OwnerProfilePhotoUrl { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public System.DateTime Date { get; set; }
        public string DateText { get; set; }
        public string Location { get; set; }
        public LocationDto LocationModel { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public IEnumerable<MemoryAttachmentDto> lstMemoryAttachment { get; set; }
        public IEnumerable<MemoryPersonDto> lstPeople { get; set; }
        public bool SavedToTimeline { get; set; }
        public bool Bookmarked { get; set; }
    }
}
