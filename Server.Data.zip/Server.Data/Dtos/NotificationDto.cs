﻿
namespace Server.Data.Dtos
{
    public class NotificationDto
    {
        public string Type { get; set; }
        public string Description { get; set; }
        public int Param1 { get; set; }
        public int Param2 { get; set; }
    }
}
