﻿
namespace Server.Data.Dtos
{
    public class MemoryInviteeDto
    {
        public int UserRelationId { get; set; }
        public string FirstName { get; set; }
        public string EmailAddress { get; set; }
        public string ScreenName { get; set; }
    }
}
