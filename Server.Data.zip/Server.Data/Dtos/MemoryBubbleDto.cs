﻿
using System.Collections.Generic;

namespace Server.Data.Dtos
{
    public class MemoryBubbleDto : MemoryDto
    {
        public int MemoryBubbleId { get; set; }
        public string BubbleDescription { get; set; }
        public bool BubbleSavedToTimeline { get; set; }
        public bool BubbleBookmarked { get; set; }
        public int BubbleOwnerId { get; set; }
        public string BubbleOwnerName { get; set; }
        public string BubbleOwnerProfilePhotoUrl { get; set; }
        public IEnumerable<MemoryBubbleAttachmentDto> lstMemoryBubbleAttachment { get; set; }
        public IEnumerable<MemoryBubblePersonDto> lstBubblePeople { get; set; }

        public MemoryBubbleDto()
        {
        }

        public MemoryBubbleDto(MemoryDto memory)
        {
            MemoryId = memory.MemoryId;
            OwnerId = memory.OwnerId;
            OwnerName = memory.OwnerName;
            OwnerProfilePhotoUrl = memory.OwnerProfilePhotoUrl;
            CategoryId = memory.CategoryId;
            CategoryName = memory.CategoryName;
            Date = memory.Date;
            DateText = memory.DateText;
            Location = memory.Location;
            LocationModel = memory.LocationModel;
            Title = memory.Title;
            Description = memory.Description;
            lstMemoryAttachment = memory.lstMemoryAttachment;
            lstPeople = memory.lstPeople;
            SavedToTimeline = memory.SavedToTimeline;
            Bookmarked = memory.Bookmarked;
        }
    }
}
