﻿
namespace Server.Data.Dtos
{
    public class TimelineQueryDto
    {
        public int TimelineUserId { get; set; }
        public string SearchTerm { get; set; }
        public TimelineFilterDto[] Filters { get; set; }
    }

    public class TimelineFilterDto
    {
        public string Type { get; set; }
        public string Value { get; set; }
    }
}
