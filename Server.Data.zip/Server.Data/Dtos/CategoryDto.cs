﻿namespace Server.Data.Dtos
{
    public class CategoryDto
    {
        public int CategoryId { get; set; }
        public int? OwnerId { get; set; }
        public string Name { get; set; }
        public string IconUrl { get; set; }
    }
}
