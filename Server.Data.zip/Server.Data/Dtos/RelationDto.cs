﻿
namespace Server.Data.Dtos
{
    public class RelationDto
    {
        public int UserRelationId { get; set; }
        public int UserId { get; set; }
        public int? RelationUserId { get; set; }
        public string RelationshipType { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string ScreenName { get; set; }
        public bool TimelineShared { get; set; }
    }
}
