﻿namespace Server.Data.Dtos
{
    public class MemoryBubblePersonDto
    {
        public int MemoryBubbleUserId { get; set; }
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public bool? IsEmailSent { get; set; }
        public string UserEmailAddress { get; set; }
    }
}