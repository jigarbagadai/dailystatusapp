﻿namespace Server.Data.Dtos
{
    public class TimelineMemoryBubbleDto
    {
        public int MemoryBubbleId { get; set; }
        public int MemoryId { get; set; }
        public string Description { get; set; }
    }
}
