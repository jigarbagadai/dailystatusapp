﻿
namespace Server.Data.Dtos
{
    public class MemoryBubbleAttachmentDto
    {
        public int BubbleAttachmentId { get; set; }
        public int MemoryBubbleId { get; set; }
        public string FileName { get; set; }
        public string FileIdentifier { get; set; }
        public string AttachmentUrl { get; set; }
    }
}
