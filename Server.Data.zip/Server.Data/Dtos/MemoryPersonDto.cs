﻿
namespace Server.Data.Dtos
{
    public class MemoryPersonDto
    {
        public int MemoryUserId { get; set; }
        public int? UserRelationId { get; set; }
        public int? UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ScreenName { get; set; }
        public bool? IsEmailSent { get; set; }
        public string UserEmailAddress { get; set; }
    }
}
