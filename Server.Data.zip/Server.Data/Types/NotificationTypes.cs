﻿
namespace Server.Data.Types
{
    public static class NotificationTypes
    {
        public static string MemoryBookmark = "memorybookmark";
        public static string BubbleBookmark = "bubblebookmark";
        public static string Memory = "memory";
        public static string Bubble = "bubble";
    }
}
