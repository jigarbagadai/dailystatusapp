﻿namespace Server.Data
{
    public static class BCryptHelper
    {
        public static string SetPassword(string passWord)
        {
            string pwdToHash = passWord + "^Y8~JJ"; // ^Y8~JJ is my hard-coded salt
            string hashToStoreInDatabase = BCrypt.HashPassword(pwdToHash, BCrypt.GenerateSalt());

            return hashToStoreInDatabase;
        }

        public static bool GetPassword(string userEnteredPassword, string hashedPwdFromDatabase)
        {
            return BCrypt.CheckPassword(userEnteredPassword + "^Y8~JJ", hashedPwdFromDatabase);
        }
    }
}
