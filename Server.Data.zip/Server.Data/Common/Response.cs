﻿namespace Server.Data
{
    public class Response
    {
        public bool Success { get; set; }
        public dynamic Object { get; set; }
        public string ResponseString { get; set; }
        public Response()
        {

        }

        public Response(bool success, string respString)
        {
            Success = success;
            ResponseString = respString;
        }
        public Response(bool success, string respString, dynamic obj)
        {
            Success = success;
            ResponseString = respString;
            Object = obj;
        }
    }
}
