﻿using Server.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Server.Data.Dtos;

namespace Server.Data.BAL.UserRelations
{
    public class UserRelationsBL
    {
        MeanderEntities objEntites;
        public UserRelationsBL(MeanderEntities _meanderEntities)
        {
            objEntites = _meanderEntities;
        }

        public async Task<Response> GetAllUserRelation(int userId)
        {
            Response response = new Response();
            try
            {
                var userRelations = await objEntites.UserRelations
                    .Where(ur => ur.UserId == userId)
                    .Select(ur => new RelationDto
                    {
                        UserRelationId = ur.UserRelationId,
                        UserId = ur.UserId,
                        RelationUserId = ur.RelationUserId,
                        RelationshipType = ur.RelationshipType,
                        FirstName = ur.FirstName,
                        LastName = ur.LastName,
                        EmailAddress = ur.EmailAddress,
                        ScreenName = ur.ScreenName,
                        TimelineShared = ur.TimelineShared
                    }).ToListAsync();

                response.Success = true;
                response.Object = userRelations;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<RelationDto> GetUserRelation(int userRelationId)
        {
            var userRelation = await objEntites.UserRelations.FindAsync(userRelationId);
            if (userRelation == null)
                return null;

            return new RelationDto
            {
                UserRelationId = userRelation.UserRelationId,
                UserId = userRelation.UserId,
                RelationUserId = userRelation.RelationUserId,
                RelationshipType = userRelation.RelationshipType,
                FirstName = userRelation.FirstName,
                LastName = userRelation.LastName,
                EmailAddress = userRelation.EmailAddress,
                ScreenName = userRelation.ScreenName,
                TimelineShared = userRelation.TimelineShared
            };
        }

        public async Task<Response> DeleteUserRelation(int userRelationId)
        {
            Response response = new Response();
            try
            {
                response.Success = true;
                UserRelation userRelation = objEntites.UserRelations.FirstOrDefault(m => m.UserRelationId == userRelationId);
                objEntites.UserRelations.Remove(userRelation);
                await objEntites.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<Response> UserRelationAddUpdate(UserRelation obj) { 
            Response response = new Response();
            try
            {
                if (obj.UserRelationId == 0)
                {
                    objEntites.UserRelations.Add(obj);
                }
                else
                {
                    var relation = objEntites.UserRelations.Find(obj.UserRelationId);
                    objEntites.Entry(relation).CurrentValues.SetValues(obj);
                }
                await objEntites.SaveChangesAsync();
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }
    }
}
