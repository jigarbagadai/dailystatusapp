﻿using Server.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Server.Data.Dtos;
using Server.Data.Types;

namespace Server.Data.BAL.DashBoard
{
    public class DashBoardBL
    {
        MeanderEntities objEntites;
        public DashBoardBL(MeanderEntities _meanderEntities)
        {
            objEntites = _meanderEntities;
        }

        public async Task<IList<NotificationDto>> Bookmarks(int userId)
        {
            var memoryBookmarks = await objEntites.MemoryUsers
                .Include(m => m.Memory)
                .Where(mu => mu.UserId == userId && mu.IsBookmarked)
                .Select(mu => new NotificationDto
                {
                    Type = NotificationTypes.MemoryBookmark,
                    Description = "Bookmarked memory: " + mu.Memory.Title,
                    Param1 = mu.MemoryId
                })
                .ToListAsync();

            var bubbleBookmarks = await objEntites.MemoryBubbleUsers
                .Include(mbu => mbu.MemoryBubble)
                .Include(mbu => mbu.MemoryBubble.Memory)
                .Where(mbu => mbu.UserId == userId && mbu.IsBookmarked)
                .Select(mbu => new NotificationDto
                {
                    Type = NotificationTypes.BubbleBookmark,
                    Description = "Bookmarked memory bubble: " + mbu.MemoryBubble.Memory.Title,
                    Param1 = mbu.MemoryBubble.MemoryId,
                    Param2 = mbu.MemoryBubbleId,
                })
                .ToListAsync();

            memoryBookmarks.AddRange(bubbleBookmarks);

            return memoryBookmarks;
        }

        public async Task<IList<NotificationDto>> Notifications(int userId)
        {
            var memoryInvitations = await objEntites.MemoryUsers
                .Include(m => m.Memory)
                .Where(mu => mu.UserId == userId && !mu.IsOpened)
                .Select(mu => new NotificationDto
                {
                    Type = NotificationTypes.Memory,
                    Description = "You have received a Memory: " + mu.Memory.Title,
                    Param1 = mu.MemoryId
                })
                .ToListAsync();

            var bubbleInvitations = await objEntites.MemoryBubbleUsers
                .Include(mbu => mbu.MemoryBubble)
                .Include(mbu => mbu.MemoryBubble.Memory)
                .Where(mbu => mbu.UserId == userId && !mbu.IsOpened)
                .Select(mbu => new NotificationDto
                {
                    Type = NotificationTypes.Bubble,
                    Description = "You have received a Memory Bubble for Memory: " + mbu.MemoryBubble.Memory.Title,
                    Param1 = mbu.MemoryBubble.MemoryId,
                    Param2 = mbu.MemoryBubbleId,
                })
                .ToListAsync();

            memoryInvitations.AddRange(bubbleInvitations);

            return memoryInvitations;
        }

        public async Task<IList<TimelineMemoryDto>> Memories(int userId, bool includeHidden = false)
        {
            // find all the memories that a given user is associated with
            var memories = await (
                from mu in objEntites.MemoryUsers
                join m in objEntites.Memories on mu.MemoryId equals m.MemoryId
                join c in objEntites.Categories on m.CategoryId equals c.CategoryId

                where mu.UserId == userId && (includeHidden || mu.TimelineVisible)

                select new
                {
                    m.MemoryId,
                    m.OwnerId,
                    m.CategoryId,
                    CategoryIconUrl = c.IconUrl,
                    m.Date,
                    m.DateText,
                    m.Location,
                    UserRelationIds = m.MemoryUsers.Select(r => r.UserRelationId),
                    m.Title,
                    m.Description
                }).ToListAsync();

            var memoryIds = memories.Select(m => m.MemoryId).ToArray();

            // find all the bubbles associated with the memories
            // only include if the given user wishes to include it on their timeline
            var bubbles = await (
                from mbu in objEntites.MemoryBubbleUsers
                join mb in objEntites.MemoryBubbles on mbu.MemoryBubbleId equals mb.MemoryBubbleId

                where memoryIds.Contains(mb.MemoryId) && mbu.UserId == userId && mbu.TimelineVisible

                select new
                {
                    mb.MemoryId,
                    mb.MemoryBubbleId,
                    mb.Description
                }).ToListAsync();

            // cast and attach all bubbles to their parent memory
            return memories.Select(m => new TimelineMemoryDto
            {
                MemoryId = m.MemoryId,
                OwnerId = m.OwnerId,
                CategoryId = m.CategoryId,
                CategoryIconUrl = m.CategoryIconUrl,
                Date = m.Date,
                DateText = m.DateText,
                Location = m.Location,
                UserRelationIds = m.UserRelationIds.Where(urId => urId.HasValue).Select(urId => urId.Value).ToArray(),
                Title = m.Title,
                Description = m.Description,
                MemoryBubbles = bubbles.Where(mb => mb.MemoryId == m.MemoryId).Select(mb => new TimelineMemoryBubbleDto
                {
                    MemoryId = mb.MemoryId,
                    MemoryBubbleId = mb.MemoryBubbleId,
                    Description = mb.Description
                })
            }).ToList();
        }

        public async Task<Response> OpenNotification(int userId, NotificationDto notification)
        {
            Response response = new Response();
            try
            {
                if (notification.Type == NotificationTypes.Memory)
                {
                    var memoryUser = await objEntites.MemoryUsers
                        .Where(mu => mu.UserId.HasValue && mu.UserId.Value == userId && mu.MemoryId == notification.Param1)
                        .SingleOrDefaultAsync();
                    if (memoryUser == null)
                        throw new InvalidOperationException("Cannot find memory user");
                    memoryUser.IsOpened = true;
                }
                else if (notification.Type == NotificationTypes.Bubble)
                {
                    var memoryBubbleUser = await objEntites.MemoryBubbleUsers
                        .Where(mbu => mbu.UserId == userId && mbu.MemoryBubbleId == notification.Param2)
                        .SingleOrDefaultAsync();
                    if (memoryBubbleUser == null)
                        throw new InvalidOperationException("Cannot find memory bubble user");
                    memoryBubbleUser.IsOpened = true;
                }

                await objEntites.SaveChangesAsync();

                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }

            return response;
        }

        public async Task<TimelineUserDto> TryViewTimelineUser(int currentUserId, int timelineUserId)
        {
            var timelineUser = await objEntites.UserRelations
                .Where(ur => ur.RelationUserId == currentUserId && ur.UserId == timelineUserId && ur.TimelineShared)
                .Select(ur => ur.User)
                .SingleOrDefaultAsync();

            if (timelineUser == null)
                return null;

            return new TimelineUserDto
            {
                UserId = timelineUser.UserId,
                FirstName = timelineUser.FirstName,
                LastName = timelineUser.LastName,
                DateOfBirth = timelineUser.DateOfBirth,
                PlaceOfBirth = timelineUser.PlaceOfBirth,
                DateFormat = timelineUser.DateFormat,
                ProfilePhotoUrl = timelineUser.ProfilePhotoUrl,
            };
        }
    }
}
