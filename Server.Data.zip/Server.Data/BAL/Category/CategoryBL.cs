﻿using Server.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Server.Data.Dtos;

namespace Server.Data.BAL.Category
{
    public class CategoryBL
    {
        MeanderEntities objEntites;
        public CategoryBL(MeanderEntities _meanderEntities)
        {
            objEntites = _meanderEntities;
        }

        public async Task<Response> GetUserAndSystemCategories(int userId)
        {
            Response response = new Response();
            try
            {
                var results = await objEntites.Categories
                    .Where(c => !c.OwnerId.HasValue || c.OwnerId == userId)
                    .Select(c => new CategoryDto
                    {
                        CategoryId = c.CategoryId,
                        OwnerId = c.OwnerId,
                        Name = c.Name,
                        IconUrl = c.IconUrl
                    })
                    .ToListAsync();

                response.Success = true;
                response.Object = results;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<Response> GetUserCategories(int userId)
        {
            Response response = new Response();
            try
            {
                var results = await objEntites.Categories
                    .Where(c => c.OwnerId == userId)
                    .Select(c => new CategoryDto
                    {
                        CategoryId = c.CategoryId,
                        OwnerId = c.OwnerId,
                        Name = c.Name,
                        IconUrl = c.IconUrl
                    })
                    .ToListAsync();

                response.Success = true;
                response.Object = results;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<Response> CategoryAddUpdate(DataModel.Category obj)
        {
            Response response = new Response();
            try
            {
                if (obj.CategoryId == 0)
                {
                    objEntites.Categories.Add(obj);
                }
                else
                {
                    objEntites.Entry(obj).State = System.Data.Entity.EntityState.Modified;
                }

                await objEntites.SaveChangesAsync();
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public DataModel.Category GetCategory(int categoryId)
        {
            return objEntites.Categories.FirstOrDefault(m => m.CategoryId.Equals(categoryId));
        }

        public async Task<Response> DeleteCategory(int categoryId)
        {
            Response response = new Response();
            try
            {
                response.Success = true;
                DataModel.Category category = objEntites.Categories.FirstOrDefault(m => m.CategoryId == categoryId);
                objEntites.Categories.Remove(category);
                await objEntites.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }
    }
}
