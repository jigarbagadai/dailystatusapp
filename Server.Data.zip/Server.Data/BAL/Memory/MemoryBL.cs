﻿using Server.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Server.Data.Dtos;

namespace Server.Data.BAL
{
    public class MemoryBL
    {
        MeanderEntities objEntites;
        public MemoryBL(MeanderEntities _meanderEntities)
        {
            objEntites = _meanderEntities;
        }

        public async Task<Response> MemoryUpdate(Memory memory, List<MemoryAttachment> memoryAttachment, List<int> lstmemoryUser)
        {
            Response response = new Response();
            try
            {
                objEntites.Entry(memory).State = System.Data.Entity.EntityState.Modified;

                objEntites.MemoryAttachments.RemoveRange(objEntites.MemoryAttachments.Where(m => m.MemoryId == memory.MemoryId));
                objEntites.SaveChanges();
                if (memoryAttachment != null)
                {
                    foreach (MemoryAttachment item in memoryAttachment)
                    {
                        if (item.MemoryId == 0)
                            item.MemoryId = memory.MemoryId;
                        objEntites.MemoryAttachments.Add(item);
                    }
                }

                objEntites.MemoryUsers.RemoveRange(objEntites.MemoryUsers.Where(m => m.MemoryId == memory.MemoryId && m.UserRelationId.HasValue));
                objEntites.SaveChanges();

                if (lstmemoryUser != null)
                {
                    // fetch owners user relations
                    var userRelations = await objEntites.UserRelations
                        .Where(ur => ur.UserId == memory.OwnerId)
                        .ToListAsync();

                    foreach (var userRelationId in lstmemoryUser)
                    {
                        var relation = userRelations.Find(ur => ur.UserRelationId == userRelationId);
                        objEntites.MemoryUsers.Add(new MemoryUser()
                        {
                            MemoryUserId = 0,
                            UserId = relation.RelationUserId, // may be null if user is not registered
                            UserRelationId = userRelationId,
                            MemoryId = memory.MemoryId,
                            IsOpened = false,
                            IsBookmarked = true,
                            TimelineVisible = true,
                            IsEmailSent = false
                        });

                    }
                    await objEntites.SaveChangesAsync();
                }

                await objEntites.SaveChangesAsync();
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }

            return response;
        }

        public async Task<int> MemoryAdd(Memory memory, List<MemoryAttachment> memoryAttachment, List<int> lstmemoryUser)
        {
            if (memory.MemoryId == 0)
            {
                objEntites.Memories.Add(memory);
            }
            else
            {
                objEntites.Entry(memory).State = System.Data.Entity.EntityState.Modified;
            }
            await objEntites.SaveChangesAsync();

            objEntites.MemoryAttachments.RemoveRange(objEntites.MemoryAttachments.Where(m => m.MemoryId == memory.MemoryId));
            await objEntites.SaveChangesAsync();

            if (memoryAttachment != null)
            {
                foreach (MemoryAttachment item in memoryAttachment)
                {
                    if (item.MemoryId == 0)
                    {
                        item.MemoryId = memory.MemoryId;
                    }
                    objEntites.MemoryAttachments.Add(item);
                }
            }
            await objEntites.SaveChangesAsync();

            // add MemoryUser entry for owner
            objEntites.MemoryUsers.Add(new MemoryUser()
            {
                MemoryUserId = 0,
                UserId = memory.OwnerId,
                UserRelationId = null, // users own Memory so no relationship to self
                MemoryId = memory.MemoryId,
                IsOpened = true,
                IsBookmarked = true,
                TimelineVisible = true,
                IsEmailSent = false
            });

            if (lstmemoryUser != null)
            {
                // fetch owners user relations
                var userRelations = await objEntites.UserRelations
                    .Where(ur => ur.UserId == memory.OwnerId)
                    .ToListAsync();

                foreach (var userRelationId in lstmemoryUser)
                {
                    var relation = userRelations.Find(ur => ur.UserRelationId == userRelationId);

                    objEntites.MemoryUsers.Add(new MemoryUser()
                    {
                        MemoryUserId = 0,
                        UserId = relation.RelationUserId, // may be null if user is not registered
                        UserRelationId = userRelationId,
                        MemoryId = memory.MemoryId,
                        IsOpened = false,
                        IsBookmarked = true,
                        TimelineVisible = true
                    });
                }
                await objEntites.SaveChangesAsync();
            }
            return memory.MemoryId;
        }

        public async Task<MemoryDto> GetMemory(int memoryId, int? forUserId = null)
        {
            //return await objEntites.Memories.Where(m => m.MemoryId.Equals(memoryId)).SingleOrDefaultAsync();
            var memory = await objEntites.Memories
                .Where(m => m.MemoryId.Equals(memoryId))
                .Select(m => new MemoryDto
                {
                    MemoryId = m.MemoryId,
                    OwnerId = m.OwnerId,
                    OwnerName = m.User.FirstName + " " + m.User.LastName,
                    OwnerProfilePhotoUrl = m.User.ProfilePhotoUrl,
                    CategoryId = m.CategoryId,
                    CategoryName = m.Category.Name,
                    Date = m.Date,
                    DateText = m.DateText,
                    Location = m.Location,
                    LocationModel = new LocationDto
                    {
                        Latitude = m.latitude,
                        Longitude = m.longitude
                    },
                    Title = m.Title,
                    Description = m.Description,
                }).SingleOrDefaultAsync();

            if (memory == null)
                return null;

            memory.lstMemoryAttachment = await GetMemoryAttachmentByMemoryId(memoryId);

            memory.lstPeople = await GetMemoryPeople(memoryId);

            if (!forUserId.HasValue)
                return memory;

            var memoryUser = await objEntites.MemoryUsers
                .Where(m => m.MemoryId == memoryId && m.UserId.HasValue && m.UserId.Value == forUserId.Value)
                .SingleOrDefaultAsync();

            if (memoryUser == null)
                return memory;

            memory.SavedToTimeline = memoryUser.TimelineVisible;
            memory.Bookmarked = memoryUser.IsBookmarked;

            return memory;
        }

        public async Task<IEnumerable<MemoryAttachmentDto>> GetMemoryAttachmentByMemoryId(int memoryId)
        {
            return await objEntites.MemoryAttachments
                .Where(m => m.MemoryId.Equals(memoryId))
                .Select(ma => new MemoryAttachmentDto
                {
                    MemoryAttachmentId = ma.MemoryAttachmentId,
                    MemoryId = ma.MemoryId,
                    FileName = ma.FileName,
                    FileIdentifier = ma.FileIdentifier,
                    AttachmentUrl = ma.AttachmentUrl
                }).ToListAsync();
        }

        public async Task<IEnumerable<MemoryPersonDto>> GetMemoryPeople(int memoryId)
        {
            return await objEntites.MemoryUsers
                .Include(mu => mu.User)
                .Include(mu => mu.UserRelation)
                .Where(m => m.MemoryId.Equals(memoryId))
                .Select(mu => new MemoryPersonDto
                {
                    MemoryUserId = mu.MemoryUserId,
                    UserRelationId = mu.UserRelationId,
                    UserId = mu.UserId,
                    FirstName = mu.User != null ? mu.User.FirstName : mu.UserRelation.FirstName,
                    LastName = mu.User != null ? mu.User.LastName : mu.UserRelation.LastName,
                    ScreenName = mu.UserRelation.ScreenName,
                    IsEmailSent = mu.IsEmailSent,
                    UserEmailAddress = mu.User != null ? mu.User.EmailAddress : string.Empty
                }).ToListAsync();
        }

        public async Task<Response> UpdateMemoryBubbleUser(int memoryId, int userId, bool isSavedToTimeline, bool isBookmarked)
        {
            Response response = new Response();
            try
            {
                var memoryUsers = await objEntites.MemoryUsers
                    .FirstOrDefaultAsync(m => m.MemoryId == memoryId && m.UserId.HasValue && m.UserId == userId);
                if (memoryUsers == null)
                    throw new InvalidOperationException("Memory user not found");

                memoryUsers.TimelineVisible = isSavedToTimeline;
                memoryUsers.IsBookmarked = isBookmarked;
                await objEntites.SaveChangesAsync();

                response.Success = true;
                response.Object = await GetMemory(memoryId, userId);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public List<SearchMemory_Result> SearchMemory(string searchText, int userId)
        {
            return objEntites.SearchMemory(searchText, userId).ToList();
        }

        public List<FilterMemory_Result> FilterMemory(int? categoryId, DateTime? dt, string location, int? userRalationId, int userId)
        {
            return objEntites.FilterMemory(categoryId, dt, location, userRalationId, userId).ToList();
        }

        public List<GetUserMemoryByUserId_Result> GetUserMemoryByUserId(int userId)
        {
            return objEntites.GetUserMemoryByUserId(userId).ToList();
        }

        public async Task<IEnumerable<MemoryInviteeDto>> GetMemoryInvitees(int memoryId)
        {
            return await objEntites.MemoryUsers
                .Include(mu => mu.UserRelation)
                .Where(mu => mu.MemoryId == memoryId && !mu.UserId.HasValue && mu.UserRelationId.HasValue)
                .Select(mu => new MemoryInviteeDto
                {
                    UserRelationId = mu.UserRelationId.Value,
                    FirstName = mu.UserRelation.FirstName,
                    EmailAddress = mu.UserRelation.EmailAddress,
                    ScreenName = mu.UserRelation.ScreenName,
                }).ToListAsync();
        }

        public async Task UpdateEmailStatus(int memoryUserId)
        {
            var memoryuser = objEntites.MemoryUsers.FirstOrDefault(m=>m.MemoryUserId == memoryUserId);
            memoryuser.IsEmailSent = true;
            await objEntites.SaveChangesAsync();
        }
    }
}
