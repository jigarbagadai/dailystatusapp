﻿using Server.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Server.Data.Dtos;

namespace Server.Data.BAL.MemoryBubble
{
    public class MemoryBubbleBL
    {
        MeanderEntities objEntites;
        MemoryBL _objMemoryBL;

        public MemoryBubbleBL(MeanderEntities _meanderEntities)
        {
            objEntites = _meanderEntities;
            _objMemoryBL = new MemoryBL(objEntites);
        }

        public async Task<Response> MemoryBubbleAdd(int memoryId, int userId, string description, List<MemoryBubbleAttachment> bubbleAttachments, List<int> lstPeopleId)
        {
            Response response = new Response();
            try
            {
                var memoryBubble = new DataModel.MemoryBubble
                {
                    MemoryId = memoryId,
                    OwnerId = userId,
                    Description = description
                };

                objEntites.MemoryBubbles.Add(memoryBubble);
                await objEntites.SaveChangesAsync();

                if (bubbleAttachments != null)
                {
                    foreach (MemoryBubbleAttachment item in bubbleAttachments)
                    {
                        if (item.BubbleId == 0)
                        {
                            item.BubbleId = memoryBubble.MemoryBubbleId;
                        }
                        objEntites.MemoryBubbleAttachments.Add(item);
                    }
                }
                await objEntites.SaveChangesAsync();

                // add current user
                objEntites.MemoryBubbleUsers.Add(new MemoryBubbleUser()
                {
                    MemoryBubbleUserId = 0,
                    UserId = userId,
                    MemoryBubbleId = memoryBubble.MemoryBubbleId,
                    IsOpened = true,
                    IsBookmarked = false,
                    TimelineVisible = true,
                    IsEmailSent = false
                });

                if (lstPeopleId != null)
                {
                    foreach (var item in lstPeopleId)
                    {
                        objEntites.MemoryBubbleUsers.Add(new MemoryBubbleUser()
                        {
                            MemoryBubbleUserId = 0,
                            UserId = item,
                            MemoryBubbleId = memoryBubble.MemoryBubbleId,
                            IsOpened = false,
                            IsBookmarked = false,
                            TimelineVisible = true,
                            IsEmailSent = false
                        });
                    }
                }

                await objEntites.SaveChangesAsync();

                response.Success = true;
                response.Object = await GetUserMemoryBubble(userId, memoryBubble.MemoryBubbleId);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<Response> MemoryBubbleUpdate(int memoryBubbleId, int userId, string description, List<MemoryBubbleAttachment> bubbleAttachments)
        {
            Response response = new Response();
            try
            {
                var memoryBubble = objEntites.MemoryBubbles.Find(memoryBubbleId);

                if (memoryBubble == null)
                    throw new InvalidOperationException("Memory bubble not found");

                objEntites.MemoryBubbleAttachments.RemoveRange(objEntites.MemoryBubbleAttachments.Where(mb => mb.BubbleId == memoryBubbleId));
                objEntites.SaveChanges();

                if (bubbleAttachments != null)
                {
                    foreach (MemoryBubbleAttachment item in bubbleAttachments)
                    {
                        if (item.BubbleId == 0)
                        {
                            item.BubbleId = memoryBubble.MemoryBubbleId;
                        }
                        objEntites.MemoryBubbleAttachments.Add(item);
                    }
                }
                await objEntites.SaveChangesAsync();

                memoryBubble.Description = description;
                await objEntites.SaveChangesAsync();

                response.Success = true;
                response.Object = await GetUserMemoryBubble(userId, memoryBubbleId);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<Response> UpdateMemoryBubbleUser(int memoryBubbleId, int userId, bool isBookmarked, bool isTimelineVisible)
        {
            Response response = new Response();
            try
            {
                var user = objEntites.MemoryBubbleUsers.FirstOrDefault(m => m.MemoryBubbleId.Equals(memoryBubbleId) && m.UserId.Equals(userId));
                if (user == null)
                    throw new InvalidOperationException("Memory bubble user not found");

                user.IsBookmarked = isBookmarked;
                user.TimelineVisible = isTimelineVisible;

                await objEntites.SaveChangesAsync();
                response.Success = true;
                response.Object = await GetUserMemoryBubble(userId, memoryBubbleId);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<Response> GetUserMemoryBubble(int userId, int memoryBubbleId)
        {
            Response response = new Response();
            try
            {
                var memoryBubble = await objEntites.MemoryBubbles
                    .Include(mb => mb.MemoryBubbleUsers)
                    .Include(mb => mb.MemoryBubbleUsers.Select(mbu => mbu.User))
                    .Include(mb => mb.User)
                    .Where(mb => mb.MemoryBubbleId.Equals(memoryBubbleId))
                    .SingleOrDefaultAsync();

                if (memoryBubble == null)
                    throw new InvalidOperationException("Memory bubble not found");

                var memory = await _objMemoryBL.GetMemory(memoryBubble.MemoryId, userId);

                if (memory == null)
                    throw new InvalidOperationException("Memory not found");

                var memoryBubbleUser = memoryBubble.MemoryBubbleUsers
                    .SingleOrDefault(mbu => mbu.MemoryBubbleId == memoryBubbleId && mbu.UserId == userId);
                if (memoryBubbleUser == null)
                    throw new InvalidOperationException("Memory bubble user not found");

                var bubbleAttachments = await GetMemoryBubbleAttachmentsByMemoryId(memoryBubbleId);

                var bubbleUsers = await GetMemoryBubblePeople(memoryBubbleId);

                var result = new MemoryBubbleDto(memory)
                {
                    MemoryBubbleId = memoryBubble.MemoryBubbleId,
                    BubbleDescription = memoryBubble.Description,
                    BubbleSavedToTimeline = memoryBubbleUser.TimelineVisible,
                    BubbleBookmarked = memoryBubbleUser.IsBookmarked,
                    BubbleOwnerId = memoryBubble.User.UserId,
                    BubbleOwnerName = memoryBubble.User.FirstName + " " + memoryBubble.User.LastName,
                    BubbleOwnerProfilePhotoUrl = memoryBubble.User.ProfilePhotoUrl,
                    lstMemoryBubbleAttachment = bubbleAttachments,
                    lstBubblePeople = bubbleUsers
                };

                response.Object = result;
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<Response> GetBubbleSummariesByMemoryId(int userId, int memoryId)
        {
            Response response = new Response();
            try
            {
                var memoryBubbles = await objEntites.MemoryBubbles
                    .Include(mb => mb.User)
                    .Include(mb => mb.MemoryBubbleUsers)
                    .Where(mb => mb.MemoryId.Equals(memoryId) && mb.MemoryBubbleUsers.Any(mbu => mbu.UserId == userId))
                    .Select(mb => new MemoryBubbleDto
                    {
                        MemoryId   = mb.MemoryId,
                        MemoryBubbleId = mb.MemoryBubbleId,
                        BubbleDescription = mb.Description,
                        BubbleOwnerId = mb.OwnerId,
                        BubbleOwnerName = mb.User.FirstName + " " + mb.User.LastName,
                        BubbleOwnerProfilePhotoUrl = mb.User.ProfilePhotoUrl,
                    })
                    .ToListAsync();
                    
                response.Object = memoryBubbles;
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<IEnumerable<MemoryBubbleAttachmentDto>> GetMemoryBubbleAttachmentsByMemoryId(int memoryBubbleId)
        {
            return await objEntites.MemoryBubbleAttachments
                .Where(mb => mb.BubbleId.Equals(memoryBubbleId))
                .Select(ma => new MemoryBubbleAttachmentDto
                {
                    BubbleAttachmentId = ma.BubbleAttachmentId,
                    MemoryBubbleId = ma.BubbleId,
                    FileName = ma.Name,
                    FileIdentifier = ma.FileIdentifier,
                    AttachmentUrl = ma.AttachmentUrl
                }).ToListAsync();
        }

        public async Task<IEnumerable<MemoryBubblePersonDto>> GetMemoryBubblePeople(int memoryBubbleId)
        {
            return await objEntites.MemoryBubbleUsers
                .Include(mbu => mbu.User)
                .Where(mbu => mbu.MemoryBubbleId.Equals(memoryBubbleId))
                .Select(mu => new MemoryBubblePersonDto
                {
                    MemoryBubbleUserId = mu.MemoryBubbleUserId,
                    UserId = mu.User.UserId,
                    FirstName = mu.User.FirstName,
                    LastName = mu.User.LastName,
                    IsEmailSent = mu.IsEmailSent,
                    UserEmailAddress = mu.User != null ? mu.User.EmailAddress : string.Empty
                }).ToListAsync();
        }

        public async Task UpdateEmailStatus(int memoryBubbleUserId)
        {
            var memoryBubbleuser = objEntites.MemoryBubbleUsers.FirstOrDefault(m => m.MemoryBubbleUserId == memoryBubbleUserId);
            memoryBubbleuser.IsEmailSent = true;
            await objEntites.SaveChangesAsync();
        }
    }
}
