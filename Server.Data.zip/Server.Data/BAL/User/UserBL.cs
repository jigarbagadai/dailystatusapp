﻿using Server.Data.DataModel;
using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Server.Data.Dtos;

namespace Server.Data.BAL
{
    public class UserBL
    {
        MeanderEntities objEntites;
        public UserBL(MeanderEntities _meanderEntities)
        {
            objEntites = _meanderEntities;
        }

        public async Task<Response> GetUserByEmail(string emailAddress)
        {
            Response response = new Response();
            try
            {
                var userinfo = await objEntites.Users.FirstOrDefaultAsync(m => m.EmailAddress.Equals(emailAddress));
                if (userinfo == null)
                {
                    response.Success = false;
                }
                else
                {
                    userinfo.PasswordHash = null;
                    response.Success = true;
                    response.Object = new TimelineUserDto
                    {
                        UserId = userinfo.UserId,
                        EmailAddress = userinfo.EmailAddress,
                        FirstName = userinfo.FirstName,
                        LastName = userinfo.LastName,
                        DateOfBirth = userinfo.DateOfBirth,
                        PlaceOfBirth = userinfo.PlaceOfBirth,
                        Mobile = userinfo.Mobile,
                        DateFormat = userinfo.DateFormat,
                        ProfilePhotoUrl = userinfo.ProfilePhotoUrl,
                    };
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }

            return response;
        }

        public async Task<Response> GetUserByUserId(int userId)
        {
            Response response = new Response();
            try
            {
                var user = await objEntites.Users.FindAsync(userId);
                if (user == null)
                {
                    response.Success = false;
                    response.ResponseString = "No user found.";
                }
                else
                {
                    response.Success = true;
                    response.Object = user;
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Object = "An unexpected error occurred.";
            }
            return response;
        }
        public Response Login(string emailAddress, string password)
        {
            Response response = new Response();
            try
            {
                var user = objEntites.Users.SingleOrDefault(m => m.EmailAddress.ToLower().Equals(emailAddress.ToLower()));
                if (user == null)
                {
                    response.Success = false;
                    response.ResponseString = "No user found.";
                }
                else if (user.EmailAddressVerified == null || user.EmailAddressVerified == false)
                {
                    response.Success = false;
                    response.ResponseString = "User is not verfied";
                }
                else
                {
                    if (BCryptHelper.GetPassword(password, user.PasswordHash))
                    {
                        response.Success = true;
                        response.Object = user;
                    }
                    else
                    {
                        response.Success = false;
                        response.ResponseString = "Sorry, Password is in correct";
                    }
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<Response> UserUpdate(User param)
        {
            Response response = new Response();
            try
            {
                if (objEntites.Users.Any(m => m.EmailAddress.Equals(param.EmailAddress) && m.UserId != param.UserId))
                {
                    response.Success = false;
                    response.ResponseString = "Email address already exists.";
                }
                else
                {
                    var user = objEntites.Users.Find(param.UserId);
                    if (user == null)
                    {
                        throw new InvalidOperationException("User not found");
                    }

                    param.PasswordHash = user.PasswordHash;
                    param.EmailAddressVerified = user.EmailAddressVerified;
                    //param.ProfilePhotoUrl = user.ProfilePhotoUrl; // todo remove once file upload complete
                    objEntites.Entry(user).CurrentValues.SetValues(param);
                    await objEntites.SaveChangesAsync();
                    response.Success = true;
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<Response> UserPasswordUpdate(int userId, string newPassword)
        {
            Response response = new Response();
            try
            {
                var user = objEntites.Users.Find(userId);
                if (user == null)
                    throw new InvalidOperationException("User not found");

                user.PasswordHash = BCryptHelper.SetPassword(newPassword);
                await objEntites.SaveChangesAsync();
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<Response> SetEmailAddressVerified(int userId)
        {
            Response response = new Response();
            try
            {
                var obj = objEntites.Users.Where(m => m.UserId.Equals(userId)).FirstOrDefault();
                if (obj != null)
                {
                    obj.EmailAddressVerified = true;
                    await objEntites.SaveChangesAsync();
                    response.Success = true;
                }
                else
                {
                    response.Success = false;
                    response.ResponseString = "User not found";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public Response UserAdd(User param)
        {
            Response response = new Response();
            try
            {
                if (objEntites.Users.Where(m => m.EmailAddress.Equals(param.EmailAddress)).Any())
                {
                    response.Success = false;
                    response.ResponseString = "Email address already exists.";
                }
                else
                {
                    param.PasswordHash = BCryptHelper.SetPassword(param.PasswordHash);
                    objEntites.Users.Add(param);
                    objEntites.SaveChanges();
                    response.Success = true;
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

        public async Task<Response> AssociateUserRelations(int userRelationId, int relationUserId, string inviteeEmail = null)
        {
            Response response = new Response();
            try
            {
                using (var transaction = objEntites.Database.BeginTransaction())
                {
                    // set the relationUserId on the original users UserRelation entry
                    var userRelation = await objEntites.UserRelations.FindAsync(userRelationId);
                    if (userRelation == null)
                        throw new InvalidOperationException("Unknown User Relation id");

                    userRelation.RelationUserId = relationUserId;

                    await objEntites.SaveChangesAsync();

                    // now add the UserRelation for the new user, pointing back to the user who invited them
                    var originalUser = await objEntites.Users.FindAsync(userRelation.UserId);
                    if (originalUser == null)
                        throw new InvalidOperationException("Unknown User id");

                    var returnRelation = await objEntites.UserRelations
                        .Where(ur => ur.UserId == relationUserId && ur.EmailAddress.ToLower() == originalUser.EmailAddress.ToLower())
                        .SingleOrDefaultAsync();

                    if (returnRelation != null)
                    {
                        returnRelation.RelationUserId = originalUser.UserId;
                    }
                    else
                    {
                        returnRelation = new UserRelation
                        {
                            UserId = relationUserId,
                            RelationUserId = originalUser.UserId,
                            RelationshipType = "Friend",
                            FirstName = originalUser.FirstName,
                            LastName = originalUser.LastName,
                            EmailAddress = originalUser.EmailAddress,
                            ScreenName = originalUser.FirstName,
                            TimelineShared = true,
                        };

                        objEntites.UserRelations.Add(returnRelation);
                    }

                    await objEntites.SaveChangesAsync();

                    // now update all the MemoryUser records for the original user
                    var memoryUsers = await objEntites.MemoryUsers.Where(mu => mu.UserRelationId == userRelationId).ToListAsync();
                    foreach (var memoryUser in memoryUsers)
                    {
                        memoryUser.UserId = relationUserId;
                    }

                    await objEntites.SaveChangesAsync();

                    // and update all the MemoryUser records for the new user
                    var returnMemoryUsers = await objEntites.MemoryUsers.Where(mu => mu.UserRelationId == returnRelation.UserRelationId).ToListAsync();
                    foreach (var memoryUser in returnMemoryUsers)
                    {
                        memoryUser.UserId = originalUser.UserId;
                    }

                    await objEntites.SaveChangesAsync();

                    transaction.Commit();
                }

                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.ResponseString = ex.Message;
            }
            return response;
        }

    }
}
