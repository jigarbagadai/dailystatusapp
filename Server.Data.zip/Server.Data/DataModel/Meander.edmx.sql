
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 05/13/2017 14:15:48
-- Generated from EDMX file: D:\Dev\Clients\Meander\MdrWebApp\Server.Data\DataModel\Meander.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [mdr-db-dev1];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_BubbleAttachment_MemoryBubble]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[BubbleAttachments] DROP CONSTRAINT [FK_BubbleAttachment_MemoryBubble];
GO
IF OBJECT_ID(N'[dbo].[FK_MemoryBubbleUsers_MemoryBubble]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MemoryBubbleUsers] DROP CONSTRAINT [FK_MemoryBubbleUsers_MemoryBubble];
GO
IF OBJECT_ID(N'[dbo].[FK_Category_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Categories] DROP CONSTRAINT [FK_Category_User];
GO
IF OBJECT_ID(N'[dbo].[FK_UserRelations_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserRelations] DROP CONSTRAINT [FK_UserRelations_User];
GO
IF OBJECT_ID(N'[dbo].[FK_MemoryUsers_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MemoryUsers] DROP CONSTRAINT [FK_MemoryUsers_User];
GO
IF OBJECT_ID(N'[dbo].[FK_MemoryBubbleUsers_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MemoryBubbleUsers] DROP CONSTRAINT [FK_MemoryBubbleUsers_User];
GO
IF OBJECT_ID(N'[dbo].[FK_Memory_Category]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Memories] DROP CONSTRAINT [FK_Memory_Category];
GO
IF OBJECT_ID(N'[dbo].[FK_Memory_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Memories] DROP CONSTRAINT [FK_Memory_User];
GO
IF OBJECT_ID(N'[dbo].[FK_MemoryAttachment_Memory]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MemoryAttachments] DROP CONSTRAINT [FK_MemoryAttachment_Memory];
GO
IF OBJECT_ID(N'[dbo].[FK_MemoryBubble_Memory]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MemoryBubbles] DROP CONSTRAINT [FK_MemoryBubble_Memory];
GO
IF OBJECT_ID(N'[dbo].[FK_MemoryUsers_Memory]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MemoryUsers] DROP CONSTRAINT [FK_MemoryUsers_Memory];
GO
IF OBJECT_ID(N'[dbo].[FK_MemoryBubble_User]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MemoryBubbles] DROP CONSTRAINT [FK_MemoryBubble_User];
GO
IF OBJECT_ID(N'[dbo].[FK_MemoryUser_UserRelation]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MemoryUsers] DROP CONSTRAINT [FK_MemoryUser_UserRelation];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[BubbleAttachments]', 'U') IS NOT NULL
    DROP TABLE [dbo].[BubbleAttachments];
GO
IF OBJECT_ID(N'[dbo].[Categories]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Categories];
GO
IF OBJECT_ID(N'[dbo].[MemoryAttachments]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MemoryAttachments];
GO
IF OBJECT_ID(N'[dbo].[MemoryBubbles]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MemoryBubbles];
GO
IF OBJECT_ID(N'[dbo].[MemoryBubbleUsers]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MemoryBubbleUsers];
GO
IF OBJECT_ID(N'[dbo].[MemoryUsers]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MemoryUsers];
GO
IF OBJECT_ID(N'[dbo].[UserRelations]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserRelations];
GO
IF OBJECT_ID(N'[dbo].[Users]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Users];
GO
IF OBJECT_ID(N'[dbo].[Memories]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Memories];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'MemoryBubbleAttachments'
CREATE TABLE [dbo].[MemoryBubbleAttachments] (
    [BubbleAttachmentId] int IDENTITY(1,1) NOT NULL,
    [BubbleId] int  NOT NULL,
    [Name] varchar(50)  NOT NULL,
    [FileIdentifier] nvarchar(max)  NOT NULL,
    [AttachmentUrl] varchar(100)  NOT NULL
);
GO

-- Creating table 'Categories'
CREATE TABLE [dbo].[Categories] (
    [CategoryId] int IDENTITY(1,1) NOT NULL,
    [OwnerId] int  NULL,
    [Name] varchar(50)  NOT NULL,
    [IconUrl] varchar(100)  NULL
);
GO

-- Creating table 'MemoryAttachments'
CREATE TABLE [dbo].[MemoryAttachments] (
    [MemoryAttachmentId] int IDENTITY(1,1) NOT NULL,
    [MemoryId] int  NOT NULL,
    [FileName] varchar(50)  NOT NULL,
    [FileIdentifier] nvarchar(max)  NOT NULL,
    [AttachmentUrl] varchar(100)  NOT NULL
);
GO

-- Creating table 'MemoryBubbles'
CREATE TABLE [dbo].[MemoryBubbles] (
    [MemoryBubbleId] int IDENTITY(1,1) NOT NULL,
    [MemoryId] int  NOT NULL,
    [OwnerId] int  NOT NULL,
    [Description] varchar(500)  NOT NULL
);
GO

-- Creating table 'MemoryBubbleUsers'
CREATE TABLE [dbo].[MemoryBubbleUsers] (
    [MemoryBubbleUserId] int IDENTITY(1,1) NOT NULL,
    [UserId] int  NOT NULL,
    [MemoryBubbleId] int  NOT NULL,
    [IsOpened] bit  NOT NULL,
    [IsBookmarked] bit  NOT NULL,
    [TimelineVisible] bit  NOT NULL
);
GO

-- Creating table 'MemoryUsers'
CREATE TABLE [dbo].[MemoryUsers] (
    [MemoryUserId] int IDENTITY(1,1) NOT NULL,
    [UserId] int  NULL,
    [UserRelationId] int  NULL,
    [MemoryId] int  NOT NULL,
    [IsOpened] bit  NOT NULL,
    [IsBookmarked] bit  NOT NULL,
    [TimelineVisible] bit  NOT NULL
);
GO

-- Creating table 'UserRelations'
CREATE TABLE [dbo].[UserRelations] (
    [UserRelationId] int IDENTITY(1,1) NOT NULL,
    [UserId] int  NOT NULL,
    [RelationUserId] int  NULL,
    [RelationshipType] varchar(50)  NOT NULL,
    [FirstName] varchar(50)  NOT NULL,
    [LastName] varchar(50)  NOT NULL,
    [EmailAddress] varchar(50)  NOT NULL,
    [ScreenName] varchar(50)  NOT NULL,
    [TimelineShared] bit  NOT NULL
);
GO

-- Creating table 'Users'
CREATE TABLE [dbo].[Users] (
    [UserId] int IDENTITY(1,1) NOT NULL,
    [EmailAddress] varchar(50)  NOT NULL,
    [PasswordHash] varchar(max)  NOT NULL,
    [FirstName] varchar(50)  NOT NULL,
    [LastName] varchar(50)  NOT NULL,
    [DateOfBirth] datetime  NULL,
    [PlaceOfBirth] varchar(50)  NULL,
    [Mobile] varchar(10)  NULL,
    [DateFormat] varchar(50)  NULL,
    [ProfilePhotoUrl] varchar(100)  NULL,
    [EmailAddressVerified] bit  NULL
);
GO

-- Creating table 'Memories'
CREATE TABLE [dbo].[Memories] (
    [MemoryId] int IDENTITY(1,1) NOT NULL,
    [OwnerId] int  NOT NULL,
    [CategoryId] int  NOT NULL,
    [Date] datetime  NOT NULL,
    [Location] varchar(50)  NOT NULL,
    [latitude] varchar(50)  NOT NULL,
    [longitude] varchar(50)  NOT NULL,
    [Title] varchar(50)  NOT NULL,
    [Description] varchar(500)  NOT NULL,
    [DateText] varchar(100)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [BubbleAttachmentId] in table 'MemoryBubbleAttachments'
ALTER TABLE [dbo].[MemoryBubbleAttachments]
ADD CONSTRAINT [PK_MemoryBubbleAttachments]
    PRIMARY KEY CLUSTERED ([BubbleAttachmentId] ASC);
GO

-- Creating primary key on [CategoryId] in table 'Categories'
ALTER TABLE [dbo].[Categories]
ADD CONSTRAINT [PK_Categories]
    PRIMARY KEY CLUSTERED ([CategoryId] ASC);
GO

-- Creating primary key on [MemoryAttachmentId] in table 'MemoryAttachments'
ALTER TABLE [dbo].[MemoryAttachments]
ADD CONSTRAINT [PK_MemoryAttachments]
    PRIMARY KEY CLUSTERED ([MemoryAttachmentId] ASC);
GO

-- Creating primary key on [MemoryBubbleId] in table 'MemoryBubbles'
ALTER TABLE [dbo].[MemoryBubbles]
ADD CONSTRAINT [PK_MemoryBubbles]
    PRIMARY KEY CLUSTERED ([MemoryBubbleId] ASC);
GO

-- Creating primary key on [MemoryBubbleUserId] in table 'MemoryBubbleUsers'
ALTER TABLE [dbo].[MemoryBubbleUsers]
ADD CONSTRAINT [PK_MemoryBubbleUsers]
    PRIMARY KEY CLUSTERED ([MemoryBubbleUserId] ASC);
GO

-- Creating primary key on [MemoryUserId] in table 'MemoryUsers'
ALTER TABLE [dbo].[MemoryUsers]
ADD CONSTRAINT [PK_MemoryUsers]
    PRIMARY KEY CLUSTERED ([MemoryUserId] ASC);
GO

-- Creating primary key on [UserRelationId] in table 'UserRelations'
ALTER TABLE [dbo].[UserRelations]
ADD CONSTRAINT [PK_UserRelations]
    PRIMARY KEY CLUSTERED ([UserRelationId] ASC);
GO

-- Creating primary key on [UserId] in table 'Users'
ALTER TABLE [dbo].[Users]
ADD CONSTRAINT [PK_Users]
    PRIMARY KEY CLUSTERED ([UserId] ASC);
GO

-- Creating primary key on [MemoryId] in table 'Memories'
ALTER TABLE [dbo].[Memories]
ADD CONSTRAINT [PK_Memories]
    PRIMARY KEY CLUSTERED ([MemoryId] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [BubbleId] in table 'MemoryBubbleAttachments'
ALTER TABLE [dbo].[MemoryBubbleAttachments]
ADD CONSTRAINT [FK_BubbleAttachment_MemoryBubble]
    FOREIGN KEY ([BubbleId])
    REFERENCES [dbo].[MemoryBubbles]
        ([MemoryBubbleId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_BubbleAttachment_MemoryBubble'
CREATE INDEX [IX_FK_BubbleAttachment_MemoryBubble]
ON [dbo].[MemoryBubbleAttachments]
    ([BubbleId]);
GO

-- Creating foreign key on [MemoryBubbleId] in table 'MemoryBubbleUsers'
ALTER TABLE [dbo].[MemoryBubbleUsers]
ADD CONSTRAINT [FK_MemoryBubbleUsers_MemoryBubble]
    FOREIGN KEY ([MemoryBubbleId])
    REFERENCES [dbo].[MemoryBubbles]
        ([MemoryBubbleId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MemoryBubbleUsers_MemoryBubble'
CREATE INDEX [IX_FK_MemoryBubbleUsers_MemoryBubble]
ON [dbo].[MemoryBubbleUsers]
    ([MemoryBubbleId]);
GO

-- Creating foreign key on [OwnerId] in table 'Categories'
ALTER TABLE [dbo].[Categories]
ADD CONSTRAINT [FK_Category_User]
    FOREIGN KEY ([OwnerId])
    REFERENCES [dbo].[Users]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Category_User'
CREATE INDEX [IX_FK_Category_User]
ON [dbo].[Categories]
    ([OwnerId]);
GO

-- Creating foreign key on [UserId] in table 'UserRelations'
ALTER TABLE [dbo].[UserRelations]
ADD CONSTRAINT [FK_UserRelations_User]
    FOREIGN KEY ([UserId])
    REFERENCES [dbo].[Users]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_UserRelations_User'
CREATE INDEX [IX_FK_UserRelations_User]
ON [dbo].[UserRelations]
    ([UserId]);
GO

-- Creating foreign key on [UserId] in table 'MemoryUsers'
ALTER TABLE [dbo].[MemoryUsers]
ADD CONSTRAINT [FK_MemoryUsers_User]
    FOREIGN KEY ([UserId])
    REFERENCES [dbo].[Users]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MemoryUsers_User'
CREATE INDEX [IX_FK_MemoryUsers_User]
ON [dbo].[MemoryUsers]
    ([UserId]);
GO

-- Creating foreign key on [UserId] in table 'MemoryBubbleUsers'
ALTER TABLE [dbo].[MemoryBubbleUsers]
ADD CONSTRAINT [FK_MemoryBubbleUsers_User]
    FOREIGN KEY ([UserId])
    REFERENCES [dbo].[Users]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MemoryBubbleUsers_User'
CREATE INDEX [IX_FK_MemoryBubbleUsers_User]
ON [dbo].[MemoryBubbleUsers]
    ([UserId]);
GO

-- Creating foreign key on [CategoryId] in table 'Memories'
ALTER TABLE [dbo].[Memories]
ADD CONSTRAINT [FK_Memory_Category]
    FOREIGN KEY ([CategoryId])
    REFERENCES [dbo].[Categories]
        ([CategoryId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Memory_Category'
CREATE INDEX [IX_FK_Memory_Category]
ON [dbo].[Memories]
    ([CategoryId]);
GO

-- Creating foreign key on [OwnerId] in table 'Memories'
ALTER TABLE [dbo].[Memories]
ADD CONSTRAINT [FK_Memory_User]
    FOREIGN KEY ([OwnerId])
    REFERENCES [dbo].[Users]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Memory_User'
CREATE INDEX [IX_FK_Memory_User]
ON [dbo].[Memories]
    ([OwnerId]);
GO

-- Creating foreign key on [MemoryId] in table 'MemoryAttachments'
ALTER TABLE [dbo].[MemoryAttachments]
ADD CONSTRAINT [FK_MemoryAttachment_Memory]
    FOREIGN KEY ([MemoryId])
    REFERENCES [dbo].[Memories]
        ([MemoryId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MemoryAttachment_Memory'
CREATE INDEX [IX_FK_MemoryAttachment_Memory]
ON [dbo].[MemoryAttachments]
    ([MemoryId]);
GO

-- Creating foreign key on [MemoryId] in table 'MemoryBubbles'
ALTER TABLE [dbo].[MemoryBubbles]
ADD CONSTRAINT [FK_MemoryBubble_Memory]
    FOREIGN KEY ([MemoryId])
    REFERENCES [dbo].[Memories]
        ([MemoryId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MemoryBubble_Memory'
CREATE INDEX [IX_FK_MemoryBubble_Memory]
ON [dbo].[MemoryBubbles]
    ([MemoryId]);
GO

-- Creating foreign key on [MemoryId] in table 'MemoryUsers'
ALTER TABLE [dbo].[MemoryUsers]
ADD CONSTRAINT [FK_MemoryUsers_Memory]
    FOREIGN KEY ([MemoryId])
    REFERENCES [dbo].[Memories]
        ([MemoryId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MemoryUsers_Memory'
CREATE INDEX [IX_FK_MemoryUsers_Memory]
ON [dbo].[MemoryUsers]
    ([MemoryId]);
GO

-- Creating foreign key on [OwnerId] in table 'MemoryBubbles'
ALTER TABLE [dbo].[MemoryBubbles]
ADD CONSTRAINT [FK_MemoryBubble_User]
    FOREIGN KEY ([OwnerId])
    REFERENCES [dbo].[Users]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MemoryBubble_User'
CREATE INDEX [IX_FK_MemoryBubble_User]
ON [dbo].[MemoryBubbles]
    ([OwnerId]);
GO

-- Creating foreign key on [UserRelationId] in table 'MemoryUsers'
ALTER TABLE [dbo].[MemoryUsers]
ADD CONSTRAINT [FK_MemoryUser_UserRelation]
    FOREIGN KEY ([UserRelationId])
    REFERENCES [dbo].[UserRelations]
        ([UserRelationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_MemoryUser_UserRelation'
CREATE INDEX [IX_FK_MemoryUser_UserRelation]
ON [dbo].[MemoryUsers]
    ([UserRelationId]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------