
# Meander Web App

## INSTALLATION

Project configuration loosely base on this tutorial:
https://devblog.dymel.pl/2016/10/25/angular2-cli-with-aspnet-core-application-tutorial/

1. Install Git
https://git-scm.com/downloads

2. Install NodeJS (works with version 6.10.0)
https://nodejs.org/en/download/current/

3. Install Visual Studio 2015
https://www.microsoft.com/net/core#windowsvs2015 (Step 1)

4. Install the .NET Core (1.1.1) tools preview for Visual Studio
https://www.microsoft.com/net/download/core (Step 2)

5. Install Angular CLI
npm install -g angular-cli

6. Install node-sass
npm install -g node-sass

7. Optional: Install Visual Studio Code to run client app (recommended)


## ARCHITECTURE
The Meander Web App is a .NET Core (C#) server-side application running with an Angular2 front-end. The server persists data to a SQL Server database and uses Entity Framework as the ORM.  

Projects:  
Server - the .NET server app which hosts the API endpoint.  
Server.Data - the .NET database layer.  
WebClient - the Angular2 client-side app.


## DEVELOPMENT

Server  
1. Open MdrWebApp.sln in Visual Studio  
2. Ensure Server project is Set As Startup Project  
3. Start Debugging using IIS Express  

Client 
1. Open command prompt and navigate to src/WebClient  
2. Run command: npm install  
3. Run command: npm start  
