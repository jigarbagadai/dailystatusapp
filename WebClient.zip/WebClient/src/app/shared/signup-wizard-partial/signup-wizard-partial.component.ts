import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';

import { Memory } from '../../models/memory';

@Component({
  selector: 'app-signup-wizard-partial',
  templateUrl: './signup-wizard-partial.component.html',
  styleUrls: ['./signup-wizard-partial.component.scss']
})
export class SignupWizardPartialComponent implements OnInit, OnChanges {

  @Input() memory: Memory;

  hasPeople() {
    return !!this.memory && !!this.memory.lstPeople && !!this.memory.lstPeople.length;
  }

  hasAttachments() {
    return !!this.memory && !!this.memory.lstMemoryAttachment && !!this.memory.lstMemoryAttachment.length;
  }

  constructor() {
    this.memory = this.memory || new Memory();
  }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    this.memory = this.memory || new Memory();
  }
}
