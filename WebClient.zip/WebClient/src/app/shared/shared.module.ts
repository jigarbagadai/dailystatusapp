import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MemoryPeopleIgnorePipe } from '../shared/memory-people-ignore.pipe';

import { MemoryViewPartialComponent } from './memory-view-partial/memory-view-partial.component';
import { SignupWizardPartialComponent } from './signup-wizard-partial/signup-wizard-partial.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    MemoryViewPartialComponent,
    SignupWizardPartialComponent,
    MemoryPeopleIgnorePipe
  ],
  exports: [
    MemoryViewPartialComponent,
    SignupWizardPartialComponent,
    MemoryPeopleIgnorePipe
  ]
})
export class SharedModule { }
