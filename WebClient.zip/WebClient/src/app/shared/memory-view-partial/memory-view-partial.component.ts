import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';

import { Memory } from '../../models/memory';

@Component({
  selector: 'app-memory-view-partial',
  templateUrl: './memory-view-partial.component.html',
  styleUrls: ['./memory-view-partial.component.scss']
})
export class MemoryViewPartialComponent implements OnInit, OnChanges {

  @Input() memory: Memory;
  @Input() canNavigatePerson: boolean;

  @Output() onClickPerson = new EventEmitter();

  hasPeople() {
    return !!this.memory && !!this.memory.lstPeople && !!this.memory.lstPeople.length;
  }

  hasAttachments() {
    return !!this.memory && !!this.memory.lstMemoryAttachment && !!this.memory.lstMemoryAttachment.length;
  }

  constructor() {
    this.memory = this.memory || new Memory();
  }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    this.memory = this.memory || new Memory();
  }

  clickPerson($event: Event, userId: number) {
    $event.preventDefault();
    this.onClickPerson.emit(userId);
  }

}
