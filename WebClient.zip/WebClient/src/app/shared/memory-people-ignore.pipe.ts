import { Pipe, PipeTransform } from '@angular/core';

import { MemoryPerson } from './../models/memory-person';

import * as _ from 'lodash';

@Pipe({
  name: 'memoryPeopleIgnore'
})
export class MemoryPeopleIgnorePipe implements PipeTransform {
  transform(people: MemoryPerson[], userIds: number[]): any {
    if (!people || !userIds) {
      return people;
    }
    return people.filter(p => !_.includes(userIds, p.userId));
  }
}
