import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { Router, Resolve, ActivatedRouteSnapshot } from '@angular/router';

import { AuthService } from './auth.service';
import { AuthContext } from './auth.context';

import { TimelineMemory } from '../models/timeline-memory';
import { TimelineFilter } from '../models/timeline-filter';
import { User } from '../models/user';

@Injectable()
export class DashboardService {

  private dashboardUrl = 'api/dashboard';

  constructor(
    private http: Http,
    private authService: AuthService) { }

  getTimelineUser(userId: number): Observable <User> {
    return this.http.get(this.dashboardUrl + '/timelineuser/' + userId, this.authService.getDefaultHeader())
      .map((response: Response) => response.json().object as User);
  }

  getTimelineMemories(timelineUserId: number, searchTerm?: string, filters?: TimelineFilter[]): Observable<TimelineMemory[]> {
    const options = this.authService.getDefaultHeader();
    options.headers.append('Content-Type', 'application/json');

    let query = {
      timelineUserId: timelineUserId,
      searchTerm: searchTerm,
      filters: filters
    }

    return Observable.create(observer => {
      this.http.post(this.dashboardUrl + '/timeline', JSON.stringify(query), options)
        .map((res: Response) => res.json())
        .subscribe(data => {
          if (data.success) {
            observer.next(data.object as TimelineMemory[]);
          } else {
            observer.error(data.responseString);
          }
          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }
}

@Injectable()
export class TimelineUserResolver implements Resolve<User> {

    constructor(
      private dashboardService: DashboardService,
      private authContext: AuthContext,
      private router: Router) { }

    resolve(route: ActivatedRouteSnapshot): Observable<any> {
      let timelineUserId = route.params['userid'];
      if (!timelineUserId){
        return null;
      }

      if (timelineUserId == this.authContext.loggedInUser.userId) {
        return undefined;
      }

      let timelineUser = this.dashboardService.getTimelineUser(route.params['userid']);
      if (!timelineUser){
        return null;
      }

      return timelineUser;
    }
}
