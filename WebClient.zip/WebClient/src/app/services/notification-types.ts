export class NotificationTypes {
  public memorybookmark = 'memorybookmark';
  public bubblebookmark = 'bubblebookmark';
  public memory = 'memory';
  public bubble = 'bubble';
}