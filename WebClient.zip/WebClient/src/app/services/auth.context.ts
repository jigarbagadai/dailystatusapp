import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs/ReplaySubject';

import { User } from '../models/user';

@Injectable()
export class AuthContext {

  public loggedInUser: User;
  public isLoggedIn: ReplaySubject<boolean>;
  public isRegistering: ReplaySubject<boolean>;

  constructor() {
    this.isLoggedIn = new ReplaySubject(1);
    this.isRegistering = new ReplaySubject(1);
  }

  login(user: User): void {
    this.loggedInUser = user;
    
    this.isLoggedIn.next(true);
  }

  logout(): void {
    this.loggedInUser = null;
    localStorage.clear();
    this.isLoggedIn.next(false);
  }

  startRegistration(): void {
    this.isRegistering.next(true);
  }

  completeRegistration(): void {
    this.isRegistering.next(false);
  }

}
