export class TimelineFilterTypes {
  public category = 'category';
  public location = 'location';
  public date = 'date';
  public person = 'person';
  public owner = 'owner';
}