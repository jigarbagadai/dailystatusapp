import { Injectable } from '@angular/core';

import * as _ from 'lodash';

@Injectable()
export class FuzzyDateUtility {

  constructor() { }

  parseDate(userDateFormat: string, date: string): string {
    //TODO: date parsing throw exception
    let regexps = [
      /^(0?[1-9]|[12][0-9]|3[01])[\/](0?[1-9]|1[012])[\/](\d{4})$/,
      /^(0?[1-9]|1[012])[\/\-](\d{4})$/,
      /^(\d{4})$/,
      /^(Early|Mid|Late)( )(\d{4})$/,
      /^(early|mid|late)( )(\d{4})$/
    ];

    if (userDateFormat == 'MM/dd/yyyy') {
      regexps[0] = /^(0?[1-9]|1[012])[\/](0?[1-9]|[12][0-9]|3[01])[\/](\d{4})$/;
    }

    let m = [];
    let mIndex = _.findIndex(regexps, function (r) {
      m = date.match(r);
      if (m) {
        return true;
      } else {
        return false;
      }
    });
    let _date: Date;
    switch (mIndex) {
      case 0:
        if (userDateFormat == 'MM/dd/yyyy')
          _date = new Date(m[3], m[1] - 1, m[2]);
        else
          _date = new Date(m[3], m[2] - 1, m[1]);
        break;
      case 1:
        _date = new Date(m[2], m[1] - 1);
        break;
      case 2:
        _date = new Date(m[1]);
        break;
      case 3:
        if (m[1] == "Early") _date = new Date(m[3], 2);
        else if (m[1] == "Mid") _date = new Date(m[3], 5);
        else if (m[1] == "Late") _date = new Date(m[3], 7);
        break;
      case 4:
        if (m[1] == "early") _date = new Date(m[3], 2);
        else if (m[1] == "mid") _date = new Date(m[3], 5);
        else if (m[1] == "late") _date = new Date(m[3], 7);
        break;

      default:
        throw "Invalid Date";
    }

    let todaysDate = new Date();
    if (_date > new Date(todaysDate.getFullYear() + 1, todaysDate.getMonth(), todaysDate.getDate())) {
      throw 'Date cannot be further than 1 year into the future';
    }

    _date = new Date(_date.getTime() - (_date.getTimezoneOffset() * 60000)); // cancel out timezone offset
    return _date.toISOString();
  }

}
