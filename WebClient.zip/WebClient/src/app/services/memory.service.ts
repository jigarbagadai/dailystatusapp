import { Injectable, Injector } from '@angular/core';
import { Http, Response, URLSearchParams, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router, Resolve, ActivatedRouteSnapshot } from '@angular/router';

import { AuthService } from './auth.service';
import { Memory } from '../models/memory';

import { Angulartics2GoogleAnalytics } from 'angulartics2';

@Injectable()
export class MemoryService {

    private analytics: Angulartics2GoogleAnalytics;

    private memoryUrl = 'api/memory';
    private accessUnauthMemoryUrl = 'api/accessunauthmemory';
    private deleteAttachementUrl = 'api/File';

    constructor(
      private http: Http, 
      private injector: Injector,
      private authService: AuthService) {
      this.analytics = this.injector.get(Angulartics2GoogleAnalytics);
    }

    getMemory(id: string): Observable<Memory> {
        return this.http.get(this.memoryUrl + '/' + id, this.authService.getDefaultHeader())
            .map((res: Response) => res.json().object as Memory);
    }

    addMemory(memory: Memory): Observable<any> {

        const options = this.authService.getDefaultHeader();
        options.headers.append('Content-Type', 'application/json');

        return Observable.create(observer => {
            this.http.post(this.memoryUrl, JSON.stringify(memory), options)
                .map((res: Response) => res.json())
                .subscribe(data => {
                    if (data.success) {
                      this.analytics.eventTrack('create', { category: 'memory' });

                      observer.next(true);
                    } else {
                      observer.error(data.responseString);
                    }

                    observer.complete();
                }, error => {
                    observer.error(error.status + ' ' + error.statusText);
                });
        });
    }

    updateMemory(memory: Memory): Observable<any> {
        const options = this.authService.getDefaultHeader();
        options.headers.append('Content-Type', 'application/json');

        return Observable.create(observer => {
            this.http.put(this.memoryUrl, JSON.stringify(memory), options)
                .map((res: Response) => res.json())
                .subscribe(data => {
                    if (data.success) {
                      this.analytics.eventTrack('update', { category: 'memory' });

                      observer.next(true);
                    } else {
                      observer.error(data.responseString);
                    }

                    observer.complete();
                }, error => {
                    observer.error(error.status + ' ' + error.statusText);
                });
        });
    }

    updateMemoryUser(memoryId: number, isSavedToTimeline: boolean, isBookmarked: boolean): Observable<any> {
        const options = this.authService.getDefaultHeader();
        options.headers.append('Content-Type', 'application/json');

        let model = {
            memoryId: memoryId,
            isSavedToTimeline: isSavedToTimeline,
            isBookmarked: isBookmarked
        }

        return Observable.create(observer => {
            this.http.put(this.memoryUrl + '/UserMemoryUpdate/' + memoryId, JSON.stringify(model), options)
                .map((res: Response) => res.json())
                .subscribe(data => {
                    if (data.success) {
                        observer.next(true);
                    } else {
                        observer.error(data.responseString);
                    }
                    observer.complete();
                }, error => {
                    observer.error(error.status + ' ' + error.statusText);
                });
        });
    }

    accessUnauthMemory(accessToken: string): Observable<Memory> {
        const options = new RequestOptions({
            headers: new Headers({ 'Content-Type': 'application/json' })
        });

        let payload = {
            accessToken: accessToken,
        }

        return Observable.create(observer => {
            this.http.post(this.accessUnauthMemoryUrl, JSON.stringify(payload), options)
                .map((res: Response) => res.json())
                .subscribe(data => {
                    if (data.success) {
                        observer.next(data.object as Memory);
                    } else {
                        observer.error(data.responseString);
                    }

                    observer.complete();
                }, error => {
                    observer.error(error.status + ' ' + error.statusText);
                });
        });
    }

    removeAttachement(fileidentifier: string): Observable<boolean> {
        let headers = this.authService.getDefaultHeader();
        headers.headers.append('Content-Type', 'application/json');
        return Observable.create(observer => {
            this.http.delete(this.deleteAttachementUrl + "/" + fileidentifier, headers)
                .map((res: Response) => res.json())
                .subscribe(data => {
                        observer.next(true);
                        observer.complete();
                }, error => {
                    observer.error(error.status + ' ' + error.statusText);
                });
        });
    }
}

@Injectable()
export class MemoryResolver implements Resolve<Memory> {
    constructor(private ms: MemoryService, private router: Router) { }
    resolve(route: ActivatedRouteSnapshot): Observable<any> {
        if (route.params['id'])
            return this.ms.getMemory(route.params['id']);
        else
            return null;
    }
}
