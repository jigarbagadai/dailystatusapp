import { Injectable } from '@angular/core';

@Injectable()
export class CacheService {

  private cachePrefix = 'mdrapp_';

  constructor() { }

  setCacheValue(key: string, value: any) {
    localStorage.setItem(this.cachePrefix + key, JSON.stringify(value));
  }

  getCacheValue(key: string): any {
    return JSON.parse(localStorage.getItem(this.cachePrefix + key));
  }

  removeFromCache(key: string): void {
    localStorage.removeItem(this.cachePrefix + key);
  }

}
