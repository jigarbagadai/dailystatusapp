import { Injectable, Injector } from "@angular/core";
import { ConnectionBackend, RequestOptions, Request, RequestOptionsArgs, Response, Http, Headers, XHRBackend } from "@angular/http";
import { Router } from "@angular/router";
import { Observable } from "rxjs/Rx";
import { LoaderService } from "./loader.service"
import { AuthContext } from "./auth.context";
import { AppContext } from "./app.context";

@Injectable()
export class HttpInterceptor extends Http {
  private router: Router;
  private appInitialized: Boolean;

  constructor(
    private backend: ConnectionBackend, 
    private defaultOptions: RequestOptions, 
    private injector: Injector, 
    private loaderService: LoaderService, 
    private authContext: AuthContext,
    private appContext: AppContext) {
    super(backend, defaultOptions);

    this.appContext.appInitialized
      .subscribe(initialized => {
        this.appInitialized = initialized;
      })
  }

  request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
    return super.request(url, options);
  }

  get(url: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.intercept(super.get(url, options));
  }

  post(url: string, body: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.intercept(super.post(url, body, options));
  }

  put(url: string, body: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.intercept(super.put(url, body, options));
  }

  delete(url: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.intercept(super.delete(url, options));
  }

  intercept(observable: Observable<Response>): Observable<Response> {
    if (!this.appInitialized) {
      return observable;
    }

    return observable.catch((err, source) => {
      if (!this.router) {
        this.router = this.injector.get(Router);
      }
      
      if (err.status == 401 && !this.router.routerState.snapshot.url.startsWith('/u/')) {
        this.authContext.logout();
        this.router.navigate(['/login']);
        this.loaderService.display(false);
        return Observable.empty();
      } else {
        return Observable.throw(err);
      }
    });
  }
}
