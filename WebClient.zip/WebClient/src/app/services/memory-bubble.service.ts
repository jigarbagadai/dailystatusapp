import { Injectable, Injector } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { AuthService } from './auth.service';
import { AuthContext } from './auth.context';
import { MemoryService } from './memory.service';

import { MemoryBubble } from '../models/memory-bubble';

import { Router, Resolve, ActivatedRouteSnapshot } from '@angular/router';

import { Angulartics2GoogleAnalytics } from 'angulartics2';

@Injectable()
export class MemoryBubbleService {

  private analytics: Angulartics2GoogleAnalytics;

  private memoryBubbleUrl = 'api/MemoryBubble';

  constructor(
    private http: Http,
    private injector: Injector,
    private authService: AuthService,
    private memoryService: MemoryService) {
      this.analytics = this.injector.get(Angulartics2GoogleAnalytics);
    }

  getMemoryBubble(id: string): Observable<MemoryBubble> {
    return this.http.get(this.memoryBubbleUrl + '/' + id, this.authService.getDefaultHeader())
      .map((res: Response) => res.json().object as MemoryBubble);
  }

  getMemoryBubbleSummaries(id: string): Observable<MemoryBubble[]> {
    return this.http.get(this.memoryBubbleUrl + '/MemoryBubbleSummaries/' + id, this.authService.getDefaultHeader())
      .map((res: Response) => res.json().object as MemoryBubble[]);
  }

  addMemoryBubble(memoryBubble: MemoryBubble): Observable<any> {
    const options = this.authService.getDefaultHeader();
    options.headers.append('Content-Type', 'application/json');
    let postString = JSON.stringify({
      memoryId: memoryBubble.memoryId,
      description: memoryBubble.bubbleDescription,
      lstBubblePeople: memoryBubble.lstBubblePeople,
      lstBubbleAttachments: memoryBubble.lstMemoryBubbleAttachment
    });
    return Observable.create(observer => {
      this.http.post(this.memoryBubbleUrl, postString, options)
        .map((res: Response) => res.json())
        .subscribe(data => {
          if (data.success) {
            this.analytics.eventTrack('create', { category: 'bubble' });

            observer.next(data.object);
          } else {
            observer.error(data.responseString);
          }
          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }

  updateMemoryBubble(memoryBubble: MemoryBubble): Observable<any> {
    const options = this.authService.getDefaultHeader();
    options.headers.append('Content-Type', 'application/json');
    let postString = JSON.stringify({
      memoryBubbleId: memoryBubble.memoryBubbleId,
      memoryId: memoryBubble.memoryId,
      description: memoryBubble.bubbleDescription,
      lstPeople: memoryBubble.lstPeople
    });
    return Observable.create(observer => {
      this.http.put(this.memoryBubbleUrl + '/' + memoryBubble.memoryBubbleId, postString, options)
        .map((res: Response) => res.json())
        .subscribe(data => {
          if (data.success) {
            this.analytics.eventTrack('update', { category: 'bubble' });

            observer.next(true);
          } else {
            observer.error(data.responseString);
          }
          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }

  updateMemoryBubbleUser(memoryBubbleId: number, isSavedToTimeline: boolean, isBookmarked: boolean): Observable<any> {
    const options = this.authService.getDefaultHeader();
    options.headers.append('Content-Type', 'application/json');

    let model = {
      memoryBubbleId: memoryBubbleId,
      isSavedToTimeline: isSavedToTimeline,
      isBookmarked: isBookmarked
    }

    return Observable.create(observer => {
      this.http.put(this.memoryBubbleUrl + '/UpdateMemoryBubbleUser/' + memoryBubbleId, JSON.stringify(model), options)
        .map((res: Response) => res.json())
        .subscribe(data => {
          if (data.success) {
            observer.next(true);
          } else {
            observer.error(data.responseString);
          }
          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }
}


@Injectable()
export class MemoryBubbleResolver implements Resolve<MemoryBubble> {
  constructor(
    private ms: MemoryService,
    private mbs: MemoryBubbleService,
    private router: Router,
    private authContext: AuthContext
  ) { }
  resolve(route: ActivatedRouteSnapshot): Observable<any> {
    if (route.params['bubbleid'])
      return this.mbs.getMemoryBubble(route.params['bubbleid']);
    else if (route.params['memid']) {
      return Observable.create(observer => {
        var memoryBubble = new MemoryBubble();
        this.ms.getMemory(route.params['memid']).subscribe(m => {
          memoryBubble.memoryBubbleId = undefined;
          memoryBubble.title = m.title;
          memoryBubble.location = m.location;
          memoryBubble.locationModel = m.locationModel;
          memoryBubble.date = m.date;
          memoryBubble.dateText = m.dateText;
          memoryBubble.lstMemoryAttachment = m.lstMemoryAttachment;
          memoryBubble.lstPeople = m.lstPeople;
          memoryBubble.memoryId = m.memoryId;
          memoryBubble.description = m.description;
          memoryBubble.ownerId = m.ownerId;
          memoryBubble.ownerName = m.ownerName;
          memoryBubble.ownerProfilePhotoUrl = m.ownerProfilePhotoUrl;
          observer.next(memoryBubble);
          observer.complete();
        });

      });

    }
    else {
      return null;
    }

  }
}
