import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { Router } from '@angular/router';

import { AuthContext } from './auth.context';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private router: Router, private authContext: AuthContext) { }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return new Observable((observer: Observer<boolean>) => {
      this.authContext.isLoggedIn.subscribe(
        isLoggedIn => {
          if (isLoggedIn) {
            observer.next(true);
            observer.complete();
          } else {
            this.router.navigate(['/login']);
            observer.next(false);
            observer.complete();
          }
        }
      );
    });
  }
}
