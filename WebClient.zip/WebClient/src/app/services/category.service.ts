import { Injectable, Injector } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { AuthService } from './auth.service';
import { Category } from '../models/category';

import { Router, Resolve, ActivatedRouteSnapshot } from '@angular/router';

import { Angulartics2GoogleAnalytics } from 'angulartics2';

@Injectable()
export class CategoryService {
  private analytics: Angulartics2GoogleAnalytics;

  private categoryUrl = 'api/categories';
  private categoriesKey = 'categories';

  constructor(
    private http: Http, 
    private injector: Injector,
    private authService: AuthService) {
    this.analytics = this.injector.get(Angulartics2GoogleAnalytics);
    }

  fetchCategories(): Observable<Category[]> {
      return Observable.create(observer => {
          this.http.get("api/Categories", this.authService.getDefaultHeader())
              .map((res: Response) => res.json())
              .subscribe(data => {
                  if (data.success) {
                      localStorage.setItem(this.categoriesKey, JSON.stringify(data.object));
                      observer.next(data.object);
                      observer.complete();
                  } else {
                      observer.error(data.responseString);
                  }
              }, error => {
                  observer.error(error.status + ' ' + error.statusText);
              });
      });
  }

  fetchOwnCategories(): Observable<Category[]> {
      return Observable.create(observer => {
          this.http.get("api/Categories/getown", this.authService.getDefaultHeader())
              .map((res: Response) => res.json())
              .subscribe(data => {
                  if (data.success) {
                      observer.next(data.object);
                      observer.complete();
                  } else {
                      observer.error(data.responseString);
                  }
              }, error => {
                  observer.error(error.status + ' ' + error.statusText);
              });
      });
  }
  
  saveCategory(category: Category): Observable<any> {
      let headers = this.authService.getDefaultHeader();
      headers.headers.append('Content-Type', 'application/json');
      return Observable.create(observer => {
          this.http.post("api/Categories", JSON.stringify(category), headers)
              .map((res: Response) => res.json())
              .subscribe(data => {
                  if (data.success) {
                    this.analytics.eventTrack('create-category', { category: 'account' });
                    observer.next(true);
                  }
                  else {
                    observer.error(data.responseString);
                  }

                  observer.complete();
              }, error => {
                  observer.error(error.status + ' ' + error.statusText);
              });
      });
  }

  updateCategory(id: number, category: Category): Observable<any> {
      let headers = this.authService.getDefaultHeader();
      headers.headers.append('Content-Type', 'application/json');
      return Observable.create(observer => {
          this.http.put("api/Categories/" + id, JSON.stringify(category), headers)
              .map((res: Response) => res.json())
              .subscribe(data => {
                  if (data.success) {
                    this.analytics.eventTrack('update-category', { category: 'account' });
                    observer.next(true);
                  }
                  else {
                    observer.error(data.responseString);
                  }

                  observer.complete();
              }, error => {
                  observer.error(error.status + ' ' + error.statusText);
              });
      });
  }

  deleteCategory(id: number): Observable<any> {
      let headers = this.authService.getDefaultHeader();
      headers.headers.append('Content-Type', 'application/json');
      return Observable.create(observer => {
          this.http.delete("api/Categories/" + id, headers)
              .map((res: Response) => res.json())
              .subscribe(data => {
                  if (data.success) {
                    this.analytics.eventTrack('delete-category', { category: 'account' });
                    observer.next(true);
                  }
                  else {
                    observer.error(data.responseString);
                  }

                  observer.complete();
              }, error => {
                  observer.error(error.status + ' ' + error.statusText);
              });
      });
  }
}

@Injectable()
export class CategoryResolver implements Resolve<Category[]> {
  constructor(private ms: CategoryService, private router: Router) { }
  resolve(route: ActivatedRouteSnapshot): Observable<any> {
    // if (localStorage.getItem("categories"))
    //   return JSON.parse(localStorage.getItem("categories"));
    // else
       return this.ms.fetchCategories();
  }
}
