import { XHRBackend, Http, RequestOptions } from "@angular/http";
import { Router } from "@angular/router";
import { Injector } from "@angular/core";
import { HttpInterceptor } from "./http-interceptor.service";
import { LoaderService } from "./loader.service";
import { AuthContext } from "./auth.context";
import { AppContext } from "./app.context";

export function HttpFactory(xhrBackend: XHRBackend, requestOptions: RequestOptions, injector: Injector, loaderService: LoaderService, authContext: AuthContext, appContext: AppContext): Http {
  return new HttpInterceptor(xhrBackend, requestOptions, injector, loaderService, authContext, appContext);
}