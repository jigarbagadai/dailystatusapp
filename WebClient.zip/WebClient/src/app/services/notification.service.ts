import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Observable, Subscription } from 'rxjs/Rx';
import { Observer } from 'rxjs/Observer';
import { ReplaySubject } from 'rxjs/ReplaySubject';

import { AuthService } from './auth.service';
import { AuthContext } from './auth.context';
import { NotificationTypes } from './notification-types';

import { Notification } from '../models/notification';

import * as _ from 'lodash';

@Injectable()
export class NotificationService {

  private pollingDelay = 2000;
  private pollingInterval = 30000;

  private isMonitoring: boolean;

  private dashboardUrl = 'api/dashboard';

  private timerSub: Subscription = null;

  public bookmarks: ReplaySubject<Notification[]>;
  public memories: ReplaySubject<Notification[]>;
  public bubbles: ReplaySubject<Notification[]>;

  constructor(
    private http: Http,
    private authService: AuthService,
    private authContext: AuthContext,
    private notificationTypes: NotificationTypes)
  {
    this.bookmarks = new ReplaySubject(1);
    this.memories = new ReplaySubject(1);
    this.bubbles = new ReplaySubject(1);

    this.authContext.isLoggedIn
      .subscribe(loggedIn => {
        if (loggedIn) {
          this.monitor();
        } else {
          this.forget();
        }
      });
  }


  monitor(): void {
    if (this.isMonitoring) {
      return;
    }

    this.loadBookmarks().subscribe(notifications => { });

    let timer = Observable.timer(this.pollingDelay, this.pollingInterval);
    this.timerSub = timer.subscribe(t => {
      this.loadNotifications().subscribe(notifications => { });
    });

    this.isMonitoring = true;
  }

  forget(): void {
    this.bookmarks.complete();
    this.bookmarks = new ReplaySubject(1);

    this.memories.complete();
    this.memories = new ReplaySubject(1);

    this.bubbles.complete();
    this.bubbles = new ReplaySubject(1);

    if (this.timerSub) {
      this.timerSub.unsubscribe();
      this.timerSub = null;
    }

    this.isMonitoring = false;
  }

  loadBookmarks(): Observable<any> {
    return Observable.create(observer => {
      this.http.get(this.dashboardUrl + '/bookmarks', this.authService.getDefaultHeader())
      .map((response: Response) => response.json().object as Notification[])
        .subscribe(notifications => {
          this.bookmarks.next(notifications);
          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }

  loadNotifications(): Observable<any> {
    return Observable.create(observer => {
      this.http.get(this.dashboardUrl + '/notifications', this.authService.getDefaultHeader())
      .map((response: Response) => response.json().object as Notification[])
        .subscribe(notifications => {
          this.memories.next(_.filter(notifications, { 'type': this.notificationTypes.memory }));
          this.bubbles.next(_.filter(notifications, { 'type': this.notificationTypes.bubble }));
          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }

  openNotification(notification: Notification): Observable<any> {
    const options = this.authService.getDefaultHeader();
    options.headers.append('Content-Type', 'application/json');

    return Observable.create(observer => {
      this.http.post(this.dashboardUrl + '/opennotification', JSON.stringify(notification), options)
        .map((res: Response) => res.json())
        .subscribe(data => {
          if (data.success) {
            observer.next(true);
          } else {
            observer.error(data.responseString);
          }
          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }

}
