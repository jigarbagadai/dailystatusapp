import { Injectable, Injector } from '@angular/core';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';

import { AuthContext } from './auth.context';

import { User } from '../models/user';

import { Angulartics2GoogleAnalytics } from 'angulartics2';

@Injectable()
export class AuthService {

  private analytics: Angulartics2GoogleAnalytics;

  private authTokenKey = 'access_token';
  private authExpiryKey = 'access_expires';

  private tokenUrl = 'api/connect/token';
  private userUrl = 'api/user';

  constructor(
    private http: Http, 
    private injector: Injector,
    private authContext: AuthContext) {
      this.analytics = this.injector.get(Angulartics2GoogleAnalytics);
    }

  login(email: string, password: string, inviteToken?: string): Observable < any > {
    const params = new URLSearchParams();
    params.append('username', email);
    params.append('password', password);
    params.append('grant_type', 'password');
    params.append('scope', 'profile');
    params.append('resource', 'resource_server');

    const headers = new Headers({
      'Content-Type': 'application/x-www-form-urlencoded'
    });

    return Observable.create(observer => {
      this.http.post(this.tokenUrl, params.toString(), {
          headers: headers
        })
        .map((res: Response) => res.json())
        .subscribe(data => {
          localStorage.setItem(this.authTokenKey, data.access_token);
          localStorage.setItem(this.authExpiryKey, data.expires_in);

          const options = new RequestOptions({
            headers: new Headers({
              'Authorization': 'Bearer ' + data.access_token
            })
          });

          this.http.get(this.userUrl, options)
            .map((response: Response) => response.json().object as User)
            .subscribe((user: User) => {
              this.authContext.login(user);

              // if no inviteToken then login complete
              if (!inviteToken) {
                observer.next(0);
                observer.complete();
              } else {
                // if inviteToken present then redeem that token
                this.redeemInvitation(inviteToken)
                  .subscribe(memoryId => {
                    observer.next(memoryId);
                    observer.complete();
                  }, errorStr => {
                    observer.error(errorStr);
                  });
              }
            });
        }, error => {
          if (error.status === 401) {
            observer.error('This email/password combination is invalid');
          } else {
            observer.error(error.status + ' ' + error.statusText);
          }
        });
    });
  }

  loginByVerifiedToken(token: string, inviteToken?: string): Observable < any > {
    const params = new URLSearchParams();
    params.append('username', '.');
    params.append('password', '.');
    params.append('token', token);
    params.append('grant_type', 'password');
    params.append('scope', 'profile');
    params.append('resource', 'resource_server');

    const headers = new Headers({
      'Content-Type': 'application/x-www-form-urlencoded'
    });

    return Observable.create(observer => {
      this.http.post(this.tokenUrl, params.toString(), {
          headers: headers
        })
        .map((res: Response) => res.json())
        .subscribe(data => {
          localStorage.setItem(this.authTokenKey, data.access_token);
          localStorage.setItem(this.authExpiryKey, data.expires_in);

          const options = new RequestOptions({
            headers: new Headers({
              'Authorization': 'Bearer ' + data.access_token
            })
          });

          this.http.get(this.userUrl, options)
            .map((response: Response) => response.json().object as User)
            .subscribe((user: User) => {
              this.authContext.login(user);

              // if no inviteToken then login complete
              if (!inviteToken) {
                observer.next(0);
                observer.complete();
              } else {
                // if inviteToken present then redeem that token
                this.redeemInvitation(inviteToken)
                  .subscribe(memoryId => {
                    observer.next(memoryId);
                    observer.complete();
                  }, errorStr => {
                    observer.error(errorStr);
                  });
              }
            });
        }, error => {
          if (error.status === 401) {
            observer.error('There was an issue with the provided token');
          } else {
            observer.error(error.status + ' ' + error.statusText);
          }
        });
    });
  }


  register(user: User): Observable < any > {
    const headers = new Headers({
      'Content-Type': 'application/json'
    });

    return Observable.create(observer => {
      this.http.post(this.userUrl, JSON.stringify(user), {
          headers: headers
        })
        .map((res: Response) => res.json())
        .subscribe(data => {
          if (data.success) {
            this.analytics.eventTrack('register', { category: 'account', label: user.emailAddress });
          
            observer.next(true);
          } else {
            observer.error(data.responseString);
          }

          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }

  verifyEmail(token: string): Observable < any > {
    const headers = new Headers({
      'Content-Type': 'application/json'
    });

    return Observable.create(observer => {
      this.http.post(this.userUrl + '/verify', JSON.stringify(token), {
          headers: headers
        })
        .map((res: Response) => res.json())
        .subscribe(data => {
          if (data.success) {
            this.analytics.eventTrack('verify', { category: 'account' });

            observer.next(true);
            observer.complete();
          } else {
            observer.error(data.responseString);
          }

          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }

  redeemInvitation(token: string): Observable < any > {
    let headers = this.getDefaultHeader();
    headers.headers.append('Content-Type', 'application/json');

    return Observable.create(observer => {
      this.http.post(this.userUrl + '/redeeminvitation', JSON.stringify(token), headers)
        .map((res: Response) => res.json())
        .subscribe(data => {
          if (data.success) {
            this.analytics.eventTrack('redeem-invitation', { category: 'account' });

            observer.next(data.object.memoryId);
          } else {
            observer.error(data.responseString);
          }

          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }

  resetPassword(emailAddress: string): Observable <any> {
    const headers = new Headers({
      'Content-Type': 'application/json'
    });

    return Observable.create(observer => {
      this.http.post(this.userUrl + '/resetpassword', JSON.stringify(emailAddress), {
          headers: headers
        })
        .map((res: Response) => res.json())
        .subscribe(data => {
          if (data.success) {
            observer.next(true);
          } else {
            observer.error(data.responseString);
          }

          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }

  updatePassword(password: string, token: string): Observable < any > {
    const headers = new Headers({
      'Content-Type': 'application/json'
    });

    let payload = { password: password, token: token }

    return Observable.create(observer => {
      this.http.post(this.userUrl + '/updatepassword', JSON.stringify(payload), {
          headers: headers
        })
        .map((res: Response) => res.json())
        .subscribe(data => {
          if (data.success) {
            this.analytics.eventTrack('update-password', { category: 'account' });

            observer.next(true);
          } else {
            observer.error(data.responseString);
          }

          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }

  logout(): void {
    this.analytics.eventTrack('logout', { category: 'account' });

    localStorage.clear();
    this.authContext.logout();
  }

  getDefaultHeader(): RequestOptions {
    const accessToken = localStorage.getItem('access_token');

    return new RequestOptions({
      headers: new Headers({
        'Authorization': 'Bearer ' + accessToken
      })
    });
  }

  getAuthBeaerToken(): string {
    const accessToken = localStorage.getItem('access_token');
    return accessToken;
  }

  getCurrentUser(): Observable <User> {
    return this.http.get(this.userUrl, this.getDefaultHeader())
      .map((response: Response) => response.json().object as User);
  }

  updateUser(user: User): Observable <any> {
    let headers = this.getDefaultHeader();
    headers.headers.append('Content-Type', 'application/json');
    
    return Observable.create(observer => {
      this.http.put(this.userUrl, JSON.stringify(user), headers)
        .map((res: Response) => res.json())
        .subscribe(data => {
          if (data.success) {
              this.analytics.eventTrack('update', { category: 'account' });

              observer.next(true);
          } else {
            observer.error(data.responseString);
          }

          observer.complete();
        }, error => {
          observer.error(error.status + ' ' + error.statusText);
        });
    });
  }
}
