import { Injectable, Injector } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { AuthService } from './auth.service';
import { Relation } from '../models/relation';

import { Router, Resolve, ActivatedRouteSnapshot } from '@angular/router';

import { Angulartics2GoogleAnalytics } from 'angulartics2';

@Injectable()
export class RelationService {

    private analytics: Angulartics2GoogleAnalytics;

    private relationUrl = 'api/userRelations';
    private relationKey = 'relations';

    constructor(
      private http: Http, 
      private injector: Injector,
      private authService: AuthService) {
      this.analytics = this.injector.get(Angulartics2GoogleAnalytics);
    }

    fetchRelations(): Observable<Relation[]> {
        return Observable.create(observer => {
            this.http.get("api/userRelations", this.authService.getDefaultHeader())
                .map((res: Response) => res.json())
                .subscribe(data => {
                    if (data.success) {
                        observer.next(data.object);
                        observer.complete();
                    } else {
                        observer.error(data.responseString);
                    }
                }, error => {
                    observer.error(error.status + ' ' + error.statusText);
                });
        });
    }

    fetchRelationsById(): Observable<Relation> {
        return Observable.create(observer => {
            this.http.get("api/UserRelations/GetUserRelationByUserRelationId", this.authService.getDefaultHeader())
                .map((res: Response) => res.json())
                .subscribe(data => {
                    if (data.success) {
                        observer.next(data.object);
                        observer.complete();
                    } else {
                        observer.error(data.responseString);
                    }
                }, error => {
                    observer.error(error.status + ' ' + error.statusText);
                });
        });
    }

    savePeople(relation: Relation): Observable<any> {
        let headers = this.authService.getDefaultHeader();
        headers.headers.append('Content-Type', 'application/json');
        return Observable.create(observer => {
            this.http.post("api/UserRelations", JSON.stringify(relation), headers)
                .map((res: Response) => res.json())
                .subscribe(data => {
                    if (data.success) {
                      this.analytics.eventTrack('create', { category: 'relation' });

                      observer.next(true);
                    } else {
                      observer.error(data.responseString);
                    }

                    observer.complete();
                }, error => {
                    observer.error(error.status + ' ' + error.statusText);
                });
        });
    }

    updatePeople(id: number, relation: Relation): Observable<any> {
        let headers = this.authService.getDefaultHeader();
        headers.headers.append('Content-Type', 'application/json');
        return Observable.create(observer => {
            this.http.put("api/UserRelations/" + id, JSON.stringify(relation), headers)
                .map((res: Response) => res.json())
                .subscribe(data => {
                    if (data.success) {
                      this.analytics.eventTrack('update', { category: 'relation' });

                      observer.next(true);
                    } else {
                      observer.error(data.responseString);
                    }

                    observer.complete();
                }, error => {
                    observer.error(error.status + ' ' + error.statusText);
                });
        });
    }

    deletePeople(id: number): Observable<any> {
        let headers = this.authService.getDefaultHeader();
        headers.headers.append('Content-Type', 'application/json');
        return Observable.create(observer => {
            this.http.delete("api/UserRelations/" + id, headers)
                .map((res: Response) => res.json())
                .subscribe(data => {
                    if (data.success) {
                      this.analytics.eventTrack('remove', { category: 'relation' });

                      observer.next(true);
                    } else {
                      observer.error(data.responseString);
                    }

                    observer.complete();
                }, error => {
                    observer.error(error.status + ' ' + error.statusText);
                });
        });
    }
}

@Injectable()
export class RelationResolver implements Resolve<Relation[]> {
    constructor(private ms: RelationService, private router: Router) { }
    resolve(route: ActivatedRouteSnapshot): Observable<any> {
        return this.ms.fetchRelations();
    }
}
