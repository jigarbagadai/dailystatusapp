import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs/ReplaySubject';

import { AppConfig } from '../models/app-config';

@Injectable()
export class AppContext {

  public appConfig: AppConfig;
  public appInitialized: ReplaySubject<boolean>;

  constructor() {
    this.appInitialized = new ReplaySubject(1);
  }

  initializeApp(config: AppConfig): void {
    this.appConfig = config;

    this.appInitialized.next(true);

    console.info('App initialized.');
  }

}
