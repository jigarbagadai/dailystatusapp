import { Injectable, Injector } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';

import { AppContext } from "./app.context";
import { AuthService } from './auth.service';
import { AuthContext } from './auth.context';
import { CacheService } from './cache.service';
import { NotificationService } from './notification.service';
import { ConfigService } from './config.service';
import { LoaderService } from './loader.service';
import { WindowRefService } from './window-ref.service';

import { User } from '../models/user';
import { AppConfig } from '../models/app-config';

@Injectable()
export class AppStartService {

  constructor(
    private appContext: AppContext,
    private authService: AuthService,
    private authContext: AuthContext,
    private cacheService: CacheService,
    private configService: ConfigService,
    private notificationService: NotificationService,
    private injector: Injector,
    private windowRefService: WindowRefService,
    private loaderService: LoaderService) {}

  load(): Promise <any> {
    this.loaderService.display(true);

    return new Promise((resolve, reject) => {

      this.configService.fetchConfig()
        .subscribe((config: AppConfig) => {
          this.windowRefService.nativeWindow.ga('create', config.googleAnalyticsTrackingId, 'auto');

          this.authService.getCurrentUser()
            .subscribe((user: User) => {
                if (user) {
                  this.authContext.login(user);
                  this.notificationService.monitor();

                  if (this.cacheService.getCacheValue('registering')) {
                    this.authContext.startRegistration();
                  }
                } else {
                  this.authContext.logout();
                }

                this.appContext.initializeApp(config);
                this.loaderService.display(false);
                resolve();
              }, error => {
                if (error.status === 401) {
                  this.authContext.logout();
                } else {
                  console.log('App start error. Failed to load current user: ', error);
                }

                this.appContext.initializeApp(config);
                this.loaderService.display(false);
                resolve();
              });

        }, error => {
          console.log('App start error. Failed to load app config: ', error);
          this.loaderService.display(false);
          resolve();
        })
    })

  }

}
