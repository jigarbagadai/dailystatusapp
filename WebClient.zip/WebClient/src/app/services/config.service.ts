import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Observable, Subscription } from 'rxjs/Rx';
import { Observer } from 'rxjs/Observer';

import { AppConfig } from '../models/app-config';

import * as _ from 'lodash';

@Injectable()
export class ConfigService {

  private configUrl: string = 'api/config';

  constructor(
    private http: Http) { }

  fetchConfig(): Observable<AppConfig> {
    const header = new RequestOptions({
      headers: new Headers({})
    });

    return this.http.get(this.configUrl, header)
        .map((response: Response) => response.json() as AppConfig);
  }

}
