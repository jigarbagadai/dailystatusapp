export class Location {
  latitude: string;
  longitude: string;
}