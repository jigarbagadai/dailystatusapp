export class AppConfig {
    googleAnalyticsTrackingId: string;
}