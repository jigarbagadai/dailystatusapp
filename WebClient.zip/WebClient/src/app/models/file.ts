export class File {
  id: string;
  name: string;
  contentType: string;
  url: string;
}
