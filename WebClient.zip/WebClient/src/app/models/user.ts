export class User {
  userId: number;
  emailAddress: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  placeOfBirth: string;
  mobile: string;
  dateFormat: string;
  profilePhotoUrl: string;
  inviteeToken?: string;
}
