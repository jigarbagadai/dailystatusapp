export class Category {
    constructor() {
        this.iseditable = false;
    }

    categoryId: number;
    name: string;
    ownerId: string;
    iconUrl: string;
    iseditable: boolean;
}