export class Notification {
  type: string;
  description: string;
  param1: number;
  param2: number;
}
