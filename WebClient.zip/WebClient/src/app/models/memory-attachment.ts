export class MemoryAttachment {
  memoryAttachmentId: number;
  memoryId: number;
  fileName: string;
  fileIdentifier: string;
  attachmentUrl: string;
}