export class MemoryPerson {
  userRelationId: number;
  userId: number;
  firstName: string;
  lastName: string;
  screenName: string;
  display: boolean;
}