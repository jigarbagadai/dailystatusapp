export class MemoryBubbleAttachment {
  bubbleAttachmentId: number;
  memoryBubbleId: number;
  fileName: string;
  fileIdentifier: string;
  attachmentUrl: string;
}