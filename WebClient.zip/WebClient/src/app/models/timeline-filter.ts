export class TimelineFilter {
  type: string;
  label: string;
  displayValue: string;
  value: string;
}
