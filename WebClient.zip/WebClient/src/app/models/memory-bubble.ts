import { MemoryAttachment } from './memory-attachment';
import { MemoryBubbleAttachment } from './memory-bubble-attachment';
import { MemoryBubblePerson } from './memory-bubble-person';
import { MemoryPerson } from './memory-person';
import { Location } from './location';

export class MemoryBubble {
  memoryBubbleId: number;
  bubbleDescription: string;
  bubbleSavedToTimeline: boolean;
  bubbleBookmarked: boolean;
  bubbleOwnerId: number;
  bubbleOwnerName: string;
  bubbleOwnerScreenName: string;
  bubbleOwnerProfilePhotoUrl: string;
  lstMemoryBubbleAttachment: MemoryBubbleAttachment[] = [];
  lstBubblePeople: MemoryBubblePerson[] = [];
  memoryId: number;
  ownerId: number;
  ownerName: string;
  ownerProfilePhotoUrl: string;
  categoryId: number;
  categoryName: string;
  date: string;
  dateText: string;
  location: string;
  locationModel: Location;
  title: string;
  description: string;
  lstMemoryAttachment: MemoryAttachment[] = [];
  lstPeople: MemoryPerson[] = [];
  savedToTimeline: boolean;
  bookmarked: boolean;
}