export class TimelineMemory {
  memoryId: number;
  categoryIconUrl: string;
  timestamp: string;
  bubbleCount: number;
}
