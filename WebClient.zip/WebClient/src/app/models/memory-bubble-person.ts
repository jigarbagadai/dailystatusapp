export class MemoryBubblePerson {
  userId: number;
  firstName: string;
  lastName: string;
  screenName: string;
  display: boolean;
}