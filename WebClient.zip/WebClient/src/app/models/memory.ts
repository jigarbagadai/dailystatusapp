import { MemoryAttachment } from './memory-attachment';
import { MemoryPerson } from './memory-person';
import { Location } from './location';

export class Memory {
  memoryId: number;
  ownerId: number;
  ownerName: string;
  ownerProfilePhotoUrl: string;
  categoryId: number;
  categoryName: string;
  date: string;
  dateText: string;
  location: string;
  locationModel: Location;
  title: string;
  description: string;
  lstMemoryAttachment: MemoryAttachment[] = [];
  lstPeople: MemoryPerson[] = [];
  savedToTimeline: boolean;
  bookmarked: boolean;
}

