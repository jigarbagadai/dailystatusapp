export class Relation {
    constructor() {
        this.iseditable = false;
    }

    userRelationId: number;
    firstName: string;
    lastName: string;
    display: boolean;
    userId: number;
    relationUserId: number;
    relationshipType: string;
    emailAddress: string;
    screenName: string;
    timelineShared: boolean;
    iseditable: boolean;
}