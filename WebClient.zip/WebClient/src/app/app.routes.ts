import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PathNotFoundComponent } from './components/pathnotfound/pathnotfound.component';

const appRoutes: Routes = [
  { path: '', redirectTo: '/dashboard/home', pathMatch: 'full' },
  { path: '**', component: PathNotFoundComponent }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);