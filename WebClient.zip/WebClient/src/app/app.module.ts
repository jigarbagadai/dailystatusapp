import './rxjs-extensions';

import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { HttpModule, Http, XHRBackend, RequestOptions } from '@angular/http';
import { RouterModule, Routes, Router } from '@angular/router';
import { Injector } from '@angular/core';

import { routing } from './app.routes';

import { AppStartService } from './services/appstart.service';
import { AppContext } from './services/app.context';
import { AuthService } from './services/auth.service';
import { AuthGuard } from './services/auth.guard';
import { AuthContext } from './services/auth.context';
import { LoaderService } from './services/loader.service';
import { ConfigService } from './services/config.service';
import { CacheService } from './services/cache.service';
import { FuzzyDateUtility } from './services/fuzzy-date.utility';
import { HttpInterceptor } from './services/http-interceptor.service';
import { HttpFactory } from './services/http.factory';
import { WindowRefService } from './services/window-ref.service';

import { AppComponent } from './components/app.component';

import { UnauthModule } from './unauth/unauth.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { PathNotFoundComponent } from './components/pathnotfound/pathnotfound.component';

import { Angulartics2Module, Angulartics2GoogleAnalytics } from 'angulartics2';

export function startupServiceFactory(appStartService: AppStartService): Function {
  return () => appStartService.load();
}

@NgModule({
  declarations: [
    AppComponent,
    PathNotFoundComponent
  ],
  imports: [
    routing,
    UnauthModule,
    DashboardModule,
    BrowserModule,
    HttpModule,
    Angulartics2Module.forRoot([Angulartics2GoogleAnalytics])
  ],
  providers: [
    AuthService,
    AuthGuard,
    AuthContext,
    AppStartService,
    AppContext,
    ConfigService,
    LoaderService,
    CacheService,
    FuzzyDateUtility,
    WindowRefService,
    {
      provide: APP_INITIALIZER,
      useFactory: startupServiceFactory,
      deps: [AppStartService, AppContext, ConfigService],
      multi: true
    },
    {
      provide: Http,
      useFactory: HttpFactory,
      deps: [XHRBackend, RequestOptions, Injector, LoaderService, AuthContext, AppContext]
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
