import { Component, OnInit } from '@angular/core';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from '../../../services/auth.service';
import { LoaderService } from '../../../services/loader.service';

@Component({
  selector: 'app-password-reset',
  templateUrl: './password-reset.component.html',
  styleUrls: ['./password-reset.component.scss']
})
export class PasswordResetComponent implements OnInit {

  public error: string;
  public success: string;
  public form: FormGroup;
  public formSubmitted: boolean;
  
  constructor(
    private authService: AuthService,
    private router: Router,
    private formBuilder: FormBuilder,
    private loaderService: LoaderService) {
      this.formSubmitted = false;
  }

  ngOnInit() {
    this.buildForm({
      email: ''
    });
  }

  private buildForm(passwordReset): void {
    const emailRegex = '^[^@]+@[^@]+\.[^@]+$';

    this.form = this.formBuilder.group({
      email: [passwordReset.email, [Validators.required, Validators.pattern(emailRegex)]]
    });
    this.form.markAsPristine();
  }

  reset(passwordReset, isValid, $event: Event): void {
    $event.preventDefault();

    if (!isValid) {
      this.error = 'Please ensure the form is completed correctly';
      return;
    }

    this.formSubmitted = true;

    this.error = undefined;
    this.success = undefined;

    this.loaderService.display(true);

    this.authService.resetPassword(passwordReset.email)
      .subscribe(x => {
        this.loaderService.display(false);
        this.formSubmitted = false;
        this.success = 'Please check your email for a password reset link.';
      }, err => {
        this.loaderService.display(false);
        this.formSubmitted = false;
        this.error = err;
      });
  }

}
