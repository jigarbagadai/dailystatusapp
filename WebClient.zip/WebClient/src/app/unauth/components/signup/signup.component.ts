import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthService } from '../../../services/auth.service';
import { LoaderService } from '../../../services/loader.service';

import { User } from '../../../models/user';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  private inviteToken: string;

  public error: string;
  public success: string;
  public form: FormGroup;
  public formSubmitted: boolean;

  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private loaderService: LoaderService) {
      this.formSubmitted = false;
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.inviteToken = params['inviteToken'];
    });

    this.buildForm(new User());
  }

  private buildForm(user): void {
    const emailRegex = '^[^@]+@[^@]+\.[^@]+$';

    this.form = this.formBuilder.group({
      firstName: [user.firstName, [Validators.required]],
      lastName: [user.lastName, [Validators.required]],
      emailAddress: [user.emailAddress, [Validators.required, Validators.pattern(emailRegex)]],
      passwordHash: [user.passwordHash, [Validators.required]],
      terms: [false, [Validators.pattern('true')]]
    });
    this.form.markAsPristine();
  }

  signup(user, isValid, $event: Event): void {
    $event.preventDefault();

    if (!isValid) {
      this.error = 'Please ensure the form is completed correctly';
      return;
    }
    this.formSubmitted = true;

    this.error = undefined;
    this.success = undefined;
    this.loaderService.display(true);

    user.inviteToken = this.inviteToken;

    this.authService.register(user)
      .subscribe(x => {
        this.loaderService.display(false);
        this.formSubmitted = false;
        // this.router.navigate(['/dashboard/home']);
        this.success = 'Successfully signed up. You should receive a verification email shortly.';
      }, err => {
        this.loaderService.display(false);
        this.formSubmitted = false;
        this.error = err;
      });
  }

}
