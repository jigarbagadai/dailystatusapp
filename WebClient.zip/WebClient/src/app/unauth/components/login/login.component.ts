import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthService } from '../../../services/auth.service';
import { LoaderService } from '../../../services/loader.service';

import { Angulartics2 } from 'angulartics2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  private inviteToken: string;

  public error: string;
  public form: FormGroup;
  public formSubmitted: boolean;

  constructor(
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder,
    private loaderService: LoaderService,
    private angulartics2: Angulartics2) {
      this.formSubmitted = false;
  }

  ngOnInit() {

    this.route.params.subscribe(params => {
      this.inviteToken = params['inviteToken'];
    });

    this.buildForm({
      email: '',
      password: ''
    });
  }

  private buildForm(login): void {
    const emailRegex = '^[^@]+@[^@]+\.[^@]+$';

    this.form = this.formBuilder.group({
      email: [login.email, [Validators.required, Validators.pattern(emailRegex)]],
      password: [login.password, [Validators.required]]
    });
    this.form.markAsPristine();
  }

  login(login, isValid, $event: Event): void {
    $event.preventDefault();

    if (!isValid) {
      this.error = 'Please ensure the form is completed correctly';
      return;
    }

    this.formSubmitted = true;

    this.error = undefined;

    this.loaderService.display(true);

    this.authService.login(login.email, login.password, this.inviteToken)
      .subscribe(x => {
        this.loaderService.display(false);
        this.formSubmitted = false;
        this.router.navigate(['/dashboard/home']);
      }, err => {
        this.loaderService.display(false);
        this.formSubmitted = false;
        this.error = err;
      });
  }

}
