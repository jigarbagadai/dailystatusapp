import { Component, OnInit } from '@angular/core';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthService } from '../../../services/auth.service';
import { LoaderService } from '../../../services/loader.service';

@Component({
  selector: 'app-password-update',
  templateUrl: './password-update.component.html',
  styleUrls: ['./password-update.component.scss']
})
export class PasswordUpdateComponent implements OnInit {

  public error: string;
  public success: boolean;
  public form: FormGroup;
  public formSubmitted: boolean;

  private token: string;
  
  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private loaderService: LoaderService) {
      this.formSubmitted = false;
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.token = params['token'];
    });

    this.buildForm({
      password: '',
      passwordConfirm: '',
    });
  }

  private buildForm(passwordReset): void {
    this.form = this.formBuilder.group({
      password: [passwordReset.password, [Validators.required]],
      passwordConfirm: [passwordReset.passwordConfirm, [Validators.required]]
    });
    this.form.markAsPristine();
  }

  updatePassword(passwordUpdate, isValid, $event: Event): void {
    $event.preventDefault();

    if (!isValid) {
      this.error = 'Please ensure the form is completed correctly';
      return;
    }

    if (passwordUpdate.password !== passwordUpdate.passwordConfirm) {
      this.error = 'Please ensure the passwords match';
      return;
    }

    this.formSubmitted = true;

    this.error = undefined;
    this.success = undefined;

    this.loaderService.display(true);

    this.authService.updatePassword(passwordUpdate.password, this.token)
      .subscribe(x => {
        this.loaderService.display(false);
        this.formSubmitted = false;
        this.success = true;
      }, err => {
        this.loaderService.display(false);
        this.formSubmitted = false;
        this.error = err;
      });
  }

}
