import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthContext } from '../../../services/auth.context';
import { AuthService } from '../../../services/auth.service';
import { LoaderService } from '../../../services/loader.service';
import { CacheService } from '../../../services/cache.service';

import { User } from '../../../models/user';

@Component({
  selector: 'app-verify',
  templateUrl: './verify.component.html',
  styleUrls: ['./verify.component.scss']
})
export class VerifyComponent implements OnInit {

  private token: string;
  private error: string;
  
  public inviteToken: string;

  constructor(
    private authContext: AuthContext,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private loaderService: LoaderService,
    private cacheService: CacheService) {}

  ngOnInit() {
    this.error = null;

    this.route.params.subscribe(params => {
      this.token = params['token'];
      this.inviteToken = params['inviteToken'];

      if (!this.token) {
        this.error = 'Token is missing';
        return;
      }

      this.loaderService.display(true);

      this.authService.verifyEmail(this.token)
        .subscribe(x => {
          this.loaderService.display(false);

          this.authService.loginByVerifiedToken(this.token, this.inviteToken)
            .subscribe(memoryId => {
              this.cacheService.setCacheValue('registering', true);
              this.authContext.startRegistration();
              if (this.inviteToken) {
                this.cacheService.setCacheValue('invitee', true);
                this.router.navigate(['/dashboard/memory/' + memoryId + '/bubble/new']);
              } else {
                this.router.navigate(['/dashboard/signup-wizard/step1']);
              }
            }, err => {
              this.error = err;
            });

        }, err => {
          this.loaderService.display(false);
          this.error = err;
        });
    });
  }

}
