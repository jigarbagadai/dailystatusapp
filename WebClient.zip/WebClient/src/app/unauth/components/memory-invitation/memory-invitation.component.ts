import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import { LoaderService } from '../../../services/loader.service';
import { MemoryService } from '../../../services/memory.service';

import { Memory } from '../../../models/memory';

@Component({
  selector: 'app-memory-invitation',
  templateUrl: './memory-invitation.component.html',
  styleUrls: ['./memory-invitation.component.scss']
})
export class MemoryInvitationComponent implements OnInit {

  private token: string;
  private memory: Memory;
  private error: string;

  constructor(
    private route: ActivatedRoute,
    private loaderService: LoaderService,
    private memoryService: MemoryService) {
      this.memory = new Memory();
    }

  ngOnInit() {
    this.error = null;

    this.route.params.subscribe(params => {
      this.token = params['inviteToken'];

      if (!this.token) {
        this.error = 'Required parameters have not been provided';
        return;
      }

      this.loaderService.display(true);

      this.memoryService.accessUnauthMemory(this.token)
        .subscribe(x => {
          this.loaderService.display(false);
          this.memory = x;
        }, err => {
          this.loaderService.display(false);
          this.error = err;
        });
    });
  }

  onClickPerson(userId: number) {
  }

}
