import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from '../shared/shared.module';
import { unauthRouting } from './unauth.routes';

import { UnauthComponent } from './components/unauth.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { VerifyComponent } from './components/verify/verify.component';
import { PasswordResetComponent } from './components/password-reset/password-reset.component';
import { PasswordUpdateComponent } from './components/password-update/password-update.component';
import { MemoryInvitationComponent } from './components/memory-invitation/memory-invitation.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    unauthRouting,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    UnauthComponent,
    LoginComponent,
    SignupComponent,
    VerifyComponent,
    PasswordResetComponent,
    PasswordUpdateComponent,
    MemoryInvitationComponent
  ]
})
export class UnauthModule { }
