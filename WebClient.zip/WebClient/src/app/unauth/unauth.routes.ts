import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UnauthComponent } from './components/unauth.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { PasswordResetComponent } from './components/password-reset/password-reset.component';
import { PasswordUpdateComponent } from './components/password-update/password-update.component';
import { VerifyComponent } from './components/verify/verify.component';
import { MemoryInvitationComponent } from './components/memory-invitation/memory-invitation.component';

const unauthRoutes: Routes = [
  {
    path: 'u',
    component: UnauthComponent,
    children: [
      { path: 'login', component: LoginComponent },
      { path: 'login/:inviteToken', component: LoginComponent },
      { path: 'signup', component: SignupComponent },
      { path: 'signup/:inviteToken', component: SignupComponent },
      { path: 'password-reset', component: PasswordResetComponent },
      { path: 'password-update/:token', component: PasswordUpdateComponent },
      { path: 'verify/:token', component: VerifyComponent },
      { path: 'verify/:token/:inviteToken', component: VerifyComponent },
      { path: 'memory-invitation/:inviteToken', component: MemoryInvitationComponent }
    ]
  }, {
    path: 'login', redirectTo: '/u/login', pathMatch: 'full'
  }
];

export const unauthRouting: ModuleWithProviders = RouterModule.forChild(unauthRoutes);