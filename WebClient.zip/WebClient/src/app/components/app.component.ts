import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';

import { LoaderService } from '.././services/loader.service';
import { AuthContext } from ".././services/auth.context";
import { AppContext } from ".././services/app.context";

import { Angulartics2GoogleAnalytics } from 'angulartics2';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  showLoader: boolean;

  constructor(
    private loaderService: LoaderService,
    private authContext: AuthContext,
    private appContext: AppContext,
    private angulartics2: Angulartics2GoogleAnalytics)
  {
    this.appContext.appInitialized
      .subscribe(initialized => {
        this.angulartics2.eventTrack('started', { category: 'application' });
      });
      
    this.authContext.isLoggedIn
      .subscribe(loggedIn => {
        if (loggedIn) {
          this.angulartics2.setUsername(this.authContext.loggedInUser.userId.toString());
          this.angulartics2.setUserProperties({ 'dimension1': this.authContext.loggedInUser.userId.toString() });
          this.angulartics2.eventTrack('login', { category: 'account' });
        } else {
          this.angulartics2.setUsername(null);
          this.angulartics2.setUserProperties({ 'dimension1': null });
        }
      });
  }

  ngOnInit() {
    this.loaderService.status.subscribe((val: boolean) => {
        this.showLoader = val;
    });
  }
}
