import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { PopoverModule } from 'ng2-pop-over';

import { SharedModule } from '../shared/shared.module';

import { DashboardComponent } from './components/dashboard.component';
import { HomeComponent } from './components/home/home.component';
import { TimelineComponent } from './components/timeline/timeline.component';
import { MemoryViewComponent } from './components/memory-view/memory-view.component';
import { MemoryEditComponent } from './components/memory-edit/memory-edit.component';
import { BubbleViewComponent } from './components/bubble-view/bubble-view.component';
import { BubbleEditComponent } from './components/bubble-edit/bubble-edit.component';
import { SettingsComponent } from './components/settings/settings.component';
import { SettingsProfileComponent } from './components/settings-profile/settings-profile.component';
import { SettingsPeopleComponent } from './components/settings-people/settings-people.component';
import { SettingsCategoriesComponent } from './components/settings-categories/settings-categories.component';
import { SignupWizardComponent } from './components/signup-wizard/signup-wizard.component';
import { Step1Component } from './components/signup-wizard/step1/step1.component';
import { Step2Component } from './components/signup-wizard/step2/step2.component';
import { Step3Component } from './components/signup-wizard/step3/step3.component';
import { Step4Component } from './components/signup-wizard/step4/step4.component';
import { Step5Component } from './components/signup-wizard/step5/step5.component';
import { Step6Component } from './components/signup-wizard/step6/step6.component';
import { Step7Component } from './components/signup-wizard/step7/step7.component';

import { FileUploadModalComponent } from './components/file-upload-modal/file-upload-modal.component';
import { DateInputComponent } from './components/date-input/date-input.component';
import { SettingsPeopleSectionComponent } from './components/settings-people-section/settings-people-section.component';
import { SettingsCategoriesSectionComponent } from './components/settings-categories-section/settings-categories-section.component';
import { ConfirmModalComponent } from './components/confirm-modal/confirm-modal.component';

import { dashboardRouting } from './dashboard.routes';

import { D3Service } from 'd3-ng2-service';
import { DashboardService, TimelineUserResolver } from '../services/dashboard.service';
import { CategoryResolver, CategoryService } from '../services/category.service';
import { RelationResolver, RelationService } from '../services/relation.service';
import { MemoryResolver, MemoryService } from '../services/memory.service';
import { MemoryBubbleResolver, MemoryBubbleService } from '../services/memory-bubble.service';
import { NotificationService } from '../services/notification.service';
import { NotificationTypes } from '../services/notification-types';
import { TimelineFilterTypes } from '../services/timeline-filter-types';

import { BsDropdownModule } from 'ng2-bootstrap/dropdown';
import { ButtonsModule } from 'ng2-bootstrap/buttons';
import { TabsModule } from 'ng2-bootstrap/tabs';
import { ModalModule } from 'ng2-bootstrap/modal';
import { DatepickerModule } from 'ng2-bootstrap/datepicker';
import { TooltipModule } from 'ng2-bootstrap/tooltip';
import { CollapseModule } from 'ng2-bootstrap/collapse';

import { MyDatePickerModule } from 'mydatepicker';
import { FileUploadModule } from 'ng2-file-upload';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        dashboardRouting,
        FormsModule,
        ReactiveFormsModule,
        PopoverModule,
        FileUploadModule,
        BsDropdownModule.forRoot(),
        ButtonsModule.forRoot(),
        TabsModule.forRoot(),
        ModalModule.forRoot(),
        DatepickerModule.forRoot(),
        TooltipModule.forRoot(),
        CollapseModule.forRoot(),
        MyDatePickerModule
    ],
    declarations: [
        DashboardComponent,
        HomeComponent,
        TimelineComponent,
        MemoryViewComponent,
        MemoryEditComponent,
        BubbleViewComponent,
        BubbleEditComponent,
        SettingsProfileComponent,
        SettingsPeopleComponent,
        SettingsPeopleSectionComponent,
        SettingsCategoriesComponent,
        SettingsCategoriesSectionComponent,
        SignupWizardComponent,
        Step1Component,
        Step2Component,
        Step3Component,
        Step4Component,
        Step5Component,
        Step6Component,
        Step7Component,
        SettingsComponent,
        DateInputComponent,
        FileUploadModalComponent,
        ConfirmModalComponent
    ],
    providers: [
        D3Service,
        RelationService,
        RelationResolver,
        CategoryService,
        CategoryResolver,
        MemoryService,
        MemoryResolver,
        MemoryBubbleService,
        MemoryBubbleResolver,
        NotificationService,
        NotificationTypes,
        TimelineFilterTypes,
        DashboardService,
        TimelineUserResolver
    ]
})
export class DashboardModule { }
