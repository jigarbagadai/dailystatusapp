import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from '.././services/auth.guard';

import { DashboardComponent } from './components/dashboard.component';
import { HomeComponent } from './components/home/home.component';
import { TimelineComponent } from './components/timeline/timeline.component';
import { MemoryViewComponent } from './components/memory-view/memory-view.component';
import { MemoryEditComponent } from './components/memory-edit/memory-edit.component';
import { BubbleViewComponent } from './components/bubble-view/bubble-view.component';
import { BubbleEditComponent } from './components/bubble-edit/bubble-edit.component';
import { SettingsComponent } from './components/settings/settings.component';
import { SettingsProfileComponent } from './components/settings-profile/settings-profile.component';
import { SettingsPeopleComponent } from './components/settings-people/settings-people.component';
import { SettingsCategoriesComponent } from './components/settings-categories/settings-categories.component';
import { SignupWizardComponent } from './components/signup-wizard/signup-wizard.component';
import { Step1Component } from './components/signup-wizard/step1/step1.component';
import { Step2Component } from './components/signup-wizard/step2/step2.component';
import { Step3Component } from './components/signup-wizard/step3/step3.component';
import { Step4Component } from './components/signup-wizard/step4/step4.component';
import { Step5Component } from './components/signup-wizard/step5/step5.component';
import { Step6Component } from './components/signup-wizard/step6/step6.component';
import { Step7Component } from './components/signup-wizard/step7/step7.component';
import { MemoryResolver } from '../services/memory.service';
import { CategoryResolver } from '../services/category.service';
import { RelationResolver } from '../services/relation.service';
import { MemoryBubbleResolver } from '../services/memory-bubble.service';
import { TimelineUserResolver } from '../services/dashboard.service';

const dashboardRoutes: Routes = [
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'home',
        component: HomeComponent,
        resolve: {
          relations: RelationResolver
        }
      },
      {
        path: 'timeline/:userid',
        component: HomeComponent,
        resolve: {
          relationUser: TimelineUserResolver
        }
      },
      {
        path: 'memory/new',
        component: MemoryEditComponent,
        resolve: {
          categories: CategoryResolver,
          relations: RelationResolver
        }
      },
      {
        path: 'memory/edit/:id',
        component: MemoryEditComponent,
        resolve: {
          memory: MemoryResolver,
          categories: CategoryResolver,
          relations: RelationResolver
        }
      },
      {
        path: 'memory/:id',
        component: MemoryViewComponent,
        resolve: {
          memory: MemoryResolver
        }
      },
      {
        path: 'memory/:memid/bubble/new',
        component: BubbleEditComponent,
        resolve: {
          memoryBubble: MemoryBubbleResolver,
          relations: RelationResolver
        }
      },
      {
        path: 'memory/:memid/bubble/:bubbleid',
        component: BubbleViewComponent,
        resolve: {
          memoryBubble: MemoryBubbleResolver,
          relations: RelationResolver
        }
      },
      {
        path: 'memory/:memid/bubble/edit/:bubbleid',
        component: BubbleEditComponent,
        resolve: {
          memoryBubble: MemoryBubbleResolver,
          relations: RelationResolver
        }
      },
      { path: 'settings', component: SettingsComponent },
      { path: 'settings-profile', component: SettingsProfileComponent },
      { path: 'settings-people', component: SettingsPeopleComponent },
      { path: 'settings-categories', component: SettingsCategoriesComponent },
      {
        path: 'signup-wizard',
        component: SignupWizardComponent,
        canActivate: [AuthGuard],
        children: [
          {
            path: 'step1',
            component: Step1Component
          },
          {
            path: 'step2',
            component: Step2Component
          },
          {
            path: 'step3',
            component: Step3Component,
            resolve: {
              categories: CategoryResolver
            }
          },
          {
            path: 'step4',
            component: Step4Component
          },
          {
            path: 'step5',
            component: Step5Component
          },
          {
            path: 'step6',
            component: Step6Component
          },
          {
            path: 'step7',
            component: Step7Component
          }
        ]
      }
    ]
  }
];

export const dashboardRouting: ModuleWithProviders = RouterModule.forChild(dashboardRoutes);