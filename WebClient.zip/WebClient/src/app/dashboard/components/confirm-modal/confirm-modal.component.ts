﻿import { Component, ViewChild, Input, Output, ViewEncapsulation, EventEmitter } from '@angular/core';
import { ModalDirective } from 'ng2-bootstrap/modal';
@Component({
    selector: 'app-confirm-modal',
    templateUrl: './confirm-modal.component.html',
    encapsulation: ViewEncapsulation.None
})
export class ConfirmModalComponent {
    @ViewChild('confirmModal') public confirmModal: ModalDirective;
    @Input() title: string;
    @Input() message: string;
    returnParams: string;
    @Output() onButtonClick = new EventEmitter();


    showConfirmModal(indexParams: string): void {
        this.returnParams = indexParams;
        this.confirmModal.show();
    }

    onHideConfirmModal($event: Event): void {
        $event.preventDefault();
        this.confirmModal.hide();
    }

    onYesButtonClick($event: Event): void {
        $event.preventDefault();
        this.confirmModal.hide();
        this.onButtonClick.emit({ dialogResult: 'YES', returnParams: this.returnParams });
    }

    onNoButtonClick($event: Event): void {
        $event.preventDefault();
        this.confirmModal.hide();
        this.onButtonClick.emit({ dialogResult: 'NO', returnParams: this.returnParams });
    }
}
