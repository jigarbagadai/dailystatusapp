import { Component, OnInit, ViewChild, Input, Output, ViewEncapsulation, EventEmitter } from '@angular/core';
import { MemoryService } from '../../../services/memory.service';
import { LoaderService } from '../../../services/loader.service';

import { AuthService } from '../../../services/auth.service';

import { File } from '../../../models/file';

import { ModalDirective } from 'ng2-bootstrap/modal';
import { FileSelectDirective, FileDropDirective, FileUploader, FileItem } from 'ng2-file-upload/ng2-file-upload';

@Component({
    selector: 'app-file-upload-modal',
    templateUrl: './file-upload-modal.component.html',
    styleUrls: ['./file-upload-modal.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class FileUploadModalComponent implements OnInit {

    private fileApi = '/api/file';

    @ViewChild('fileUploadModal') public fileUploadModal: ModalDirective;

    @Input() title: string;
    @Input() isMultiple: boolean;
    @Input() showFileUpload: Function;
    @Input() autoUpload: boolean;

    @Output() onUpdateFiles = new EventEmitter();
    @Output() onClearAllFiles = new EventEmitter();

    public uploader: FileUploader;
    public hasBaseDropZoneOver: boolean;
    public files: File[] = [];
    public uploadedfiles: File[] = [];

    constructor(
        private authService: AuthService, private memoryService: MemoryService, private loaderService: LoaderService)
    { }

    ngOnInit() {
        this.uploader = new FileUploader({
            url: this.fileApi,
            autoUpload: this.autoUpload,
            authToken: 'Bearer ' + this.authService.getAuthBeaerToken(),
            maxFileSize: 1024 * 1024 * 10, // 10 megabytes
            //allowedMimeType: ['image/png', 'image/jpg', 'image/jpeg']
        });
        this.uploader.onCompleteItem = this.onCompleteItem.bind(this);
        this.uploader.onBeforeUploadItem = this.onBeforeUploadItem.bind(this);
    }

    showUploadModal(): void {
        this.fileUploadModal.show();
    }

    onHideUploadModal($event: Event): void {
        $event.preventDefault();
        this.uploader.clearQueue();
        this.fileUploadModal.hide();
    }

    public fileOverBase(e: any): void {
        this.hasBaseDropZoneOver = e;
    }

    public onBeforeUploadItem(fileItem: FileItem) {
        this.loaderService.display(true);
    }

    public onCompleteItem(item: any, response: string, status: number, header: any): any {
        this.loaderService.display(false);
        this.files = JSON.parse(response) as File[];
        this.files.forEach(file => {
            this.uploadedfiles.push(file);
        });

        this.onUpdateFiles.emit(this.files);

        if (this.autoUpload) {
            this.uploader.clearQueue();
            this.fileUploadModal.hide();
        }
    }

    public onClearAll() {
        let fileids: string = '';
        this.uploadedfiles.forEach(file => {
            if (fileids.length > 0) {
                fileids = fileids + ",";
            }

            fileids = fileids + file.id;
        });

        this.loaderService.display(true);
        this.memoryService.removeAttachement(fileids).subscribe(x => {
            this.loaderService.display(false);
            this.uploader.clearQueue()
            this.onClearAllFiles.emit();
        }, err => {
            this.loaderService.display(false);
        });
    }

}
