﻿import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { Relation } from '../../../models/Relation';

@Component({
    selector: 'settings-people-section',
    templateUrl: './settings-people-section.component.html'
})
export class SettingsPeopleSectionComponent implements OnInit {

    @Input() data: Relation;
    @Input() index;
    @Output() onPeopelRelationSave = new EventEmitter();
    @Output() onPeopelRelationDelete = new EventEmitter();

    relationShipTypes = Array<string>();
    peopelTimelineShared: string;
    public peopelForm: FormGroup;

    ngOnInit(): void {
        this.peopelForm = this.initRelation(this.data);
        this.peopelTimelineShared = this.data.timelineShared ? 'YES' : 'NO';
        this.relationShipTypes = Array<string>();
        this.relationShipTypes.push('Friend');
        this.relationShipTypes.push('Husband');
        this.relationShipTypes.push('Wife');
        this.relationShipTypes.push('Son');
        this.relationShipTypes.push('Daughter');
        this.relationShipTypes.push('Father');
        this.relationShipTypes.push('Mother');
        this.relationShipTypes.push('Brother');
        this.relationShipTypes.push('Sister');
        this.relationShipTypes.push('Aunt');
        this.relationShipTypes.push('Boyfriend');
        this.relationShipTypes.push('Cousin');
        this.relationShipTypes.push('Fiancé');
        this.relationShipTypes.push('Girlfriend');
        this.relationShipTypes.push('Grandfather');
        this.relationShipTypes.push('Grandmother');
        this.relationShipTypes.push('Guardian');
        this.relationShipTypes.push('Nephew');
        this.relationShipTypes.push('Niece');
        this.relationShipTypes.push('Partner');
        this.relationShipTypes.push('Uncle');
    }

    constructor(private formbuilder: FormBuilder) {
    }

    initRelation(relation: Relation) {
        const emailRegex: string = '^[^@]+@[^@]+\.[^@]+$';

        return this.formbuilder.group({
            userRelationId: [relation.userRelationId],
            firstName: [relation.firstName, Validators.required],
            lastName: [relation.lastName, Validators.required],
            relationshipType: [relation.relationshipType, Validators.required],
            emailAddress: [relation.emailAddress, [Validators.required, Validators.pattern(emailRegex)]],
            screenName: [relation.screenName, Validators.required],
            timelineShared: [relation.timelineShared || false],
            iseditable: [relation.iseditable]
        });
    }

    editSelectedPeopel($event: Event, relation: Relation) {
        $event.preventDefault();
        if (relation.iseditable) {
            if (relation.userRelationId > 0) {
                relation.iseditable = false;
            } else {
                this.onPeopelRelationDelete.emit(relation);
            }
        } else {
            relation.iseditable = true;
        }
    }

    cancelEdit($event: Event, relation: Relation) {
        $event.preventDefault();
        if (relation.userRelationId > 0) {
            relation.iseditable = false;
        } else {
            this.onPeopelRelationDelete.emit(relation);
        }
    }

    onSaveRelation($event: Event, formrelation: Relation, datarelation: Relation) {
        $event.preventDefault();
        datarelation.iseditable = false;

        formrelation.relationshipType = datarelation.relationshipType;
        formrelation.timelineShared = this.peopelTimelineShared === 'YES';
        this.onPeopelRelationSave.emit(formrelation);
    }

    onDelete($event: Event, index: number) {
        $event.preventDefault();
        this.onPeopelRelationDelete.emit(index);
    }

    onRelationChange($event: Event, relationshipType: string, relation: Relation) {
        $event.preventDefault();
        relation.relationshipType = relationshipType;
    }

    onChangeTimeLineShared(value: string) {
        this.peopelTimelineShared = value ;
    }

}