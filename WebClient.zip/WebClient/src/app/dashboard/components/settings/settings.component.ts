import { Component, OnInit, ViewChild } from '@angular/core';
import { TabsetComponent } from 'ng2-bootstrap/tabs';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {

  @ViewChild('staticTabs') staticTabs: TabsetComponent;

  public activeTabIdx: number;

  constructor() { }

  ngOnInit() {
    this.activeTabIdx = 0;
  }

  selectTab(idx: number) {
    this.activeTabIdx = idx;
    this.staticTabs.tabs[idx].active = true;
  }

}
