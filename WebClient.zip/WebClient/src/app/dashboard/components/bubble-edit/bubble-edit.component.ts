import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { MemoryBubbleService } from '../../../services/memory-bubble.service';
import { LoaderService } from '../../../services/loader.service';
import { CacheService } from '../../../services/cache.service';
import { MemoryBubble } from '../../../models/memory-bubble';
import { MemoryBubblePerson } from '../../../models/memory-bubble-person';
import { MemoryBubbleAttachment } from '../../../models/memory-bubble-attachment';
import { Relation } from '../../../models/relation';
import { File } from '../../../models/file';

import { FileUploadModalComponent } from '../file-upload-modal/file-upload-modal.component';

import * as _ from 'lodash';

@Component({
  selector: 'app-bubble-edit',
  templateUrl: './bubble-edit.component.html',
  styleUrls: ['./bubble-edit.component.scss']
})
export class BubbleEditComponent implements OnInit {

  public memoryBubble: MemoryBubble;
  public memoryBubbleForm: FormGroup;
  public persons: MemoryBubblePerson[];

  public error: string;
  public success: string;
  public formSubmitted: boolean;

  @ViewChild('fileUpload') public fileUpload: FileUploadModalComponent;

  isExistingMemoryBubble() {
    return !!this.memoryBubble && !!this.memoryBubble.memoryBubbleId;
  }

  constructor(
    private memoryBubbleService: MemoryBubbleService,
    private loaderService: LoaderService,
    private cacheService: CacheService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.formSubmitted = false;
    this.route.data.subscribe((data: { memoryBubble: MemoryBubble, relations: Relation[] }) => {
      this.memoryBubble = data.memoryBubble;
      if (!this.isExistingMemoryBubble()) {
        // if its a new memory bubble, then populate the people list with the memory people that are in the current users relations
        this.persons = _.map(data.memoryBubble.lstPeople, function (person) {
          if (person.userId) {
            let relation = _.find(data.relations, { relationUserId: person.userId });
            if (relation) {
              person.display = true;
              person.screenName = relation.screenName; // use the screen name on the current users relation
              return person;
            }
          }
          return _.extend({ display: false }, person);
        });
      } else {
        this.persons = _.map(data.memoryBubble.lstBubblePeople, function (person) {
          return _.extend({ display: true }, person);
        });
      }

    });
    this.buildForm(this.memoryBubble);
  }

  private buildForm(memoryBubble): void {
    this.memoryBubbleForm = this.formBuilder.group({
      memoryBubbleId: [memoryBubble.memoryBubbleId],
      memoryId: [memoryBubble.memoryId],
      date: [memoryBubble.date],
      dateText: [{ value: memoryBubble.dateText, disabled: true }],
      locationView: [{ value: memoryBubble.location, disabled: true }, [Validators.required]],
      location: [memoryBubble.location, []],
      locationModel: [memoryBubble.locationModel, []],
      lstBubblePeople: [memoryBubble.lstBubblePeople, []],
      lstMemoryBubbleAttachment: [memoryBubble.lstMemoryBubbleAttachment, []],
      title: [{ value: memoryBubble.title, disabled: true }, []],
      description:  [{ value: memoryBubble.description, disabled: true }],
      bubbleDescription: [memoryBubble.bubbleDescription, [Validators.required]]
    });
    this.memoryBubbleForm.markAsPristine();
  }

  addPerson(e, person) {
    person.display = true;
  }

  removePerson(e, person) {
    e.preventDefault();
    person.display = false;
  }

  removeAttachment(e, attachment) {
    e.preventDefault();
    _.remove(this.memoryBubble.lstMemoryBubbleAttachment, { 'fileIdentifier': attachment.fileIdentifier });
  }

  saveMemoryBubble(memoryBubble, isValid, $event: Event): void {
    $event.preventDefault();
    if (!isValid) {
      this.error = 'Please ensure the form is completed correctly';
      return;
    }

    this.formSubmitted = true;

    this.error = undefined;
    this.success = undefined;
    memoryBubble.lstBubblePeople = _.map(_.filter(this.persons, { display: true }), 'userId');

    if (this.isExistingMemoryBubble()) {
      this.updateMemoryBubble(memoryBubble);
    } else {
      this.addMemoryBubble(memoryBubble);
    };
  }

  addMemoryBubble(memoryBubble: MemoryBubble) {
    this.loaderService.display(true);

    this.memoryBubbleService.addMemoryBubble(memoryBubble)
      .subscribe(x => {
        this.formSubmitted = false;
        this.loaderService.display(false);
        if (this.cacheService.getCacheValue("invitee")) {
          this.router.navigate(['/dashboard/signup-wizard/step1']);
        } else {
          this.router.navigate(['/dashboard/home']);
        }
      }, err => {
        this.error = err;
        this.formSubmitted = false;
      });
  }

  updateMemoryBubble(memoryBubble: MemoryBubble) {
    this.loaderService.display(true);
    this.memoryBubbleService.updateMemoryBubble(memoryBubble)
      .subscribe(x => {
        this.formSubmitted = false;
        this.loaderService.display(true);
        this.router.navigate(['/dashboard/home']);
      }, err => {
        this.error = err;
        this.loaderService.display(true);
        this.formSubmitted = false;
      });
  }

  openPhotoUpload($event: Event): void {
    $event.preventDefault();

    this.fileUpload.showUploadModal();
  }

  onBubblePhotosUpdated(files: File[]): void {
    if (!files || !files.length) {
      return;
    }

    files.forEach(file => {
      this.memoryBubble.lstMemoryBubbleAttachment.push({
        bubbleAttachmentId: 0,
        memoryBubbleId: this.memoryBubble.memoryBubbleId || 0,
        fileName: file.name,
        fileIdentifier: file.id,
        attachmentUrl: file.url
      } as MemoryBubbleAttachment);
    });
  }

  onClearAllFiles() {
      for (var i = 0; i <= this.memoryBubble.lstMemoryBubbleAttachment.length; i++) {
          this.memoryBubble.lstMemoryBubbleAttachment.pop();
      }
  }
}
