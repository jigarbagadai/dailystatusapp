import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';

import { AuthService } from '../../services/auth.service';
import { AuthContext } from '../../services/auth.context';
import { CacheService } from '../../services/cache.service';
import { NotificationService } from '../../services/notification.service';
import { NotificationTypes } from '../../services/notification-types';

import { User } from '../../models/user';
import { Notification } from '../../models/notification';

import * as _ from 'lodash';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public profilePhotoUrl: string;
  public showWizardLink: boolean;

  public bookmarksOpen: boolean;
  public bookmarks: Notification[] = [];
  public memoriesOpen: boolean;
  public memories: Notification[] = [];
  public bubblesOpen: boolean;
  public bubbles: Notification[] = [];

  constructor(
    private authService: AuthService,
    private authContext: AuthContext,
    private cacheService: CacheService,
    private notificationService: NotificationService,
    private notificationTypes: NotificationTypes,
    private router: Router) { }

  ngOnInit() {
    this.profilePhotoUrl = this.authContext.loggedInUser.profilePhotoUrl || 'assets/images/icon-user.png';

    this.notificationService.bookmarks
      .subscribe(bookmarks => {
        this.bookmarks = bookmarks;
      });
    this.notificationService.memories
      .subscribe(memories => {
        this.memories = memories;
      });
    this.notificationService.bubbles
      .subscribe(bubbles => {
        this.bubbles = bubbles;
      });

    this.authContext.isLoggedIn
      .subscribe(loggedIn => {
        if (this.authContext.loggedInUser) {
          this.profilePhotoUrl = this.authContext.loggedInUser.profilePhotoUrl;
        }
        this.profilePhotoUrl = this.profilePhotoUrl || 'assets/images/icon-user.png';
      });

    this.authContext.isRegistering
      .subscribe(isRegistering => {
        this.showWizardLink = isRegistering;
      });

  }

  onToggleBookmarks($event: Event): void {
    $event.preventDefault();
    this.bookmarksOpen = !this.bookmarksOpen;
    this.memoriesOpen = false;
    this.bubblesOpen = false;
  }

  onClickBookmark($event: Event, bookmark: Notification): void {
    $event.preventDefault();

    this.bookmarksOpen = false;
    if (bookmark.param1 && bookmark.param2) {
      this.router.navigate(['/dashboard/memory/' + bookmark.param1 + '/bubble/' + bookmark.param2]);
    } else {
      this.router.navigate(['/dashboard/memory/' + bookmark.param1]);
    }
  }

  onToggleMemories($event: Event): void {
    $event.preventDefault();
    this.memoriesOpen = !this.memoriesOpen;
    this.bookmarksOpen = false;
    this.bubblesOpen = false;
  }

  onClickMemory($event: Event, memory: Notification): void {
    $event.preventDefault();

    this.memoriesOpen = false;
    this.router.navigate(['/dashboard/memory/' + memory.param1]);
  }

  onToggleBubbles($event: Event): void {
    $event.preventDefault();
    this.bubblesOpen = !this.bubblesOpen;
    this.bookmarksOpen = false;
    this.memoriesOpen = false;
  }

  onClickBubble($event: Event, bubble: Notification): void {
    $event.preventDefault();

    this.bubblesOpen = false;
    this.router.navigate(['/dashboard/memory/' + bubble.param1 + '/bubble/' + bubble.param2]);
  }

  onCloseNotification($event: Event, notification: Notification): void {
    $event.preventDefault();

    if (notification.type === this.notificationTypes.memory) {
      _.remove(this.memories, { param1: notification.param1 });
    } else if (notification.type === this.notificationTypes.bubble) {
      _.remove(this.bubbles, { param1: notification.param1, param2: notification.param2 });
    }

    this.notificationService.openNotification(notification)
      .subscribe(bookmarks => {
        this.notificationService.loadNotifications()
          .subscribe(memories => { });
      });
  }

  logout($event: Event): void {
    $event.preventDefault();

    this.authService.logout();
    this.router.navigate(['/u/login']);
  }

}
