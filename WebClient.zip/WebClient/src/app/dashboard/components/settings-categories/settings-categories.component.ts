import { Component, OnInit, ViewChild } from '@angular/core';
import { Category } from '../../../models/Category';
import { LoaderService } from '../../../services/loader.service';
import { CategoryService } from '../../../services/category.service';
import { ConfirmModalComponent } from '../confirm-modal/confirm-modal.component';


@Component({
    selector: 'app-settings-categories',
    templateUrl: './settings-categories.component.html',
    styleUrls: ['./settings-categories.component.scss']
})
export class SettingsCategoriesComponent implements OnInit {
    public lstcategories: Category[];
    public error: any;
    public success: any;
    @ViewChild('categoryConfirmmodal') public categoryConfirm: ConfirmModalComponent;


    constructor(private categoryService: CategoryService, private loaderService: LoaderService) {
    }

    ngOnInit() {
        this.getAllCategories();
    }

    getAllCategories(): void {
        this.loaderService.display(true);
        this.categoryService.fetchOwnCategories()
            .subscribe(x => {
                this.loaderService.display(false);
                this.lstcategories = <Category[]>x;
            }, err => {
                this.loaderService.display(false);
            });
    }

    showAddCategory($event) {
        $event.preventDefault();
        var category = new Category();
        category.iseditable = true;
        category.iconUrl = '/assets/images/category-icons/other1.png';
        category.categoryId = 0;
        this.lstcategories.push(category);
    }

    onSaveCategory(category) {
        this.loaderService.display(true);
        this.success = '';
        this.error = '';

        if (category.categoryId == null || category.categoryId == 0) {
            category.categoryId = 0;
            this.categoryService.saveCategory(category).subscribe(x => {
                //this.success = "Category have successfully updated";
                this.loaderService.display(false);
                this.getAllCategories();
            }, err => {
                this.loaderService.display(false);
                this.error = "Ooops... Something went wrong.";
            });
        }
        else {
            this.categoryService.updateCategory(category.categoryId, category).subscribe(x => {
                //this.success = "Category have successfully updated";
                this.loaderService.display(false);
                this.getAllCategories();
            }, err => {
                this.loaderService.display(false);
                this.error = "Ooops... Something went wrong.";
            });
        }
    }

    onRemoveCategory(index) {
        this.categoryConfirm.showConfirmModal(index.toString());
    }

    onButtonClick(event) {
        if (event.dialogResult == "YES") {
            this.success = '';
            this.error = '';
            let category: Category = this.lstcategories[parseInt(event.returnParams)];
            if (category.categoryId == 0) {
                this.lstcategories.pop();
            }
            else {
                this.loaderService.display(true);
                this.categoryService.deleteCategory(category.categoryId).subscribe(x => {
                    this.success = "record deleted sucessfully";
                    this.loaderService.display(false);
                    this.getAllCategories();
                }, err => {
                    this.loaderService.display(false);
                    this.error = "Ooops... Something went wrong.";
                });
            }
        }
    }

}
