import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';

import { ModalDirective } from 'ng2-bootstrap/modal';

import { AuthContext } from '../../../services/auth.context';
import { AuthService } from '../../../services/auth.service';
import { LoaderService } from '../../../services/loader.service';
import { User } from '../../../models/user';
import { File } from '../../../models/file';

import { FileUploadModalComponent } from '../file-upload-modal/file-upload-modal.component';

@Component({
  selector: 'app-settings-profile',
  templateUrl: './settings-profile.component.html',
  styleUrls: ['./settings-profile.component.scss']
})
export class SettingsProfileComponent implements OnInit {

  @ViewChild('passwordModal') public passwordModal: ModalDirective;
  @ViewChild('fileUpload') public fileUpload: FileUploadModalComponent;

  private user: User;
  public error: string;
  public success: string;
  public form: FormGroup;
  public formSubmitted: boolean;
  public selectedDateFormat: string;
  public dateOfBirthDate: Date = null;
  private myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
    showClearDateBtn: false,
    editableDateField: false
  };
  private selDate: any;

  constructor(
    private authService: AuthService,
    private authContext: AuthContext,
    private router: Router,
    private formBuilder: FormBuilder,
    private loaderService: LoaderService) {
    this.formSubmitted = false;
    this.selectedDateFormat = null;
    this.user = authContext.loggedInUser;
  }

  hasProfilePhoto() {
    return !!(this.form.controls['profilePhotoUrl'].value);
  }

  ngOnInit() {
    this.buildForm(new User());
  }

  private buildForm(userProfile): void {
    const emailRegex = '^[^@]+@[^@]+\.[^@]+$';

    userProfile = Object.assign({}, this.user);

    this.form = this.formBuilder.group({
      userId: [userProfile.userId],
      emailAddress: [userProfile.emailAddress, [Validators.required, Validators.pattern(emailRegex)]],
      firstName: [userProfile.firstName, [Validators.required]],
      lastName: [userProfile.lastName, [Validators.required]],
      dateOfBirth: userProfile.dateOfBirth,
      placeOfBirth: userProfile.placeOfBirth,
      mobile: userProfile.mobile,
      dateFormat: userProfile.dateFormat,
      profilePhotoUrl: userProfile.profilePhotoUrl
    });
    this.form.markAsPristine();

    if (userProfile.dateOfBirth) {
      this.dateOfBirthDate = new Date(userProfile.dateOfBirth);
      this.selDate = {
        year: this.dateOfBirthDate.getFullYear(),
        month: this.dateOfBirthDate.getMonth() + 1,
        day: this.dateOfBirthDate.getDate()
      };
    }
    if (userProfile.dateFormat)
      this.setDateFormat(userProfile.dateFormat);
  }

  SaveProfile(user, isValid, $event: Event): void {
    $event.preventDefault();

    if (!isValid) {
      this.error = 'Please ensure the form is completed correctly';
      return;
    }

    this.formSubmitted = true;

    this.error = undefined;
    this.success = undefined;

    this.loaderService.display(true);

    this.authService.updateUser(user)
      .subscribe(x => {
        this.loaderService.display(false);
        this.formSubmitted = false;
        this.authContext.login(user);
        this.success = 'Your details have been successfully updated.';
      }, err => {
        this.loaderService.display(false);
        this.formSubmitted = false;
        this.error = err;
      });
  }

  setDateFormat(str: string) {
    this.myDatePickerOptions.dateFormat = str.toLowerCase();
    this.selectedDateFormat = str;
    this.form.controls['dateFormat'].setValue(str);
  }

  setDateOfBirthDate(event: IMyDateModel) {
    let dateString = event.jsdate;
    if (dateString) {
      let date = new Date(dateString);
      this.dateOfBirthDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000)); // cancel out timezone offset
      this.selDate = event.date;
      this.form.patchValue({
        dateOfBirth: this.dateOfBirthDate.toISOString()
      });
    } else {
      this.dateOfBirthDate = null;
      this.form.patchValue({
        dateOfBirth: null
      });
    }
  }

  onPasswordUpdateClick($event: Event): void {
    $event.preventDefault();

    this.loaderService.display(true);

    this.authService.resetPassword(this.user.emailAddress)
      .subscribe(m => {
        this.loaderService.display(false);

        this.passwordModal.show();
      }, err => {
        this.loaderService.display(false);
      });
  }

  onPasswordUpdateHide($event: Event): void {
    $event.preventDefault();

    this.passwordModal.hide();
  }

  openPhotoUpload($event: Event): void {
    $event.preventDefault();

    this.fileUpload.showUploadModal();
  }

  onProfilePhotoUpdated(files: File[]): void {
    if (files && files.length) {
      this.form.controls['profilePhotoUrl'].setValue(files[0].url);
    }
  }

}
