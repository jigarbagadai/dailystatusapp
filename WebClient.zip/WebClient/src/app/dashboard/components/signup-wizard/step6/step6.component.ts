import { Component, ViewChild, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { MemoryService } from '../../../../services/memory.service';
import { LoaderService } from '../../../../services/loader.service';
import { File } from '../../../../models/file';
import { MemoryAttachment } from '../../../../models/memory-attachment';
import { Memory } from '../../../../models/memory';
import { FileUploadModalComponent } from '../../file-upload-modal/file-upload-modal.component';

import * as _ from 'lodash';

@Component({
  selector: 'app-signup-wizard-step6',
  templateUrl: './step6.component.html'
})

export class Step6Component implements OnInit {

  private memory: Memory;
  public saveToBookmarks: string;

  @ViewChild('fileUpload') public fileUpload: FileUploadModalComponent;

  constructor(
    private router: Router,
    private memoryService: MemoryService,
    private loaderService: LoaderService
  ) { }

  ngOnInit() {
    if (localStorage.getItem("memory")) {
      this.memory = JSON.parse(localStorage.getItem("memory"));
      if (!this.memory.lstMemoryAttachment) this.memory.lstMemoryAttachment = new Array<MemoryAttachment>();
      this.saveToBookmarks = this.memory.bookmarked ? 'YES' : 'NO';
    } else this.router.navigate(['dashboard', 'signup-wizard', 'step3']);
  }

  removeAttachment(e, attachment) {
    e.preventDefault();
    this.loaderService.display(true);

    this.memoryService.removeAttachement(attachment.fileIdentifier).subscribe(x => {
      this.loaderService.display(false);
      _.remove(this.memory.lstMemoryAttachment, { 'fileIdentifier': attachment.fileIdentifier });
    }, err => {
      this.loaderService.display(false);
    });
  }

  openPhotoUpload($event: Event): void {
    $event.preventDefault();

    this.fileUpload.showUploadModal();
  }

  onMemoryPhotosUpdated(files: File[]): void {
    if (!files || !files.length) {
      return;
    }

    files.forEach(file => {
      this.memory.lstMemoryAttachment.push({
        memoryAttachmentId: 0,
        memoryId: this.memory.memoryId || 0,
        fileName: file.name,
        fileIdentifier: file.id,
        attachmentUrl: file.url
      } as MemoryAttachment);
    });
  }

  updateSaveToBookmarks(value: string): void {
    this.memory.bookmarked = value === 'YES';
  }

  onClearAllFiles() {
      for (var i = 0; i <= this.memory.lstMemoryAttachment.length; i++) {
          this.memory.lstMemoryAttachment.pop();
      }
  }

  private updateAndNext($event: Event) {
    $event.preventDefault();
    localStorage.setItem('memory', JSON.stringify(this.memory));
    this.router.navigate(['dashboard', 'signup-wizard', 'step7']);
  }
}
