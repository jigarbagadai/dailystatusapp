import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { LoaderService } from '../../../../services/loader.service';
import { AuthService } from '../../../../services/auth.service';
import { CacheService } from '../../../../services/cache.service';
import { AuthContext } from '../../../../services/auth.context';
import { User } from '../../../../models/user';

@Component({
  selector: 'app-signup-wizard-step1',
  templateUrl: './step1.component.html'
})

export class Step1Component implements OnInit {

  private form: FormGroup;
  private error: string;
  private user: User;
  private fromBubblePage: boolean;
  public dateOfBirthDate: Date = null;
  private myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
    showClearDateBtn: false,
    editableDateField: false
  };
  private selDate: any;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private authContext: AuthContext,
    private loaderService: LoaderService,
    private cacheService: CacheService
  ) { }

  ngOnInit() {
    localStorage.removeItem('memory');
    this.fromBubblePage = this.cacheService.getCacheValue("invitee");
    this.user = this.authContext.loggedInUser;
    if (this.user.dateOfBirth) {
      this.dateOfBirthDate = new Date(this.user.dateOfBirth);
      this.selDate = {
        year: this.dateOfBirthDate.getFullYear(),
        month: this.dateOfBirthDate.getMonth() + 1,
        day: this.dateOfBirthDate.getDate()
      };
    }
    if (this.user.dateFormat)
      this.myDatePickerOptions.dateFormat = this.user.dateFormat.toLowerCase();
    this.buildForm(this.user);
  }

  private buildForm(user): void {
    this.form = this.formBuilder.group({
      dateOfBirth: [user.dateOfBirth, [Validators.required]],
      placeOfBirth: [user.placeOfBirth, [Validators.required]]
    });
    this.form.markAsPristine();

    if (user.dateOfBirth) {
      this.dateOfBirthDate = new Date(user.dateOfBirth);
    }
  }

  setDateOfBirthDate(event: IMyDateModel) {
    let dateString = event.jsdate;
    if (dateString) {
      let date = new Date(dateString);
      this.dateOfBirthDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000)); // cancel out timezone offset
      this.selDate = event.date;
      this.form.patchValue({
        dateOfBirth: this.dateOfBirthDate.toISOString()
      });
    } else {
      this.dateOfBirthDate = null;
      this.form.patchValue({
        dateOfBirth: null
      });
    }
  }

  private updateAndNext(user, isValid, $event: Event) {
    $event.preventDefault();
    if (!isValid) {
      this.error = "Please fill out all details correctly"
    } else {
      this.user.dateOfBirth = new Date(user.dateOfBirth).toISOString();
      this.user.placeOfBirth = user.placeOfBirth;
      this.authService.updateUser(this.user)
        .subscribe(x => {
          this.loaderService.display(false);
          this.cacheService.removeFromCache("invitee");
          this.router.navigate(['dashboard', 'signup-wizard', 'step2']);
        }, err => {
          this.loaderService.display(false);
          this.error = err;
        });
    }
  }
}
