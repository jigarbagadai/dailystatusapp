import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup-wizard',
  templateUrl: './signup-wizard.component.html'
})

export class SignupWizardComponent implements OnInit {

  constructor(
    private router: Router
  ) { }

  ngOnInit() {
    this.router.navigate(['dashboard', 'signup-wizard', 'step1']);
  }
}
