import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Memory } from '../../../../models/memory';

import { AuthContext } from '../../../../services/auth.context';
import { MemoryService } from '../../../../services/memory.service';
import { LoaderService } from '../../../../services/loader.service';
import { CacheService } from '../../../../services/cache.service';
import { NotificationService } from '../../../../services/notification.service';

import * as _ from 'lodash';

@Component({
  selector: 'app-signup-wizard-step7',
  templateUrl: './step7.component.html'
})

export class Step7Component implements OnInit {

  private memory: Memory;
  private error: string;
  private success: string;

  constructor(
    private router: Router,
    private authContext: AuthContext,
    private memoryService: MemoryService,
    private loaderService: LoaderService,
    private cacheService: CacheService,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {
    if (localStorage.getItem("memory")) {
        this.memory = JSON.parse(localStorage.getItem("memory"));
    } else {
      this.router.navigate(['/dashboard/signup-wizard/step3']);
    }
  }

  private saveAndSend($event: Event) {
    $event.preventDefault();
    this.loaderService.display(true);
    let memory: any = this.memory;
    memory.lstPeople = _.map(this.memory.lstPeople, 'userRelationId');
    this.memoryService.addMemory(this.memory)
      .subscribe(x => {
        this.memoryService.updateMemoryUser(x.memoryId, true, this.memory.bookmarked)
          .subscribe(x => {
            this.loaderService.display(false);
            this.success = "Sent successfully";

            localStorage.removeItem("memory");
            this.cacheService.removeFromCache("registering");
            this.authContext.completeRegistration();

            this.notificationService.loadBookmarks()
              .subscribe(y => { });
          });
      }, err => {
        this.error = err;
        this.loaderService.display(false);
      });
  }
}
