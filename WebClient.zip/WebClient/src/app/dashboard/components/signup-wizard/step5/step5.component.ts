import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { Memory } from '../../../../models/memory';

@Component({
  selector: 'app-signup-wizard-step5',
  templateUrl: './step5.component.html'
})

export class Step5Component implements OnInit {

  private form: FormGroup;
  private memory: Memory;
  private error: string;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router
  ) { }

  ngOnInit() {
    if (localStorage.getItem("memory")) {
      this.memory = JSON.parse(localStorage.getItem("memory"));
      this.buildForm(this.memory);
    }
    else
      this.router.navigate(['/dashboard/signup-wizard/step3']);
  }


  private buildForm(memory): void {
    this.form = this.formBuilder.group({
      title: [memory.title, [Validators.required]],
      description: [memory.description, []]
    });
    this.form.markAsPristine();
  }

  private updateAndNext(memory, isValid, $event: Event) {
    $event.preventDefault();
    if (isValid) {
      this.memory.title = memory.title;
      this.memory.description = memory.description;
      localStorage.setItem("memory", JSON.stringify(this.memory));
      this.router.navigate(['dashboard', 'signup-wizard', 'step6']);
    } else this.error = 'Please fill out all fields correctly.';
  }
}
