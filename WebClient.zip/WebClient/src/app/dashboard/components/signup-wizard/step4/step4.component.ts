import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { LoaderService } from '../../../../services/loader.service';
import { RelationService } from '../../../../services/relation.service';
import { Relation } from '../../../../models/Relation';
import { Memory } from '../../../../models/memory';

@Component({
  selector: 'app-signup-wizard-step4',
  templateUrl: './step4.component.html'
})

export class Step4Component implements OnInit {

  private memory: Memory;
  private peopleForm: FormGroup;
  private relation: Relation;
  private relations: Relation[];
  private relationShipTypes: string[];
  private error: string;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private loaderService: LoaderService,
    private relationService: RelationService
  ) { }

  getAllRelations(): void {
    this.loaderService.display(true);
    this.relationService.fetchRelations()
      .subscribe(x => {
        this.loaderService.display(false);
        this.relations = <Relation[]>x;
        this.memory.lstPeople = this.relations;
      }, err => {
        this.loaderService.display(false);
      });
  }

  ngOnInit() {
    if (localStorage.getItem("memory")) {
      this.memory = JSON.parse(localStorage.getItem("memory"));
      if (this.memory.lstPeople)
        this.relations = <Relation[]>this.memory.lstPeople;
      else
        this.relations = new Array<Relation>();
    }
    else {
      this.router.navigate(['/dashboard/signup-wizard/step3']);
    }
    this.getAllRelations();
    this.relation = new Relation();
    this.relationShipTypes = Array<string>();
    this.relationShipTypes.push('Friend');
    this.relationShipTypes.push('Husband');
    this.relationShipTypes.push('Wife');
    this.relationShipTypes.push('Son');
    this.relationShipTypes.push('Daughter');
    this.relationShipTypes.push('Father');
    this.relationShipTypes.push('Mother');
    this.relationShipTypes.push('Brother');
    this.relationShipTypes.push('Sister');
    this.relationShipTypes.push('Aunt');
    this.relationShipTypes.push('Boyfriend');
    this.relationShipTypes.push('Cousin');
    this.relationShipTypes.push('Fiancé');
    this.relationShipTypes.push('Girlfriend');
    this.relationShipTypes.push('Grandfather');
    this.relationShipTypes.push('Grandmother');
    this.relationShipTypes.push('Guardian');
    this.relationShipTypes.push('Nephew');
    this.relationShipTypes.push('Niece');
    this.relationShipTypes.push('Partner');
    this.relationShipTypes.push('Uncle');
    this.relation.relationshipType = this.relationShipTypes[0];
    this.buildForm(this.relation);
  }

  private buildForm(relation: Relation): void {
    const emailRegex: string = '^[^@]+@[^@]+\.[^@]+$';

    this.peopleForm = this.formBuilder.group({
      userRelationId: [relation.userRelationId],
      firstName: [relation.firstName, Validators.required],
      lastName: [relation.lastName, Validators.required],
      relationshipType: [relation.relationshipType, Validators.required],
      emailAddress: [relation.emailAddress, [Validators.required, Validators.pattern(emailRegex)]],
      screenName: [relation.screenName, Validators.required],
      timelineShared: [relation.timelineShared || true],
      iseditable: [relation.iseditable]
    });
    this.peopleForm.markAsPristine();
  }

  private saveRelation(relation, isValid, $event: Event) {
    $event.preventDefault();
    relation.timelineShared = true;
    this.loaderService.display(true);
    this.relationService.savePeople(relation).subscribe(x => {
      //this.success = "Details have successfully updated";
      this.loaderService.display(false);
      this.getAllRelations();
      this.relation = new Relation();
      this.relation.relationshipType = this.relationShipTypes[0];
      this.buildForm(this.relation);
      this.peopleForm.reset()
    }, err => {
      this.loaderService.display(false);
      this.error = "Ooops... Something went wrong.";
    });
  }

  onRelationChange($event, relationship) {
    $event.preventDefault();
    this.relation.relationshipType = relationship;
    this.peopleForm.patchValue({ relationshipType: relationship });
  }

  private removeRelation($event: Event, relation) {
    $event.preventDefault();
    this.loaderService.display(true);
    this.relationService.deletePeople(relation.userRelationId).subscribe(x => {
      this.loaderService.display(false);
      this.getAllRelations();
    }, err => {
      this.loaderService.display(false);
      this.error = "Ooops... Something went wrong.";
    });
  }

  private updateAndNext($event: Event) {
    $event.preventDefault();
    localStorage.setItem('memory', JSON.stringify(this.memory));
    this.router.navigate(['dashboard', 'signup-wizard', 'step5']);
  }
}

