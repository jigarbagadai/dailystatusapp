import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Memory } from '../../../../models/memory';
import { Category } from '../../../../models/category';

import * as _ from 'lodash';
declare var google: any;

@Component({
  selector: 'app-signup-wizard-step3',
  templateUrl: './step3.component.html'
})

export class Step3Component implements OnInit {

  private form: FormGroup;
  private memory: Memory;
  private categories: Category[];
  private selectedCategory: string;
  private error: string;

  @ViewChild('search')
  private searchElementRef: ElementRef;

  constructor(
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private router: Router,
    private ngZone: NgZone
  ) {
    this.selectedCategory = null;
  }

  ngOnInit() {
    this.route.data.subscribe((data: { categories: Category[] }) => {
      this.categories = data.categories;
      if (localStorage.getItem('memory')) {
        this.memory = JSON.parse(localStorage.getItem('memory'));
      } else {
        this.memory = new Memory();
      }

      this.buildForm(this.memory);

      if(this.memory.categoryId)
        this.setCategory(null, _.find(this.categories, { categoryId: this.memory.categoryId }));
      else
        this.setCategory(null, _.find(this.categories, { categoryId: 7 }));

      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: ['geocode']
      });
      autocomplete.addListener('place_changed', () => {
        this.ngZone.run(() => {
          let place: any = autocomplete.getPlace();

          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          this.form.controls['location'].setValue(place.name);
          this.form.controls['locationModel'].setValue({
            latitude: place.geometry.location.lat(),
            longitude: place.geometry.location.lng()
          });
        });
      });

    });
  }

  private buildForm(memory): void {
    this.form = this.formBuilder.group({
      date: [memory.date],
      dateText: [memory.dateText],
      categoryId: [memory.categoryId, []],
      locationView: [memory.location, [Validators.required]],
      location: [memory.location, []],
      locationModel: [memory.locationModel, []]
    });
    this.form.markAsPristine();
  }

  setCategory(e, category) {
    this.selectedCategory = category.name;
    this.form.controls['categoryId'].setValue(category.categoryId);
  }

  updatedDate(dateText: string) {
    this.form.patchValue({ dateText: dateText });
  }


  private updateAndNext(memory, isValid, $event: Event) {
    if (isValid) {
      memory.categoryName = this.selectedCategory;
      this.memory.categoryId = memory.categoryId;
      this.memory.categoryName = memory.categoryName;
      this.memory.date = memory.date;
      this.memory.dateText = memory.dateText;
      this.memory.location = memory.location;
      this.memory.locationModel = memory.locationModel;
      localStorage.setItem('memory', JSON.stringify(this.memory));
      this.router.navigate(['dashboard', 'signup-wizard', 'step4']);
    }
    else
      this.error = 'Please fill all the fields correctly';
  }
}
