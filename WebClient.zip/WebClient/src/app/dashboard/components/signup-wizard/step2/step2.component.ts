import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup-wizard-step2',
  templateUrl: './step2.component.html'
})

export class Step2Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
