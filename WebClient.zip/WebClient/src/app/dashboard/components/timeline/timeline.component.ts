import { Component, OnInit, OnChanges, ElementRef, ViewEncapsulation, ViewChild, Input, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';

import { D3Service, D3, Selection } from 'd3-ng2-service';

import { MemoryService } from '../../../services/memory.service';
import { MemoryBubbleService } from '../../../services/memory-bubble.service';
import { LoaderService } from '../../../services/loader.service';

import { ModalDirective } from 'ng2-bootstrap/modal';

import { User } from '../../../models/user';
import { TimelineMemory } from '../../../models/timeline-memory';
import { Memory } from '../../../models/memory';
import { MemoryBubble } from '../../../models/memory-bubble';
import { Relation } from '../../../models/relation';

import * as moment from 'moment';
import * as _ from 'lodash';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TimelineComponent implements OnInit, OnChanges {

  @ViewChild('memoryModal') public memoryModal: ModalDirective;
  @ViewChild('bubblesModal') public bubblesModal: ModalDirective;

  @Input() user: User;
  @Input() memories: TimelineMemory[] = [];
  @Input() relations: Relation[] = [];

  private d3: D3;
  private nativeElement: any;

  private svg: any;
  private scatterPlot: any;

  private timelineWidth: number;
  private timelineHeight: number;
  private timelinePadding = 50;

  public selectedMemory: Memory = new Memory();
  public selectedBubbleSummaries: MemoryBubble[] = [];

  private renderSettings = {
    xWidth: 20000, // how "wide" the sine curve is
    cycles: 3, // how many times the sinusoid repeats
    density: 1000, // the number of discrete points per cycle
    animatePoints: 800,
    categoryIconWidth: 40,
    categoryIconHeight: 40,
    bubbleRadius: 12,
    bubbleOffset: 5,
    bubbleTextSize: 13,
    bubbleTextOffsetX: 2,
    bubbleTextOffsetY: 16,
    profileImageWidth: 48,
    profileImageHeight: 48,
    zoomLimit: 12,
    futureYears: 1
  };

  constructor(
    private element: ElementRef,
    private d3Service: D3Service,
    private router: Router,
    private memoryService: MemoryService,
    private memoryBubbleService: MemoryBubbleService,
    private loaderService: LoaderService) {

    this.d3 = d3Service.getD3();
    this.nativeElement = element.nativeElement;

    this.nativeElement.focus();
  }

  // A simple function that generates an array of {x, y} objects constrained to a
  // sine curve, according to certain input parameters.
  generateDataPoints(renderSettings, pointCount, boundaries) {
    const data = this.d3.range(pointCount);

    const x = this.d3.scaleLinear().domain([-1, 1]).range([-renderSettings.xWidth, renderSettings.xWidth]);
    const y = this.d3.scaleLinear().domain([pointCount, 0]).range([pointCount, 0]);

    const yD = this.d3.scaleLinear().domain([boundaries.start, boundaries.end]).range([pointCount, 0]);

    // create an object that contains a key/value reference between the memory position and the memory object
    const memoryMap = {};
    _.each(this.memories, function(memory, idx) {
      const point = Math.round(yD(new Date(memory.timestamp)));
      memoryMap[point] = memory;
    });

    return data.map(function (index) {
        // first, transform the x-value just like on a graph, then perform y-axis scaling for amplitude corrections
        let yPoint = y(index) * -1;
        const xPoint = x(Math.sin((yPoint) * (2 * Math.PI) / renderSettings.density));

        // factor in the bending back/forward of the curve
        const yOffsetPoint = y(index + (renderSettings.density / 2)) * -1;
        const xOffsetPoint = x(Math.sin((yOffsetPoint) * (4 * Math.PI) / renderSettings.density)) / 100;

        // apply the bend offset
        yPoint = yPoint - xOffsetPoint;

        const point = {
          x: xPoint,
          y: yPoint
        };

        if (!memoryMap[index]) {
          return point;
        }

        point['memory'] = memoryMap[index];

        return point;
    });
  }

  determineTodayPoint(pointCount, boundaries) {
    const yD = this.d3.scaleLinear().domain([boundaries.start, boundaries.end]).range([pointCount, 0]);

    return Math.round(yD(new Date()));
  }

  renderMemoryPoints(renderSettings, data, xScale, yScale, median) {
    const memoryPoints = _.filter(data, function(point) { return !!point.memory; });
    const memoryBounds = this.scatterPlot.selectAll('.memory-point').data(memoryPoints);

    const iconWidth = renderSettings.categoryIconWidth;
    const iconHeight = renderSettings.categoryIconHeight;

    memoryBounds.enter()
        .append('image')
        .classed('memory-point', true)
        .attr('transform', function(d: any) { return 'translate(-' + iconWidth / 2 + ', -' + iconWidth + ')'; })
        .attr('x', function (d) {
          return xScale(median(data.map(function(dm) { return dm.x; })));
        })
        .attr('y', function (d) {
          return yScale(0) ;
        })
      .merge(memoryBounds) // ENTER + UPDATE
        .transition().duration(renderSettings.animatePoints).delay(function (d, i) {
          return i * (renderSettings.animatePoints * 1 / data.length);
        })
        .attr('xlink:href', function(d: any) {
          return d.memory.categoryIconUrl || '/assets/images/pin_64x64.png';
        })
        .attr('x', function (d: any) {
          return xScale(d.x);
        })
        .attr('y', function (d: any) {
          return yScale(d.y);
        })
        .attr('width', iconWidth)
        .attr('height', iconHeight);

    memoryBounds.exit()
        .transition().duration(renderSettings.animatePoints)
        .attr('r', 0)
        .remove();
  }

  renderBubblePoints(renderSettings, data, xScale, yScale, median) {
    let isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);

    const bubblePoints = _.filter(data, function(point) { return !!point.memory && !!point.memory.bubbleCount; });
    const bubbleBounds = this.scatterPlot.selectAll('.bubble-point').data(bubblePoints);

    const bubbleNodes = bubbleBounds.enter()
        .append('g')
        .classed('bubble-point', true)
        .attr('transform', function(d: any) {
          return 'translate(' + xScale(median(data.map(function(dm) { return dm.x; }))) + ', ' + yScale(0) + ')';
        });

    bubbleNodes.merge(bubbleBounds) // ENTER + UPDATE
        .transition().duration(renderSettings.animatePoints).delay(function (d, i) {
          return i * (renderSettings.animatePoints * 1 / data.length);
        })
        .attr('transform', function(d: any) {
          return 'translate(' + xScale(d.x) + ', ' + yScale(d.y) + ')';
        });

    bubbleNodes
        .append('circle')
        .classed('bubble-circle', true)
        .attr('transform', function(d) { return 'translate(' + renderSettings.bubbleOffset + ', ' + renderSettings.bubbleRadius + ')'; })
        .style('fill', isSafari ? '#d3d3d3' : 'url(#radial-gradient)')
        .attr('cx', 0)
        .attr('cy', 0)
        .attr('r', renderSettings.bubbleRadius);

    bubbleNodes
        .append('text')
        .classed('bubble-text', true)
        .attr('transform', function(d) { return 'translate(' + renderSettings.bubbleTextOffsetX + ', ' + renderSettings.bubbleTextOffsetY + ')'; })
        .attr('x', 0)
        .attr('y', 0)
        .style('font-size', renderSettings.bubbleTextSize + 'px')
        .text(function(d: any){
          return d.memory.bubbleCount;
        });

    bubbleBounds.exit()
        .transition().duration(renderSettings.animatePoints)
        .attr('r', 0)
        .remove();
  }

  renderProfileImage(renderSettings, data, xScale, median, max) {
    this.scatterPlot
        .append('image')
        .classed('profile-image', true)
        .attr('transform', function(d: any) { return 'translate(0, ' + renderSettings.profileImageHeight / 2 + ') scale(1)'; })
        .attr('x', function (d) {
          return xScale(median(data.map(function(dm) { return dm.x; })));
        })
        .attr('y', '10')
        // .attr('y', function (d) {
        //   return max(data.map(function(dm) { return dm.y; }));
        // })
        .attr('xlink:href', !!(this.user.profilePhotoUrl) ? this.user.profilePhotoUrl : '/assets/images/profile-img.jpg')
        .attr('width', renderSettings.profileImageWidth)
        .attr('height', renderSettings.profileImageHeight);
  }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    this.refreshTimeline();
  }

  refreshTimeline(): void {
    const _this = this;
    const d3 = this.d3;
    const today = new Date();

    let startDate = new Date('January 1, 1950 00:00:00');
    if (this.user.dateOfBirth) {
      startDate = new Date(this.user.dateOfBirth);
      startDate.setDate(startDate.getDate() - 7); // subtract a week from the birth date so that memories on the birthdate are visible
    }
    if (startDate >= new Date()) { // dont let user set DOB in future
      startDate = new Date('January 1, 1950 00:00:00');
    }

    const boundaries = {
      start: startDate,
      end: new Date(today.getFullYear() + this.renderSettings.futureYears, today.getMonth(), today.getDate())
    };

    const timelineElement = this.nativeElement.querySelector('#timeline');

    this.timelineWidth = timelineElement.offsetWidth;
    this.timelineHeight = timelineElement.offsetHeight;

    if (!timelineElement) {
      return;
    };

    const d3ParentElement = d3.select(timelineElement);

    // clear previous
    d3ParentElement.select('svg').remove();

    // making the root svg, and mounting it to the `root` parameter.
    this.svg = d3ParentElement.append('svg')
      .attr('width', this.timelineWidth)
      .attr('height', this.timelineHeight)
      .call(d3.zoom()
        .translateExtent([[0, 0], [this.timelineWidth, this.timelineHeight]])
        .scaleExtent([1, this.renderSettings.zoomLimit])
        .on('zoom', _this.onZoomed.bind(_this)))

    // `scatterplot` will be the group which contains all the points.
    this.scatterPlot = this.svg.append('g')
      .classed('scatter-plot', true);

    // apply hidden rect which takes up full render space so zoom works everywhere
    this.scatterPlot.append('svg:rect')
      .attr('width', this.timelineWidth)
      .attr('height', this.timelineHeight)
      .attr('fill', 'transparent');

    // generate the datapoints and using a sin equation
    const pointCount = (this.renderSettings.cycles * this.renderSettings.density) + 1;
    const data = this.generateDataPoints(this.renderSettings, pointCount, boundaries);
    const todayPoint = this.determineTodayPoint(pointCount, boundaries);

    const xExtent: any = this.d3.extent(data.map( function (d) { return d.x; } ));
    const yExtent: any = this.d3.extent(data.map( function (d) { return d.y; } ));

    // get scales to fit data to graph
    const xScale = this.d3.scaleLinear().domain(xExtent).range([this.timelineWidth - this.timelinePadding, this.timelinePadding])
    const yScale = this.d3.scaleLinear().domain(yExtent).range([this.timelinePadding, this.timelineHeight - this.timelinePadding]);

    // clear the lines
    this.scatterPlot.selectAll('.line').remove();

    // render the lines
    const line = this.d3.line().curve(this.d3['curveBasis']);

    const lineData = [];
    const dottedLineData = [];
    // note that dotted line starts 2 points from the end
    for (let i = todayPoint; i < data.length; i++) {
      lineData.push([xScale(data[i].x), yScale(data[i].y)]);
    }
    for (let i = 0; i <= todayPoint; i++) {
      dottedLineData.push([xScale(data[i].x), yScale(data[i].y)]);
    }

    this.scatterPlot.append('path')
      .classed('line', true)
      .attr('stroke', '#488ecc')
      .attr('stroke-width', '2px')
      .attr('fill', 'transparent')
      .attr('d', line(lineData));

    this.scatterPlot.append('path')
      .classed('line', true)
      .attr('stroke', '#488ecc')
      .attr('stroke-dasharray', '2, 9')
      .attr('stroke-width', '2px')
      .attr('fill', 'transparent')
      .attr('marker-start', 'url(#triangle)')
      .attr('d', line(dottedLineData));

    // add the definition for the bubble shape
    const radialGradient = this.scatterPlot.append('defs')
      .append('radialGradient')
        .attr('x1', '0%')
        .attr('y1', '0%')
        .attr('x2', '100%')
        .attr('y2', '100%')
        .attr('spreadMethod', 'pad')
        .attr('id', 'radial-gradient');

    radialGradient.append('stop')
        .attr('offset', '30%')
        .attr('cx', '30%')
        .attr('stop-color', '#DDD')
        .attr('stop-opacity', 1);

    radialGradient.append('stop')
        .attr('offset', '70%')
        .attr('stop-color', '#999')
        .attr('stop-opacity', 1);

    this.scatterPlot.append('svg:marker')
      .attr('id', 'triangle')
      .attr('fill', '#488ecc')
      .attr('viewBox', '0 0 10 10')
      .attr('refX', 0)
      .attr('refY', 5)
      .attr('markerUnits', 'strokeWidth')
      .attr('markerWidth', 12)
      .attr('markerHeight', 8)
      .attr('orient', 'auto-start-reverse')
      .append('svg:path')
        .attr('d', 'M 0 0 L 10 5 L 0 10 z');

    this.renderProfileImage(this.renderSettings, data, xScale, this.d3.median, this.d3.max);

    this.renderMemoryPoints(this.renderSettings, data, xScale, yScale, this.d3.median);

    this.renderBubblePoints(this.renderSettings, data, xScale, yScale, this.d3.median);

    this.scatterPlot.selectAll('.memory-point')
      .on('click', _this.onMemoryClick.bind(_this));

    this.scatterPlot.selectAll('.bubble-point')
      .on('click', _this.onBubblesClick.bind(_this));
  }

  onZoomed(): void {
    // get the zoom event scale and translate vector
    let scale = Math.max(1, this.d3.event.transform.k);

    // limit zoom to boundaries
    const maxX = Math.max(this.d3.event.transform.x, this.timelineWidth - this.timelineWidth * scale);
    const maxY = Math.max(this.d3.event.transform.y, this.timelineHeight - this.timelineHeight * scale);

    let translateX = Math.min(0, maxX);
    let translateY = Math.min(0, maxY);

    // translate and scale the group
    this.scatterPlot.attr('transform', function() {
      return 'translate(' + translateX + ',' + translateY + ') scale(' + scale + ')';
    });

    // elements (icon/bubble) stop decreasing in size at a scale level of 3
    let elementScale = scale > 3 ? 3 : scale;

    // adapts the stroke width to the zoom level
    this.scatterPlot.selectAll('.memory-point')
      .attr('width', this.renderSettings.categoryIconWidth / elementScale)
      .attr('height', this.renderSettings.categoryIconHeight / elementScale)
      .attr('transform', 'translate(' + '-' + ((this.renderSettings.categoryIconWidth / 2) / elementScale) + ', -' + (this.renderSettings.categoryIconHeight / elementScale) + ')');

    this.scatterPlot.selectAll('.bubble-circle')
      .attr('transform', 'translate(' + (this.renderSettings.bubbleOffset / elementScale) + ', ' + (this.renderSettings.bubbleRadius / elementScale) + ')')
      .attr('r', this.renderSettings.bubbleRadius / elementScale);

    this.scatterPlot.selectAll('.bubble-text')
      .attr('transform', 'translate(' + (this.renderSettings.bubbleTextOffsetX / elementScale) + ', ' + (this.renderSettings.bubbleTextOffsetY / elementScale) + ')')
      .style('font-size', this.renderSettings.bubbleTextSize / elementScale + 'px');
  }

  onMemoryClick(point: any): void {
    this.loaderService.display(true);

    this.memoryService.getMemory(point.memory.memoryId)
      .subscribe(m => {
        this.selectedMemory = m;

        this.loaderService.display(false);

        this.memoryModal.show();
      }, err => {
        this.selectedMemory = new Memory();

        this.loaderService.display(false);
      });
  }

  onBubblesClick(point: any): void {
    this.loaderService.display(true);

    this.memoryBubbleService.getMemoryBubbleSummaries(point.memory.memoryId)
      .subscribe(summaries => {
        // find and map the screen names from the current users relations collection
        _.each(summaries, bs => {
          let bubbleOwnerRelation = _.find(this.relations, { relationUserId: bs.bubbleOwnerId });
          if (bubbleOwnerRelation) {
            bs.bubbleOwnerScreenName = bubbleOwnerRelation.screenName;
          } else {
            bs.bubbleOwnerScreenName = bs.bubbleOwnerName;
          }
        })
        this.selectedBubbleSummaries = summaries;

        this.loaderService.display(false);

        this.bubblesModal.show();
      }, err => {
        this.selectedMemory = new Memory();

        this.loaderService.display(false);
      });
  }

  hideMemoryModal(): void {
    this.memoryModal.hide();
  }

  hideBubblesModal(): void {
    this.bubblesModal.hide();
  }

  onClickPerson(userId: number) {
    this.memoryModal.hide();
    this.router.navigate(['/dashboard/timeline', userId || 0]);
  }

}
