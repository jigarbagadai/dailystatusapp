import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { Category } from '../../../models/Category';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

@Component({
    selector: 'app-settings-categories-section',
    templateUrl: './settings-categories-section.component.html'
})
export class SettingsCategoriesSectionComponent implements OnInit {

    @Input() data: Category;
    @Input() index;
    @Output() onCategorySave = new EventEmitter();
    @Output() onCategoryDelete = new EventEmitter();
    categoryImages = Array<string>();
    public categoryForm: FormGroup;

    constructor(private formbuilder: FormBuilder) {
    }

    ngOnInit(): void {
        this.categoryForm = this.initCategory(this.data);
        this.categoryImages = Array<string>();
        this.categoryImages.push('/assets/images/category-icons/other1.png');
        this.categoryImages.push('/assets/images/category-icons/other2.png');
        this.categoryImages.push('/assets/images/category-icons/other3.png');
    }

    initCategory(category: Category) {
        return this.formbuilder.group({
            categoryId: [category.categoryId],
            name: [category.name, Validators.required],
            ownerId: [category.ownerId],
            iconUrl: [category.iconUrl],
            iseditable: [category.iseditable]
        });
    }

    editSelectedCategory(category: Category, $event) {
        $event.preventDefault();
        if (category.iseditable) {
            if (category.categoryId > 0) {
                category.iseditable = false;
            }
            else {
                this.onCategoryDelete.emit(category);
            }
        }
        else {
            category.iseditable = true;
        }
    }

    cancelEdit(category: Category) {
        if (category.categoryId > 0) {
            category.iseditable = false;
        }
        else {
            this.onCategoryDelete.emit(category);
        }
    }

    onSaveCategory(formcategory: Category, datacategory: Category, $event) {
        $event.preventDefault();
        datacategory.iseditable = false;
        formcategory.iconUrl = datacategory.iconUrl;
        this.onCategorySave.emit(formcategory);
    }

    onDelete(index: number, $event) {
        $event.preventDefault();
        this.onCategoryDelete.emit(index);
    }

    onIconUrlChange(iconUrl: string, category: Category) {
        category.iconUrl = iconUrl;
    }
}
