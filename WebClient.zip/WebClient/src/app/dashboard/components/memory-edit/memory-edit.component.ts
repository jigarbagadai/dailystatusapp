import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import 'rxjs/add/operator/switchMap';

import { AuthContext } from '../../../services/auth.context';
import { MemoryService } from '../../../services/memory.service';
import { LoaderService } from '../../../services/loader.service';
import { Memory } from '../../../models/memory';
import { MemoryAttachment } from '../../../models/memory-attachment';
import { Category } from '../../../models/category';
import { Relation } from '../../../models/relation';
import { File } from '../../../models/file';

import { FileUploadModalComponent } from '../file-upload-modal/file-upload-modal.component';

import * as _ from 'lodash';
declare var google: any;

@Component({
    selector: 'app-memory-edit',
    templateUrl: './memory-edit.component.html',
    styleUrls: ['./memory-edit.component.scss']
})
export class MemoryEditComponent implements OnInit {

    public error: string;
    public success: string;
    public dateFormat: string;
    public dateFormatInTooltip: string;
    public memory: Memory;
    public categories: Category[];
    public relations: Relation[];

    public memoryForm: FormGroup;
    public formSubmitted: boolean;
    public selectedCategory: string;


    @ViewChild("search")
    public searchElementRef: ElementRef;

    @ViewChild('fileUpload') public fileUpload: FileUploadModalComponent;

    isExistingMemory() {
        return !!this.memory && !!this.memory.memoryId;
    }

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authContext: AuthContext,
        private memoryService: MemoryService,
        private loaderService: LoaderService,
        private formBuilder: FormBuilder,
        private ngZone: NgZone
    ) {
        this.formSubmitted = false;
        this.selectedCategory = null;
    }

    ngOnInit() {
      this.dateFormat = this.authContext.loggedInUser.dateFormat || 'dd/MM/yyyy';
      this.dateFormatInTooltip = this.dateFormat === 'dd/MM/yyyy' ? '27/01/2015' : '01/27/2015';

      this.route.data.subscribe((data: { memory: Memory, categories: Category[], relations: Relation[] }) => {
        if (!data.memory) {
            this.memory = new Memory();

            this.categories = data.categories;
            this.relations = data.relations;
        } else {
            this.memory = data.memory;

            this.categories = data.categories;
            // re-populate chosen category
            let category = _.find(this.categories, { categoryId: this.memory.categoryId });
            this.selectedCategory = category ? category.name : '';

            this.relations = _.map(data.relations, function (relation) {
                // check if relations is already in memory
                if (_.some(data.memory.lstPeople, { userRelationId: relation.userRelationId })) {
                    return _.extend({ display: true }, relation);
                }
                return _.extend({ display: false }, relation);
            });
        }

      });

      this.buildForm(this.memory);

      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
          types: ["geocode"]
      });
      autocomplete.addListener("place_changed", () => {
        this.ngZone.run(() => {
          let place: any = autocomplete.getPlace();

          if (place.geometry === undefined || place.geometry === null) {
              return;
          }

          this.memoryForm.controls['location'].setValue(place.name);
          this.memoryForm.controls['locationModel'].setValue({
              latitude: place.geometry.location.lat(),
              longitude: place.geometry.location.lng()
          });
        });
      });

    }

    private buildForm(memory): void {
        this.memoryForm = this.formBuilder.group({
            memoryId: [memory.memoryId],
            date: [memory.date],
            dateText: [memory.dateText],
            categoryId: [memory.categoryId, []],
            locationView: [memory.location, [Validators.required]],
            location: [memory.location, []],
            locationModel: [memory.locationModel, []],
            lstPeople: [memory.lstPeople, []],
            lstMemoryAttachment: [memory.lstMemoryAttachment, []],
            title: [memory.title, []],
            description: [memory.description, []]
        });
        this.memoryForm.markAsPristine();
    }

    setCategory(e, category) {
        this.selectedCategory = category.name;
        this.memoryForm.controls['categoryId'].setValue(category.categoryId);
    }

    addRelation(e, relation) {
        relation.display = true;
    }

    removeRelation(e, relation) {
        e.preventDefault();
        relation.display = false;
    }

    removeAttachment(e, attachment) {
        e.preventDefault();
        this.loaderService.display(true);

        this.memoryService.removeAttachement(attachment.fileIdentifier).subscribe(x => {
            this.loaderService.display(false);
            _.remove(this.memory.lstMemoryAttachment, { 'fileIdentifier': attachment.fileIdentifier });
        }, err => {
            this.loaderService.display(false);
        });
    }

    updatedDate(dateText: string) {
        this.memoryForm.patchValue({ dateText: dateText });
    }

    saveMemory(memory, isValid, $event: Event): void {
        $event.preventDefault();

        if (!isValid) {
            this.error = 'Please ensure the form is completed correctly';
            return;
        }

        memory.lstPeople = _.map(_.filter(this.relations, { display: true }), 'userRelationId');

        this.formSubmitted = true;

        this.error = undefined;
        this.success = undefined;

        if (memory.memoryId) {
            this.updateMemory(memory);
        } else {
            this.addMemory(memory);
        };
    }

    addMemory(memory: Memory) {
        this.loaderService.display(true);

        this.memoryService.addMemory(memory)
            .subscribe(x => {
                this.formSubmitted = false;
                this.loaderService.display(false);
                this.router.navigate(['/dashboard/home']);
            }, err => {
                this.error = err;
                this.loaderService.display(false);
                this.formSubmitted = false;
            });
    }

    updateMemory(memory: Memory) {
        this.loaderService.display(true);

        this.memoryService.updateMemory(memory)
            .subscribe(x => {
                this.formSubmitted = false;
                this.loaderService.display(false);
                this.router.navigate(['/dashboard/home']);
            }, err => {
                this.error = err;
                this.loaderService.display(false);
                this.formSubmitted = false;
            });
    }

    openPhotoUpload($event: Event): void {
        $event.preventDefault();

        this.fileUpload.showUploadModal();
    }

    onMemoryPhotosUpdated(files: File[]): void {
        if (!files || !files.length) {
            return;
        }

        files.forEach(file => {
            this.memory.lstMemoryAttachment.push({
                memoryAttachmentId: 0,
                memoryId: this.memory.memoryId || 0,
                fileName: file.name,
                fileIdentifier: file.id,
                attachmentUrl: file.url
            } as MemoryAttachment);
        });
    }

    onClearAllFiles() {
        for (var i = 0; i <= this.memory.lstMemoryAttachment.length; i++) {
            this.memory.lstMemoryAttachment.pop();
        } 
    }

}
