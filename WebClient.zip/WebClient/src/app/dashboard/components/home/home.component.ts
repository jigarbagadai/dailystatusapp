import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { AuthContext } from '../../../services/auth.context';
import { DashboardService } from '../../../services/dashboard.service';
import { LoaderService } from '../../../services/loader.service';
import { CacheService } from '../../../services/cache.service';
import { TimelineFilterTypes } from '../../../services/timeline-filter-types';
import { FuzzyDateUtility } from '../../../services/fuzzy-date.utility';
import { CategoryService } from '../../../services/category.service';

import { User } from '../../../models/user';
import { TimelineMemory } from '../../../models/timeline-memory';
import { TimelineFilter } from '../../../models/timeline-filter';
import { Category } from '../../../models/category';
import { Relation } from '../../../models/relation';

export class TimelineOption {
  label: string;
  value: string;
}

import * as _ from 'lodash';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HomeComponent implements OnInit {

  private user: User;
  private userTimelineInaccessible: boolean;
  private memories: TimelineMemory[] = [];
  private isRelationsTimeline: boolean;

  private searchCacheKey = 'searchTerm';
  private filterCacheKey = 'filters';

  public searchForm: FormGroup;
  public filterForm: FormGroup;

  public selectedFilter: TimelineOption;
  public filterOptions: TimelineOption[] = [];
  public filters: TimelineFilter[] = [];
  public filterTypes: TimelineFilterTypes;
  public searchTerm: string;

  public categories: Category[] = null;
  public relations: Relation[] = null;
  public owners: Relation[] = null;

  public catSummaryCollapsed: boolean = true;

  constructor(
    private authContext: AuthContext,
    private dashboardService: DashboardService,
    private loaderService: LoaderService,
    private cacheService: CacheService,
    private timelineFilterTypes: TimelineFilterTypes,
    private fuzzyDateUtility: FuzzyDateUtility,
    private categoryService: CategoryService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute)
  {
    this.route.data.subscribe((data: { relationUser: User, relations: Relation[] }) => {
      this.relations = data.relations;
      if (data.relationUser !== undefined && data.relationUser !== null) {
        // timelineUser is a relation who has given permission
        this.user = data.relationUser;
        this.isRelationsTimeline = true;
      } else if (data.relationUser === null) {
        // timelineUser is a relation who has NOT given permission
        this.userTimelineInaccessible = true;
      } else {
        // timelineUser is just the currentUser (home screen)
        this.user = authContext.loggedInUser;
        this.isRelationsTimeline = false;
      }

      this.updateTimelineMemories();
    });

    this.filterTypes = timelineFilterTypes;

    _.forOwn(timelineFilterTypes, (value, key) => {
      this.filterOptions.push({
        label: value.toUpperCase(),
        value: value,
      } as TimelineOption);
    });
  }

  ngOnInit() {
      this.searchTerm = this.cacheService.getCacheValue(this.searchCacheKey);
      this.filters = this.cacheService.getCacheValue(this.filterCacheKey) || [];

      this.buildForms();
  }

  private buildForms(): void {
    this.searchForm = this.formBuilder.group({
      searchTerm: [this.searchTerm, []]
    });
    this.filterForm = this.formBuilder.group({
      filterType: ['', [Validators.required]],
      filterDisplayValue: ['', [Validators.required]],
      filterValue: ['', [Validators.required]],
    });

    this.searchForm.markAsPristine();
    this.filterForm.markAsPristine();
  }

  private toTitleCase(str): string {
      return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
  }

  private updateTimelineMemories(): void {
    if (!this.user) {
      this.memories = [];
      return;
    }

    this.loaderService.display(true);

    this.dashboardService.getTimelineMemories(this.user.userId, this.searchTerm, this.filters)
      .subscribe(x => {
        this.memories = x;
        this.loaderService.display(false);
      });
  }

  onSelectFilter($event: Event, filter: TimelineOption) {
    $event.preventDefault();

    this.selectedFilter = filter;
    this.filterForm.patchValue({
      filterType: filter.value,
      filterDisplayValue: '',
      filterValue: ''
    });

    if (filter.value === this.filterTypes.category) {
      // if categories not loaded yet then fetch them
      if (this.categories === null) {
        this.categoryService.fetchCategories()
          .subscribe(c => {
            this.categories = c;
          });
      }
    } else if (filter.value === this.filterTypes.person || filter.value === this.filterTypes.owner) {
      // if relations not loaded yet then fetch them
      if (this.relations === null || this.owners === null) {
        // owners are registered relations
        this.owners = _.filter(this.relations, rr => { return !!(rr.relationUserId); });
        // add the current user themselve to the options
        this.owners.unshift({
          relationUserId: this.user.userId,
          firstName: this.user.firstName,
          lastName: this.user.lastName,
        } as Relation);
      }
    }
  }

  submitSearch(search, isValid, $event: Event): void {
    $event.preventDefault();

    this.searchTerm = search.searchTerm;

    this.updateTimelineMemories();

    this.cacheService.setCacheValue(this.searchCacheKey, search.searchTerm);
  }

  clearSearch($event: Event): void {
    $event.preventDefault();

    this.searchTerm = undefined;
    this.searchForm.patchValue({ searchTerm: '' });
    this.searchForm.markAsPristine();

    this.updateTimelineMemories();

    this.cacheService.removeFromCache(this.searchCacheKey);
  }

  submitFilter(filter, isValid, $event: Event): void {
    $event.preventDefault();

    this.filters.push({
      type: filter.filterType,
      label: this.toTitleCase(filter.filterType),
      displayValue: filter.filterDisplayValue,
      value: filter.filterValue,
    } as TimelineFilter);

    this.updateTimelineMemories();

    this.cacheService.setCacheValue(this.filterCacheKey, this.filters);

    this.filterForm.patchValue({
      filterValue: ''
    });
  }

  onFilterRemove($event: Event, filter: TimelineFilter) {
    $event.preventDefault();

    _.remove(this.filters, filter);

    this.updateTimelineMemories();

    this.cacheService.setCacheValue(this.filterCacheKey, this.filters);
  }

  onSelectCategory($event: Event, category: Category) {
    $event.preventDefault();

    this.filterForm.patchValue({
      filterDisplayValue: category.name,
      filterValue: category.categoryId,
    });

    this.submitFilter(this.filterForm.value, this.filterForm.valid, $event);
  }

  onSelectLocation($event: any) {
    $event.preventDefault();

    this.filterForm.patchValue({
      filterDisplayValue: $event.target.value,
      filterValue: $event.target.value
    });

    $event.target.value = '';

    this.submitFilter(this.filterForm.value, this.filterForm.valid, $event);
  }

  onSelectDate($event: any) {
    $event.preventDefault();

    let dateText = $event.target.value;
    //let date = this.fuzzyDateUtility.parseDate('dd/MM/yyyy', dateText);

    this.filterForm.patchValue({
      filterDisplayValue: dateText,
      filterValue: dateText
    });

    $event.target.value = '';

    this.submitFilter(this.filterForm.value, this.filterForm.valid, $event);
  }

  onSelectRelation($event: Event, relation: Relation) {
    $event.preventDefault();

    this.filterForm.patchValue({
      filterDisplayValue: relation.firstName + ' ' + relation.lastName,
      filterValue: relation.userRelationId // pass the userRelationId
    });

    this.submitFilter(this.filterForm.value, this.filterForm.valid, $event);
  }

  onSelectOwner($event: Event, relation: Relation) {
    $event.preventDefault();

    this.filterForm.patchValue({
      filterDisplayValue: relation.firstName + ' ' + relation.lastName,
      filterValue: relation.relationUserId // pass the owner userId
    });

    this.submitFilter(this.filterForm.value, this.filterForm.valid, $event);
  }

}
