import { Component, Input, Output, EventEmitter, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR, NG_VALIDATORS, FormControl } from '@angular/forms';

import { FuzzyDateUtility } from '../../.././services/fuzzy-date.utility';

@Component({
  selector: 'date-input',
  templateUrl: './date-input.component.html',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => DateInputComponent),
      multi: true,
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => DateInputComponent),
      multi: true,
    }]
})

export class DateInputComponent implements ControlValueAccessor {

  @Input()
  userDateFormat: string;

  @Input('placeholder')
  placeholder: string;

  @Input()
  dateText: string;
  @Output() update = new EventEmitter();

  private displayedDate: string;
  private parseError: boolean;
  private parsedDate: string;

  constructor(
    private fuzzyDateUtility: FuzzyDateUtility) {

  }

  writeValue(value: any) {
    value = this.dateText || null;
    if (value !== undefined && value != null) {
      this.displayedDate = value;
      this.parsedDate = this.fuzzyDateUtility.parseDate(this.userDateFormat, value);
      this.propagateChange(this.parsedDate);
    } else {
      this.displayedDate = '';
    };
  }

  private propagateChange = (_: any) => { };

  public registerOnChange(fn: any) {
    this.propagateChange = fn;
  }

  public validate(c: FormControl) {
    return (!this.parseError) ? null : {
      invalidDateError: {
        valid: false,
      },
    };
  }

  registerOnTouched() { }

  private onChange(event) {
    let newValue = event.target.value;
    // this.displayedDate = newValue;
    if (newValue != undefined && newValue != null) {
      try {
        this.parsedDate = this.fuzzyDateUtility.parseDate(this.userDateFormat, newValue);
        this.parseError = false;
      } catch (ex) {
        this.parseError = true;
      }
      this.propagateChange(this.parsedDate);
    }

    this.update.emit(newValue);
  }

}
