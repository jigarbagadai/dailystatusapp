import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { AuthContext } from '../../../services/auth.context';
import { MemoryBubbleService } from '../../../services/memory-bubble.service';
import { NotificationService } from '../../../services/notification.service';
import { MemoryBubble } from '../../../models/memory-bubble';
import { MemoryBubblePerson } from '../../../models/memory-bubble-person';
import { Relation } from '../../../models/relation';

import * as _ from 'lodash';

@Component({
  selector: 'app-bubble-view',
  templateUrl: './bubble-view.component.html',
  styleUrls: ['./bubble-view.component.scss']
})
export class BubbleViewComponent implements OnInit {
  public saveToTimeline: string;
  public saveToBookmarks: string;
  public memoryBubble: MemoryBubble;
  public persons: MemoryBubblePerson[] = [];

  isOwnMemoryBubble() {
    return this.memoryBubble && this.memoryBubble.bubbleOwnerId === this.authContext.loggedInUser.userId;
  }

  constructor(
    private memoryBubbleService: MemoryBubbleService,
    private notificationService: NotificationService,
    private route: ActivatedRoute,
    private authContext: AuthContext) { }

  ngOnInit() {
    this.route.data.subscribe((data: { memoryBubble: MemoryBubble, relations: Relation[] }) => {
      this.memoryBubble = data.memoryBubble;

      let persons = this.persons;
      let currentUserId = this.authContext.loggedInUser.userId;
      _.each(this.memoryBubble.lstBubblePeople, function (person) {
        if (person.userId === currentUserId) {
          person.screenName = person.firstName + ' ' + person.lastName;
          persons.push(person);
        } else {
          let relation = _.find(data.relations, { relationUserId: person.userId });
          if (relation) {
            person.screenName = relation.screenName;
            persons.push(person);
          }
          // if not a relation then dont display
        }
      });

      this.saveToTimeline = this.memoryBubble.bubbleSavedToTimeline ? 'YES' : 'NO';
      this.saveToBookmarks = this.memoryBubble.bubbleBookmarked ? 'YES' : 'NO';
    });
  }

  updateSaveToTimeline(value: string): void {
    this.memoryBubble.bubbleSavedToTimeline = value === 'YES';

    this.memoryBubbleService.updateMemoryBubbleUser(
      this.memoryBubble.memoryBubbleId,
      this.memoryBubble.bubbleSavedToTimeline,
      this.memoryBubble.bubbleBookmarked)
      .subscribe(x => { });
  }

  updateSaveToBookmarks(value: string): void {
    this.memoryBubble.bubbleBookmarked = value === 'YES';

    this.memoryBubbleService.updateMemoryBubbleUser(
      this.memoryBubble.memoryBubbleId,
      this.memoryBubble.bubbleSavedToTimeline,
      this.memoryBubble.bubbleBookmarked)
      .subscribe(x => {
        this.notificationService.loadBookmarks().subscribe(y => { });
      });
  }

}
