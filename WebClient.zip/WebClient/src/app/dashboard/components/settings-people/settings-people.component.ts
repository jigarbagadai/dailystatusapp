import { Component, OnInit, ViewChild  } from '@angular/core';
import { Relation } from '../../../models/Relation';
import { LoaderService } from '../../../services/loader.service';
import { RelationService } from '../../../services/relation.service';
import { ConfirmModalComponent } from '../confirm-modal/confirm-modal.component';


@Component({
    selector: 'app-settings-people',
    templateUrl: './settings-people.component.html',
    styleUrls: ['./settings-people.component.scss']
})
export class SettingsPeopleComponent implements OnInit {
    public lstrelations: Relation[];
    public error: any;
    public success: any;
    @ViewChild('peopelConfirmmodal') public peopelConfirm: ConfirmModalComponent;

    constructor(private relationService: RelationService, private loaderService: LoaderService) {
    }

    ngOnInit() {
        this.getAllRelations();
    }

    getAllRelations(): void {
        this.loaderService.display(true);
        this.relationService.fetchRelations()
            .subscribe(x => {
                this.loaderService.display(false);
                this.lstrelations = <Relation[]>x;
            }, err => {
                this.loaderService.display(false);

            });
    }

    showAddRelation($event: Event) {
        let relation = new Relation();
        relation.iseditable = true;
        relation.relationshipType = 'Mother';
        relation.userRelationId = 0;
        relation.timelineShared = true;
        this.lstrelations.push(relation);
    }

    onSaveRelation(relation: Relation) {
        this.loaderService.display(true);
        this.success = '';
        this.error = '';

        if (!relation.userRelationId) {
            relation.userRelationId = 0;
            this.relationService.savePeople(relation).subscribe(x => {
                //this.success = "Details have successfully updated";
                this.loaderService.display(false);
                this.getAllRelations();
            }, err => {
                this.loaderService.display(false);
                this.error = "Ooops... Something went wrong.";
            });
        } else {
            this.relationService.updatePeople(relation.userRelationId, relation).subscribe(x => {
                //this.success = "Details have successfully updated";
                this.loaderService.display(false);
                this.getAllRelations();
            }, err => {
                this.loaderService.display(false);
                this.error = "Ooops... Something went wrong.";
            });
        }
    }

    onRemoveRelation(index: number) {
        this.peopelConfirm.showConfirmModal(index.toString());

    }

    onButtonClick(event) {
        if (event.dialogResult == "YES") {
            this.success = '';
            this.error = '';
            let relation: Relation = this.lstrelations[parseInt(event.returnParams)];
            if (!relation || !relation.userRelationId || relation.userRelationId == 0) {
                this.lstrelations.pop();
            } else {
                this.loaderService.display(true);
                this.relationService.deletePeople(relation.userRelationId).subscribe(x => {
                    //this.success = "record deleted sucessfully";
                    this.loaderService.display(false);
                    this.getAllRelations();
                }, err => {
                    this.loaderService.display(false);
                    this.error = "Ooops... Something went wrong.";
                });
            }
        }
    }
}
