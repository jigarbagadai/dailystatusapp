import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import 'rxjs/add/operator/switchMap';

import { AuthContext } from '../../../services/auth.context';
import { MemoryService } from '../../../services/memory.service';
import { NotificationService } from '../../../services/notification.service';
import { Memory } from '../../../models/memory';
import { Category } from '../../../models/category';
import { Relation } from '../../../models/relation';

import * as _ from 'lodash';

@Component({
  selector: 'app-memory-view',
  templateUrl: './memory-view.component.html',
  styleUrls: ['./memory-view.component.scss']
})
export class MemoryViewComponent implements OnInit {

  public saveToTimeline: string;
  public saveToBookmarks: string;
  
  public memory: Memory;
  public categories: Category[];
  public relations: Relation[];

  isOwnMemory() {
    return this.memory
      && this.memory.ownerId === this.authContext.loggedInUser.userId;
  }

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authContext: AuthContext,
    private memoryService: MemoryService,
    private notificationService: NotificationService,
    private ngZone: NgZone) { }

  ngOnInit() {
    this.route.data.subscribe((data: {
      memory: Memory,
      categories: Category[],
      relations: Relation[]
    }) => {
      if (!data.memory) {
        this.memory = new Memory();
      } else {
        this.memory = data.memory;
      }
      this.categories = data.categories;
      this.relations = data.relations;
      this.relations = _.map(this.relations, function (element) {
        return _.extend({}, element, { display: true });
      });

      this.saveToTimeline = this.memory.savedToTimeline ? 'YES' : 'NO';
      this.saveToBookmarks = this.memory.bookmarked ? 'YES' : 'NO';

    });
  }

  updateSaveToTimeline(value: string): void {
    this.memory.savedToTimeline = value === 'YES';

    this.memoryService.updateMemoryUser(this.memory.memoryId, this.memory.savedToTimeline, this.memory.bookmarked)
      .subscribe(x => { });
  }

  updateSaveToBookmarks(value: string): void {
    this.memory.bookmarked = value === 'YES';

    this.memoryService.updateMemoryUser(this.memory.memoryId, this.memory.savedToTimeline, this.memory.bookmarked)
      .subscribe(x => {
        this.notificationService.loadBookmarks().subscribe(y => { });
      });
  }

  onClickPerson(userId: number) {
    this.router.navigate(['/dashboard/timeline', userId || 0]);
  }

}
