import { MdrappPage } from './app.po';

describe('mdrapp App', () => {
  let page: MdrappPage;

  beforeEach(() => {
    page = new MdrappPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
